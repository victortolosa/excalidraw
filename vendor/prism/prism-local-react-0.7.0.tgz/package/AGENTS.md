# Prism 0.7.0

Read [release identity](release.json) and [discovery](agent/manifest.json) first. Code, guidance and checks must match this installed release (a145cd7af00c9b18e3f6ff29b3c1f746f4dad21487d80c306f832a4c7fda45f4). Only its export inventory is available.

Read [consumer rules](agent/rules.md), then the [page skill](agent/skills/prism-page/SKILL.md) for design/implementation. Retrieve only selected component guidance, schemas and React declarations. [Audit policy](agent/audit.md), [template](agent/audit-template.md), [recipes](agent/recipes.md), [theming](agent/theming.md) and [validation](agent/validation.md) are available without Prism repository access.

Import from @prism-local/react. Choose one CSS integration: import @prism-local/react/styles.css once, or build its Tailwind source with selected component manifests. Follow [stylesheet setup](styling.md); preserve an existing source integration instead of adding the compiled stylesheet. Run prism-check and project validation. Run prism-setup from the project root to connect this entry point to existing agent instructions and add a check script. Setup does not install a framework, change styling or publish anything.
