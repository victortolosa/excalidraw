const palette = 'slate|gray|zinc|neutral|stone|red|orange|amber|yellow|lime|green|emerald|teal|cyan|sky|blue|indigo|violet|purple|fuchsia|pink|rose';
export const forbiddenVisualValues = [
    ['hex color', /#[0-9a-fA-F]{3,8}\b/],
    ['color function', /\b(rgb|rgba|hsl|hsla|oklch|oklab|lab|lch|color-mix)\(/],
    ['Tailwind palette class', new RegExp(`\\b(bg|text|border|ring|outline|fill|stroke|from|via|to|decoration|divide|placeholder)-(${palette})-\\d{2,3}\\b`)],
    ['fixed white or black class', /\b(bg|text|border|ring|outline|fill|stroke)-(white|black)\b/],
    ['arbitrary color utility', /\b(bg|text|border|ring|outline|fill|stroke)-\[(?!var\(|length:|url\(|[-\d])[^\]]+\]/],
    ['primitive variable', /--primitive-/],
];
// Values that bypass the token-backed spacing, radius and type scales. Prototypes apply these on top of the rules
// above; values built from variables, such as py-[calc(var(--button-padding-y)-1px)], are left to the role check.
export const scaleBypassValues = [
    ['arbitrary spacing, radius or type value', /(?<![\w-])-?(p[xytrblse]?|m[xytrblse]?|gap(-[xy])?|space-[xy]|rounded(-[trblse]{1,2})?|text|leading|tracking|font)-\[(?![^\]]*var\()[^\]]+\]/],
    ['inline spacing, radius or type style', /\bstyle=\{\{[^}]*\b(padding|margin|gap|rowGap|columnGap|fontSize|fontFamily|fontWeight|lineHeight|letterSpacing|borderRadius)\w*\s*:/],
];
