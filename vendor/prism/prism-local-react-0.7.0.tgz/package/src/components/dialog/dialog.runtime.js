//#region src/components/dialog/dialog.runtime.ts
var e = {
	confirmVariant: "primary",
	cancelLabel: "Cancel",
	defaultOpen: !1
};
//#endregion
export { e as dialogDefaults };
