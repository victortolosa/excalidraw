import { typographyProps as e } from "../../lib/typography.js";
import { Alert as t } from "../alert/alert.js";
import { Button as n } from "../button/button.js";
import { Dialog as r, DialogClose as i, DialogContent as a, DialogDescription as o, DialogFooter as s, DialogHeader as c, DialogTitle as l, DialogTrigger as u } from "../ui/dialog.js";
import { dialogDefaults as d } from "./dialog.runtime.js";
import { dialogMeta as f } from "./dialog.meta.js";
import { useRef as p, useState as m } from "react";
import { jsx as h, jsxs as g } from "react/jsx-runtime";
//#region src/components/dialog/dialog.tsx
var _ = "max-h-[calc(100dvh-2rem)] overflow-y-auto", v = "leading-snug wrap-anywhere";
function y({ title: y, description: b, confirmLabel: x, confirmVariant: S = d.confirmVariant, cancelLabel: C = d.cancelLabel, error: w, open: T, defaultOpen: E = d.defaultOpen, onOpenChange: D, trigger: O, onConfirm: k, children: A, returnFocusRef: j }) {
	let [M, N] = m(E), P = p(null), [F, I] = m(!1), L = T ?? M, R = (e) => {
		T === void 0 && N(e), D?.(e);
	}, z = async () => {
		if (F) return;
		let e = k?.();
		if (!(e instanceof Promise)) return R(!1);
		I(!0);
		try {
			await e, R(!1);
		} catch {} finally {
			I(!1);
		}
	};
	return /* @__PURE__ */ g(r, {
		open: L,
		onOpenChange: R,
		children: [O && /* @__PURE__ */ h(u, {
			asChild: !0,
			children: O
		}), /* @__PURE__ */ g(a, {
			"data-component": f.id,
			className: _,
			onOpenAutoFocus: (e) => {
				S === "destructive" && (e.preventDefault(), P.current?.focus());
			},
			onCloseAutoFocus: (e) => {
				j?.current && (e.preventDefault(), j.current.focus());
			},
			...b ? {} : { "aria-describedby": void 0 },
			children: [
				/* @__PURE__ */ g(c, {
					className: "min-w-0 pr-8",
					children: [/* @__PURE__ */ h(l, {
						...e("dialog", "title"),
						className: v,
						children: y
					}), b && /* @__PURE__ */ h(o, {
						...e("dialog", "description"),
						className: "wrap-anywhere",
						children: b
					})]
				}),
				A && /* @__PURE__ */ h("div", {
					...e("dialog", "body"),
					className: "min-w-0",
					children: A
				}),
				w && /* @__PURE__ */ h(t, {
					title: w,
					variant: "destructive",
					live: "assertive"
				}),
				/* @__PURE__ */ g(s, { children: [/* @__PURE__ */ h(i, {
					asChild: !0,
					children: /* @__PURE__ */ h(n, {
						ref: P,
						variant: "secondary",
						children: C
					})
				}), x && /* @__PURE__ */ h(n, {
					variant: S,
					loading: F,
					onClick: z,
					children: x
				})] })
			]
		})]
	});
}
//#endregion
export { y as Dialog };
