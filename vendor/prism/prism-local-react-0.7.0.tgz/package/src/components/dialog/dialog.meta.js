//#region src/components/dialog/dialog.meta.ts
var e = {
	id: "dialog",
	name: "Dialog",
	status: "experimental",
	sources: {
		contract: "src/components/dialog/dialog.contract.ts",
		implementation: "src/components/dialog/dialog.tsx",
		guidance: "src/components/dialog/dialog.mdx",
		fixtures: "src/components/dialog/dialog.fixtures.ts",
		stories: "src/components/dialog/dialog.stories.tsx",
		catalog: "src/components/ui/dialog.tsx"
	},
	tokens: [
		"border",
		"font-heading",
		"foreground",
		"muted",
		"muted-foreground",
		"popover",
		"popover-foreground"
	],
	origin: {
		kind: "shadcn-wrapper",
		catalogSources: ["catalog"]
	},
	dependencies: ["alert", "button"]
};
//#endregion
export { e as dialogMeta };
