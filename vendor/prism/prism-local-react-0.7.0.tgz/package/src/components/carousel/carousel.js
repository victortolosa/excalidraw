import { typographyProps as e } from "../../lib/typography.js";
import { Button as t } from "../button/button.js";
import { Carousel as n, CarouselContent as r, CarouselItem as i } from "../ui/carousel.js";
import { useEffect as a, useState as o } from "react";
import { jsx as s, jsxs as c } from "react/jsx-runtime";
//#region src/components/carousel/carousel.tsx
function l({ label: l, items: u, renderSlide: d }) {
	let [f, p] = o(), [m, h] = o(0), [g, _] = o(!0);
	return a(() => {
		let e = window.matchMedia("(prefers-reduced-motion: reduce)"), t = () => _(e.matches);
		return t(), e.addEventListener("change", t), () => e.removeEventListener("change", t);
	}, []), a(() => {
		if (!f) return;
		let e = () => h(f.selectedScrollSnap());
		return e(), f.on("select", e).on("reInit", e), () => {
			f.off("select", e).off("reInit", e);
		};
	}, [f]), /* @__PURE__ */ c(n, {
		"data-component": "carousel",
		"aria-label": l,
		tabIndex: 0,
		setApi: p,
		opts: {
			loop: !1,
			duration: g ? 0 : 25
		},
		className: "min-w-0 max-w-full rounded-panel focus-visible:outline-2 focus-visible:outline-ring",
		onKeyDownCapture: (e) => {
			e.target === e.currentTarget && (e.key === "ArrowLeft" && (e.preventDefault(), f?.scrollPrev()), e.key === "ArrowRight" && (e.preventDefault(), f?.scrollNext()));
		},
		children: [/* @__PURE__ */ s(r, { children: u.map((e, t) => /* @__PURE__ */ s(i, {
			"aria-label": `${t + 1} of ${u.length}: ${e.label}`,
			"aria-hidden": t !== m,
			inert: t !== m,
			children: /* @__PURE__ */ s("div", {
				className: "min-w-0 p-1 wrap-anywhere",
				children: d(e.id)
			})
		}, e.id)) }), /* @__PURE__ */ c("div", {
			className: "mt-3 flex flex-wrap items-center gap-2",
			children: [
				/* @__PURE__ */ s(t, {
					variant: "secondary",
					disabled: !f || m === 0,
					onClick: () => f?.scrollPrev(),
					children: "Previous slide"
				}),
				/* @__PURE__ */ s(t, {
					variant: "secondary",
					disabled: !f || m === u.length - 1,
					onClick: () => f?.scrollNext(),
					children: "Next slide"
				}),
				/* @__PURE__ */ c("p", {
					...e("carousel", "status"),
					role: "status",
					"aria-atomic": "true",
					className: "text-sm text-muted-foreground",
					children: [
						"Slide ",
						m + 1,
						" of ",
						u.length
					]
				})
			]
		})]
	});
}
//#endregion
export { l as Carousel };
