//#region src/components/accordion/accordion.runtime.ts
var e = {
	type: "single",
	defaultValue: "",
	disabled: !1
};
//#endregion
export { e as accordionDefaults };
