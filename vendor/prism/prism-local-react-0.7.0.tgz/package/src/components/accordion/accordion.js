import { typographyProps as e } from "../../lib/typography.js";
import { Accordion as t, AccordionContent as n, AccordionItem as r, AccordionTrigger as i } from "../ui/accordion.js";
import { accordionDefaults as a } from "./accordion.runtime.js";
import { jsx as o, jsxs as s } from "react/jsx-runtime";
//#region src/components/accordion/accordion.tsx
function c(c) {
	let l = c.items.map((t) => /* @__PURE__ */ s(r, {
		value: t.id,
		disabled: t.disabled,
		children: [/* @__PURE__ */ o(i, {
			...e("accordion", "title"),
			className: "min-w-0 gap-2 wrap-anywhere focus-visible:ring-ring text-(length:--accordion-title-font-size) leading-(--accordion-title-line-height)",
			children: t.title
		}), /* @__PURE__ */ o(n, {
			...e("accordion", "body"),
			className: "h-auto px-1 wrap-anywhere text-(length:--accordion-body-font-size) leading-(--accordion-body-line-height)",
			children: c.renderPanel(t.id)
		})]
	}, t.id)), u = c.disabled ?? a.disabled;
	return c.type === "multiple" ? /* @__PURE__ */ o(t, {
		"data-component": "accordion",
		type: "multiple",
		disabled: u,
		defaultValue: c.defaultValue ?? [],
		value: c.value,
		onValueChange: c.onValueChange,
		children: l
	}) : /* @__PURE__ */ o(t, {
		"data-component": "accordion",
		type: "single",
		collapsible: !0,
		disabled: u,
		defaultValue: c.defaultValue ?? a.defaultValue,
		value: c.value,
		onValueChange: c.onValueChange,
		children: l
	});
}
//#endregion
export { c as Accordion };
