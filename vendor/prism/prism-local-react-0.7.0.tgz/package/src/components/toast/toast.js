import { typographyProps as e } from "../../lib/typography.js";
import { Toaster as t } from "../ui/sonner.js";
import { toastDefaults as n } from "./toast.runtime.js";
import { createContext as r, useContext as i, useEffect as a, useId as o, useMemo as s, useRef as c, useState as l } from "react";
import { jsx as u, jsxs as d } from "react/jsx-runtime";
import { createPortal as f } from "react-dom";
import { toast as p } from "sonner";
//#region src/components/toast/toast.tsx
var m = r(null), h = {
	default: p,
	success: p.success,
	info: p.info,
	warning: p.warning,
	destructive: p.error
};
function g({ children: r, validateInput: i }) {
	let g = o(), _ = c(/* @__PURE__ */ new Set()), [v, y] = l(null), [b, x] = l("light");
	a(() => {
		y(document.body);
		let e = document.documentElement, t = () => x(e.dataset.mode === "dark" ? "dark" : "light");
		t();
		let n = new MutationObserver(t);
		n.observe(e, {
			attributes: !0,
			attributeFilter: ["data-mode"]
		});
		let r = _.current;
		return () => {
			n.disconnect();
			for (let e of r) p.dismiss(e);
			r.clear();
		};
	}, []);
	let S = s(() => ({
		show(t) {
			let { title: r, description: a, variant: o = n.variant, duration: s = n.duration } = i ? i(t) : t, c = (e) => {
				_.current.delete(e.id);
			}, l = h[o](/* @__PURE__ */ u("span", {
				...e("toast", "title"),
				children: r
			}), {
				description: a ? /* @__PURE__ */ u("span", {
					...e("toast", "description"),
					children: a
				}) : void 0,
				duration: s,
				toasterId: g,
				onDismiss: c,
				onAutoClose: c
			});
			return _.current.add(l), l;
		},
		dismiss(e) {
			_.current.delete(e) && p.dismiss(e);
		}
	}), [g, i]);
	return /* @__PURE__ */ d(m.Provider, {
		value: S,
		children: [r, v && f(/* @__PURE__ */ u("div", {
			"data-component": "toast",
			"data-scheme": "default",
			children: /* @__PURE__ */ u(t, {
				id: g,
				theme: b,
				position: "bottom-right",
				closeButton: !0,
				richColors: !1,
				toastOptions: { classNames: {
					toast: "font-sans",
					title: "wrap-anywhere",
					description: "!text-muted-foreground wrap-anywhere",
					closeButton: "!bg-popover !text-popover-foreground !border-border focus-visible:!outline-ring"
				} }
			})
		}), v)]
	});
}
function _() {
	let e = i(m);
	if (!e) throw Error("useToast requires ToastProvider");
	return e;
}
//#endregion
export { g as ToastProvider, _ as useToast };
