import { toastSchema as e } from "./toast.contract.js";
//#region src/components/toast/toast-validation.ts
function t(t) {
	return e.parse(t);
}
//#endregion
export { t as validateToast };
