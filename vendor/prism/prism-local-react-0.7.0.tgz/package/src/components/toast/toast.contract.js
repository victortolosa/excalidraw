import { toastDefaults as e } from "./toast.runtime.js";
import { z as t } from "zod";
//#region src/components/toast/toast.contract.ts
var n = [
	"default",
	"success",
	"info",
	"warning",
	"destructive"
], r = t.strictObject({
	title: t.string().regex(/\S/).describe("Brief, explicit outcome; meaning must not depend on the icon."),
	description: t.string().regex(/\S/).optional().describe("Optional supporting information. Essential instructions also belong inline."),
	variant: t.enum(n).default(e.variant),
	duration: t.number().int().min(5e3).max(3e4).default(e.duration).describe("Visible duration in milliseconds, paused by Sonner during interaction.")
}).meta({
	title: "Toast",
	description: "Brief non-blocking outcome feedback via ToastProvider and useToast. Use inline Alert for persistent errors or required action."
});
//#endregion
export { r as toastSchema, n as toastVariants };
