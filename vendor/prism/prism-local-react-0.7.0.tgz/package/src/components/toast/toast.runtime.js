//#region src/components/toast/toast.runtime.ts
var e = {
	variant: "default",
	duration: 6e3
};
//#endregion
export { e as toastDefaults };
