import { typographyProps as e } from "../../lib/typography.js";
import { Field as t, FieldContent as n, FieldDescription as r, FieldError as i, FieldLabel as a } from "../ui/field.js";
import { Switch as o } from "../ui/switch.js";
import { switchDefaults as s } from "./switch.runtime.js";
import { useId as c } from "react";
import { jsx as l, jsxs as u } from "react/jsx-runtime";
//#region src/components/switch/switch.tsx
function d({ label: d, description: f, error: p, id: m, name: h, value: g, form: _, required: v = s.required, disabled: y = s.disabled, checked: b, defaultChecked: x = s.defaultChecked, onCheckedChange: S }) {
	let C = c(), w = m ?? C, T = [f && `${w}-description`, p && `${w}-error`].filter(Boolean).join(" ") || void 0;
	return /* @__PURE__ */ u(t, {
		"data-component": "switch",
		"data-invalid": !!p,
		"data-disabled": y,
		orientation: "horizontal",
		className: "min-w-0 items-start justify-between",
		children: [/* @__PURE__ */ u(n, {
			className: "pr-4",
			children: [
				/* @__PURE__ */ u(a, {
					...e("switch", "label"),
					htmlFor: w,
					className: "break-words",
					children: [d, v && /* @__PURE__ */ l("span", {
						"aria-hidden": "true",
						children: " (required)"
					})]
				}),
				f && /* @__PURE__ */ l(r, {
					...e("switch", "description"),
					id: `${w}-description`,
					className: "break-words",
					children: f
				}),
				p && /* @__PURE__ */ l(i, {
					...e("switch", "error"),
					id: `${w}-error`,
					className: "break-words",
					children: p
				})
			]
		}), /* @__PURE__ */ l(o, {
			id: w,
			name: h,
			value: g,
			form: _,
			disabled: y,
			required: v,
			checked: b,
			defaultChecked: x,
			onCheckedChange: S,
			"aria-invalid": p ? !0 : void 0,
			"aria-describedby": T,
			className: "mt-0.5 after:right-0 focus-visible:ring-ring aria-invalid:focus-visible:ring-ring"
		})]
	});
}
//#endregion
export { d as Switch };
