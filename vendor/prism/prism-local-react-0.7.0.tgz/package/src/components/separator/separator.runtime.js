//#region src/components/separator/separator.runtime.ts
var e = {
	orientation: "horizontal",
	decorative: !0
};
//#endregion
export { e as separatorDefaults };
