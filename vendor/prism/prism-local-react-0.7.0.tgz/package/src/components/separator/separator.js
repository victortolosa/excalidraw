import { Separator as e } from "../ui/separator.js";
import { separatorDefaults as t } from "./separator.runtime.js";
import { jsx as n } from "react/jsx-runtime";
//#region src/components/separator/separator.tsx
function r({ orientation: r = t.orientation, decorative: i = t.decorative }) {
	return /* @__PURE__ */ n(e, {
		"data-component": "separator",
		orientation: r,
		decorative: i
	});
}
//#endregion
export { r as Separator };
