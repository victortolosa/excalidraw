//#region src/components/avatar/avatar.runtime.ts
var e = {
	size: "default",
	decorative: !1
};
function t(e) {
	let t = e.trim().split(/\s+/), n = (e) => Array.from(e)[0] ?? "";
	return (n(t[0]) + (t.length > 1 ? n(t[t.length - 1]) : "")).toLocaleUpperCase();
}
//#endregion
export { e as avatarDefaults, t as avatarInitials };
