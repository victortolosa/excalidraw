//#region src/components/avatar/avatar.meta.ts
var e = {
	id: "avatar",
	name: "Avatar",
	status: "experimental",
	sources: {
		contract: "src/components/avatar/avatar.contract.ts",
		implementation: "src/components/avatar/avatar.tsx",
		guidance: "src/components/avatar/avatar.mdx",
		fixtures: "src/components/avatar/avatar.fixtures.ts",
		stories: "src/components/avatar/avatar.stories.tsx",
		catalog: "src/components/ui/avatar.tsx"
	},
	tokens: [
		"border",
		"muted",
		"muted-foreground"
	],
	origin: {
		kind: "shadcn-wrapper",
		catalogSources: ["catalog"]
	},
	dependencies: []
};
//#endregion
export { e as avatarMeta };
