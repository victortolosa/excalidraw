import { typographyProps as e } from "../../lib/typography.js";
import { Avatar as t, AvatarFallback as n, AvatarImage as r } from "../ui/avatar.js";
import { avatarDefaults as i, avatarInitials as a } from "./avatar.runtime.js";
import { avatarMeta as o } from "./avatar.meta.js";
import { jsx as s, jsxs as c } from "react/jsx-runtime";
//#region src/components/avatar/avatar.tsx
function l({ name: l, src: u, size: d = i.size, decorative: f = i.decorative }) {
	let p = f ? { "aria-hidden": !0 } : {
		role: "img",
		"aria-label": l
	};
	return /* @__PURE__ */ c(t, {
		size: d,
		"data-component": o.id,
		...p,
		children: [u && /* @__PURE__ */ s(r, {
			src: u,
			alt: ""
		}), /* @__PURE__ */ s(n, {
			...e("avatar", `initials-${d}`),
			"aria-hidden": "true",
			children: a(l)
		})]
	});
}
//#endregion
export { l as Avatar };
