//#region src/components/tabs/tabs.meta.ts
var e = {
	id: "tabs",
	name: "Tabs",
	status: "experimental",
	sources: {
		contract: "src/components/tabs/tabs.contract.ts",
		implementation: "src/components/tabs/tabs.tsx",
		guidance: "src/components/tabs/tabs.mdx",
		fixtures: "src/components/tabs/tabs.fixtures.ts",
		stories: "src/components/tabs/tabs.stories.tsx",
		catalog: "src/components/ui/tabs.tsx"
	},
	tokens: [
		"background",
		"foreground",
		"input",
		"muted",
		"muted-foreground",
		"ring"
	],
	origin: {
		kind: "shadcn-wrapper",
		catalogSources: ["catalog"]
	},
	dependencies: []
};
//#endregion
export { e as tabsMeta };
