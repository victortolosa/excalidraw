import { typographyProps as e } from "../../lib/typography.js";
import { Tabs as t, TabsContent as n, TabsList as r, TabsTrigger as i } from "../ui/tabs.js";
import { firstEnabledTab as a, tabsDefaults as o } from "./tabs.runtime.js";
import { tabsMeta as s } from "./tabs.meta.js";
import { createElement as c } from "react";
import { jsx as l, jsxs as u } from "react/jsx-runtime";
//#region src/components/tabs/tabs.tsx
var d = "h-auto max-w-full group-data-horizontal/tabs:h-auto", f = "transition-none h-auto min-w-0 self-stretch whitespace-normal break-words text-center focus-visible:ring-ring", p = "transition-none h-auto min-w-0 self-stretch whitespace-nowrap overflow-hidden text-ellipsis text-center focus-visible:ring-ring", m = "min-w-0 rounded-md focus-visible:ring-3 focus-visible:ring-ring", h = {
	default: "",
	sm: "px-1"
};
function g({ label: t, tabs: n, truncate: a, size: s = o.size }) {
	let u = `${a ? p : f} ${h[s]}`;
	return /* @__PURE__ */ l(r, {
		"aria-label": t,
		"data-size": s,
		className: d,
		children: n.map((t) => /* @__PURE__ */ c(i, {
			...e("tabs", "label"),
			key: t.value,
			value: t.value,
			disabled: t.disabled,
			className: u
		}, t.label))
	});
}
function _({ value: e, defaultValue: n, onValueChange: r, children: i }) {
	return /* @__PURE__ */ l(t, {
		"data-component": s.id,
		value: e,
		defaultValue: n,
		onValueChange: r,
		className: "min-w-0",
		children: i
	});
}
function v({ value: t, children: r }) {
	return /* @__PURE__ */ l(n, {
		...e("tabs", "panel"),
		value: t,
		className: m,
		children: r
	});
}
function y({ label: e, tabs: n, value: r, defaultValue: i, onValueChange: o, truncate: c, size: d, renderPanel: f }) {
	let p = r === void 0 ? i ?? a(n) : void 0;
	return /* @__PURE__ */ u(t, {
		"data-component": s.id,
		value: r,
		defaultValue: p,
		onValueChange: o,
		className: "min-w-0",
		children: [/* @__PURE__ */ l(g, {
			label: e,
			tabs: n,
			truncate: c,
			size: d
		}), n.map((e) => /* @__PURE__ */ l(v, {
			value: e.value,
			children: f(e.value)
		}, e.value))]
	});
}
//#endregion
export { y as Tabs, g as TabsList, v as TabsPanel, _ as TabsRoot };
