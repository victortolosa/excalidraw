import { composerDefaults as e } from "./composer.runtime.js";
import { z as t } from "zod";
//#region src/components/composer/composer.contract.ts
var n = t.strictObject({
	label: t.string().regex(/\S/).describe("Accessible name; visible unless labelVisibility is hidden."),
	labelVisibility: t.enum(["visible", "hidden"]).default(e.labelVisibility).describe("hidden removes the label from view but keeps it as the accessible name. Use only when visible context already names the composer, such as a single composer under a heading, and the accessibility profile allows contextual labels."),
	description: t.string().regex(/\S/).optional().describe("Persistent guidance; remains visible when an error appears."),
	error: t.string().regex(/\S/).optional().describe("Actionable error text; sets aria-invalid and is associated with the input."),
	disabled: t.boolean().default(e.disabled),
	readOnly: t.boolean().default(e.readOnly),
	busy: t.boolean().default(e.busy).describe("Temporarily locks editing and Clear/Undo; the host disables its slot actions and prevents duplicate requests."),
	clearable: t.boolean().default(e.clearable).describe("Optional Clear with persistent Undo until the next edit, external draft replacement, form reset or busy/read-only transition. Controlled usage requires onValueChange."),
	clearLabel: t.string().regex(/\S/).default(e.clearLabel),
	undoLabel: t.string().regex(/\S/).default(e.undoLabel),
	required: t.boolean().default(e.required),
	maxLength: t.number().int().positive().optional().describe("Native textarea UTF-16 code-unit limit. Does not truncate externally supplied content."),
	maxRows: t.number().int().positive().optional().describe("Growth limit in lines of current typography, including editor padding. Defaults to at least rows or 12, whichever is greater."),
	status: t.string().regex(/\S/).optional().describe("Host-provided polite feedback. Does not imply autosave."),
	submissionError: t.string().regex(/\S/).optional().describe("Failed-request feedback; does not mark the draft invalid. Supply Retry through actions."),
	rows: t.number().int().positive().default(e.rows).describe("Minimum number of visible text lines; grows to maxRows and then scrolls.")
});
function r(e, t) {
	e.maxRows !== void 0 && e.maxRows < e.rows && t.addIssue({
		code: "custom",
		path: ["maxRows"],
		message: "maxRows must be at least rows."
	}), e.required && e.labelVisibility === "hidden" && t.addIssue({
		code: "custom",
		path: ["labelVisibility"],
		message: "Required composers need a visible label."
	});
}
n.superRefine(r).meta({
	title: "Composer",
	description: "A multiline text entry panel for composing one item, with optional toolbar above and actions below the text. Not for forms with several fields; use TextField and Textarea."
});
//#endregion
export { r as composerConstraints, n as composerFieldsSchema };
