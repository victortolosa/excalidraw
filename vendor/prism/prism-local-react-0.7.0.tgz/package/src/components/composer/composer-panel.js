import { typographyProps as e } from "../../lib/typography.js";
import { Field as t, FieldDescription as n, FieldError as r, FieldLabel as i } from "../ui/field.js";
import { InputGroup as a } from "../ui/input-group.js";
import { composerDefaults as o } from "./composer.runtime.js";
import { jsx as s, jsxs as c } from "react/jsx-runtime";
//#region src/components/composer/composer-panel.tsx
function l({ label: l, labelVisibility: u = o.labelVisibility, required: d, disabled: f, readOnly: p, busy: m, description: h, error: g, submissionError: _, status: v, inputId: y, announcement: b, headerActions: x, toolbar: S, secondaryActions: C, actions: w, children: T, onLabelClick: E, component: D = "composer" }) {
	let O = u === "visible" || !p && !!x;
	return /* @__PURE__ */ s(t, {
		"data-component": D,
		"data-invalid": !!g,
		"data-disabled": f,
		className: "min-w-0",
		children: /* @__PURE__ */ c(a, {
			"aria-busy": m || void 0,
			className: "h-auto flex-col rounded-panel p-4 pt-2 bg-card text-card-foreground dark:bg-card has-disabled:bg-card has-disabled:opacity-100 dark:has-disabled:bg-card has-[[data-slot=input-group-control]:focus-visible]:border-ring has-[[data-slot=input-group-control]:focus-visible]:ring-ring",
			children: [
				O && /* @__PURE__ */ c("div", {
					className: "flex min-h-11 w-full min-w-0 flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ c(i, {
						...e("textarea", "label"),
						id: `${y}-label`,
						htmlFor: y,
						onClick: E,
						className: u === "hidden" ? "sr-only" : "min-w-0 flex-1 break-words",
						children: [l, d && /* @__PURE__ */ s("span", {
							"aria-hidden": "true",
							children: " (required)"
						})]
					}), !p && /* @__PURE__ */ s("div", {
						className: "flex flex-wrap items-center gap-2",
						children: x
					})]
				}),
				!O && /* @__PURE__ */ s(i, {
					...e("textarea", "label"),
					id: `${y}-label`,
					htmlFor: y,
					onClick: E,
					className: "sr-only",
					children: l
				}),
				!p && S && /* @__PURE__ */ s("div", {
					className: "flex w-full flex-wrap items-center gap-2 pb-3",
					children: S
				}),
				T,
				/* @__PURE__ */ c("div", {
					className: "w-full space-y-2",
					"aria-live": "polite",
					"aria-atomic": "true",
					children: [
						h && /* @__PURE__ */ s(n, {
							...e("textarea", "description"),
							id: `${y}-description`,
							className: "break-words",
							children: h
						}),
						g && /* @__PURE__ */ s(r, {
							...e("textarea", "error"),
							id: `${y}-error`,
							className: "break-words",
							children: g
						}),
						_ && /* @__PURE__ */ s(r, {
							...e("textarea", "error"),
							id: `${y}-submission-error`,
							className: "break-words",
							children: _
						}),
						v && /* @__PURE__ */ s("p", {
							...e("textarea", "description"),
							className: "text-muted-foreground",
							children: v
						}),
						/* @__PURE__ */ s("span", {
							className: "sr-only",
							children: b
						})
					]
				}),
				!p && (C || w) && /* @__PURE__ */ c("div", {
					className: "flex w-full flex-wrap items-center justify-between gap-3 pt-3",
					children: [C && /* @__PURE__ */ s("div", {
						className: "min-w-0",
						children: C
					}), w && /* @__PURE__ */ s("div", {
						className: "ml-auto flex min-w-0 flex-wrap items-center gap-2",
						children: w
					})]
				})
			]
		})
	});
}
//#endregion
export { l as ComposerPanel };
