//#region src/components/composer/composer.runtime.ts
var e = {
	labelVisibility: "visible",
	disabled: !1,
	readOnly: !1,
	busy: !1,
	clearable: !1,
	rows: 3,
	maxRows: 12,
	clearLabel: "Clear",
	undoLabel: "Undo",
	required: !1
};
//#endregion
export { e as composerDefaults };
