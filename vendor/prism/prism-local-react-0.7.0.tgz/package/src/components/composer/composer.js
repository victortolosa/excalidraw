import { typographyProps as e } from "../../lib/typography.js";
import { Button as t } from "../button/button.js";
import { InputGroupTextarea as n } from "../ui/input-group.js";
import { composerDefaults as r } from "./composer.runtime.js";
import { ComposerPanel as i } from "./composer-panel.js";
import { useEffect as a, useId as o, useImperativeHandle as s, useLayoutEffect as c, useRef as l, useState as u } from "react";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
//#region src/components/composer/composer.tsx
function m({ label: m, labelVisibility: h = r.labelVisibility, description: g, error: _, submissionError: v, status: y, id: b, rows: x = r.rows, maxRows: S, maxLength: C, required: w = r.required, disabled: T = r.disabled, readOnly: E = r.readOnly, busy: D = r.busy, clearable: O = r.clearable, clearLabel: ee = r.clearLabel, undoLabel: k = r.undoLabel, headerActions: A, toolbar: j, secondaryActions: M, actions: N, value: P, defaultValue: F = "", onValueChange: I, onChange: te, ref: ne, ...L }) {
	let R = o(), z = b ?? R, B = l(null), [V, H] = u(F), [U, W] = u(), [G, K] = u(""), q = P ?? V, J = T || E || D, Y = [
		g && `${z}-description`,
		_ && `${z}-error`,
		v && `${z}-submission-error`
	].filter(Boolean).join(" ") || void 0;
	s(ne, () => B.current, []);
	let [X, re] = u({
		text: q,
		locked: J,
		clearable: O
	});
	(q !== X.text || J !== X.locked || O !== X.clearable) && (re({
		text: q,
		locked: J,
		clearable: O
	}), (q !== "" || J || !O) && (W(void 0), K("")));
	function Z(e) {
		P === void 0 && H(e), I?.(e);
	}
	a(() => {
		let e = B.current?.form;
		if (!e) return;
		let t = (e) => {
			queueMicrotask(() => {
				e.defaultPrevented || (W(void 0), K(""), P === void 0 && (H(F), I?.(F)));
			});
		};
		return e.addEventListener("reset", t), () => e.removeEventListener("reset", t);
	}, [
		P,
		F,
		I,
		L.form
	]), c(() => {
		let e = B.current;
		if (!e) return;
		function t() {
			let t = e, n = getComputedStyle(t), i = parseFloat(n.lineHeight), a = parseFloat(n.paddingTop) + parseFloat(n.paddingBottom), o = parseFloat(n.borderTopWidth) + parseFloat(n.borderBottomWidth), s = x * i + a + o, c = (S ?? Math.max(x, r.maxRows)) * i + a + o;
			t.style.height = "auto", t.style.height = `${Math.min(c, Math.max(s, t.scrollHeight + o))}px`, t.style.overflowY = t.scrollHeight + o > c ? "auto" : "hidden";
		}
		t();
		let n = e.clientWidth, i = new ResizeObserver(() => {
			e.clientWidth !== n && (n = e.clientWidth, t());
		});
		i.observe(e);
		let a = new MutationObserver(t);
		for (let t = e.parentElement; t; t = t.parentElement) a.observe(t, {
			attributes: !0,
			attributeFilter: [
				"data-density",
				"data-mode",
				"class",
				"style"
			]
		});
		return window.addEventListener("resize", t), document.fonts?.addEventListener("loadingdone", t), () => {
			i.disconnect(), a.disconnect(), window.removeEventListener("resize", t), document.fonts?.removeEventListener("loadingdone", t);
		};
	}, [
		q,
		x,
		S
	]);
	function ie() {
		!J && q && (W(q), Z(""), K("Draft cleared. Undo is available until the next edit."), B.current?.focus());
	}
	function ae() {
		J || U === void 0 || q !== "" || (Z(U), W(void 0), K("Draft restored."), B.current?.focus());
	}
	let Q = U !== void 0 && q === "", $ = !E && O && (q !== "" || Q);
	return /* @__PURE__ */ f(i, {
		label: m,
		labelVisibility: h,
		required: w,
		disabled: T,
		readOnly: E,
		busy: D,
		description: g,
		error: _,
		submissionError: v,
		status: y,
		inputId: z,
		announcement: G,
		toolbar: j,
		secondaryActions: M,
		actions: N,
		headerActions: A || $ ? /* @__PURE__ */ p(d, { children: [A, $ && (Q ? /* @__PURE__ */ f(t, {
			variant: "ghost",
			disabled: J,
			onClick: ae,
			children: k
		}) : /* @__PURE__ */ f(t, {
			variant: "ghost",
			disabled: J,
			onClick: ie,
			children: ee
		}))] }) : void 0,
		children: /* @__PURE__ */ f(n, {
			...e("textarea", "control"),
			...L,
			ref: B,
			id: z,
			rows: x,
			value: q,
			maxLength: C,
			required: w,
			disabled: T,
			readOnly: E || D,
			"aria-invalid": _ ? !0 : void 0,
			"aria-describedby": Y,
			className: "min-h-0 flex-none field-sizing-fixed px-0 text-foreground",
			onChange: (e) => {
				W(void 0), K(""), Z(e.target.value), te?.(e);
			}
		})
	});
}
//#endregion
export { m as Composer };
