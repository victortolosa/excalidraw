import { typographyProps as e } from "../../lib/typography.js";
import { Field as t, FieldDescription as n, FieldError as r, FieldLabel as i } from "../ui/field.js";
import { Textarea as a } from "../ui/textarea.js";
import { textareaDefaults as o } from "./textarea.runtime.js";
import { useId as s } from "react";
import { jsx as c, jsxs as l } from "react/jsx-runtime";
//#region src/components/textarea/textarea.tsx
function u({ label: u, labelVisibility: d = o.labelVisibility, description: f, error: p, id: m, rows: h, required: g = o.required, disabled: _ = o.disabled, readOnly: v = o.readOnly, ...y }) {
	let b = s(), x = m ?? b, S = [f && `${x}-description`, p && `${x}-error`].filter(Boolean).join(" ") || void 0;
	return /* @__PURE__ */ l(t, {
		"data-component": "textarea",
		"data-invalid": !!p,
		"data-disabled": _,
		className: "min-w-0",
		children: [
			/* @__PURE__ */ l(i, {
				...e("textarea", "label"),
				htmlFor: x,
				className: d === "hidden" ? "sr-only" : "break-words",
				children: [u, g && /* @__PURE__ */ c("span", {
					"aria-hidden": "true",
					children: " (required)"
				})]
			}),
			/* @__PURE__ */ c(a, {
				...e("textarea", "control"),
				...y,
				id: x,
				rows: h,
				required: g,
				disabled: _,
				readOnly: v,
				"aria-invalid": p ? !0 : void 0,
				"aria-describedby": S,
				className: "text-foreground focus-visible:ring-ring aria-invalid:focus-visible:ring-ring"
			}),
			f && /* @__PURE__ */ c(n, {
				...e("textarea", "description"),
				id: `${x}-description`,
				className: "break-words",
				children: f
			}),
			p && /* @__PURE__ */ c(r, {
				...e("textarea", "error"),
				id: `${x}-error`,
				className: "break-words",
				children: p
			})
		]
	});
}
//#endregion
export { u as Textarea };
