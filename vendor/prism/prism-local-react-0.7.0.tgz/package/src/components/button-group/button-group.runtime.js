//#region src/components/button-group/button-group.runtime.ts
var e = { orientation: "horizontal" };
//#endregion
export { e as buttonGroupDefaults };
