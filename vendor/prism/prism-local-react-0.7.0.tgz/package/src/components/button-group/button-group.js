import { Button as e } from "../button/button.js";
import { ButtonGroup as t } from "../ui/button-group.js";
import { buttonSchema as n } from "../button/button.contract.js";
import { buttonGroupDefaults as r } from "./button-group.runtime.js";
import { jsx as i } from "react/jsx-runtime";
//#region src/components/button-group/button-group.tsx
function a({ label: a, items: o, orientation: s = r.orientation, onAction: c }) {
	return /* @__PURE__ */ i(t, {
		"data-component": "button-group",
		"aria-label": a,
		orientation: s,
		className: "max-w-full min-w-0 [&>button]:min-w-0 [&>button]:flex-1 [&>button]:wrap-anywhere",
		children: o.map((t) => {
			let r = n.parse(t.button), a = r.loading ? {
				loading: !0,
				disabled: !1
			} : {
				loading: !1,
				disabled: r.disabled
			};
			return /* @__PURE__ */ i(e, {
				...r,
				...a,
				onClick: () => c(t.id)
			}, t.id);
		})
	});
}
//#endregion
export { a as ButtonGroup };
