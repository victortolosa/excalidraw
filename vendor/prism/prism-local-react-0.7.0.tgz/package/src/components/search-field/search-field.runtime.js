//#region src/components/search-field/search-field.runtime.ts
var e = {
	labelVisibility: "visible",
	disabled: !1,
	readOnly: !1
};
//#endregion
export { e as searchFieldDefaults };
