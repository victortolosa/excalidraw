import { typographyProps as e } from "../../lib/typography.js";
import { Field as t, FieldDescription as n, FieldError as r, FieldLabel as i } from "../ui/field.js";
import { InputGroup as a, InputGroupAddon as o, InputGroupInput as s } from "../ui/input-group.js";
import { IconButton as c } from "../icon-button/icon-button.js";
import { searchFieldDefaults as l } from "./search-field.runtime.js";
import { useId as u, useImperativeHandle as d, useRef as f } from "react";
import { Search as p } from "lucide-react";
import { jsx as m, jsxs as h } from "react/jsx-runtime";
//#region src/components/search-field/search-field.tsx
function g({ label: g, labelVisibility: _ = l.labelVisibility, placeholder: v, description: y, error: b, id: x, disabled: S = l.disabled, readOnly: C = l.readOnly, onClear: w, ref: T, ...E }) {
	let D = f(null);
	d(T, () => D.current, []);
	let O = u(), k = x ?? O, A = [y && `${k}-description`, b && `${k}-error`].filter(Boolean).join(" ") || void 0;
	return /* @__PURE__ */ h(t, {
		"data-component": "search-field",
		"data-invalid": !!b,
		"data-disabled": S,
		className: "min-w-0",
		children: [
			/* @__PURE__ */ m(i, {
				...e("search-field", "label"),
				htmlFor: k,
				className: _ === "hidden" ? "sr-only" : "break-words",
				children: g
			}),
			/* @__PURE__ */ h(a, {
				className: "transition-none has-[[data-slot=input-group-control]:focus-visible]:ring-ring has-[[data-slot=input-group-control]:focus-visible]:border-ring",
				children: [
					/* @__PURE__ */ m(s, {
						ref: D,
						...e("search-field", "control"),
						...E,
						id: k,
						type: "search",
						placeholder: v,
						disabled: S,
						readOnly: C,
						"aria-invalid": b ? !0 : void 0,
						"aria-describedby": A,
						className: "text-foreground transition-none"
					}),
					/* @__PURE__ */ m(o, {
						align: "inline-start",
						"aria-hidden": "true",
						children: /* @__PURE__ */ m(p, { "aria-hidden": "true" })
					}),
					w && !!E.value && !S && !C && /* @__PURE__ */ m(o, {
						align: "inline-end",
						children: /* @__PURE__ */ m(c, {
							icon: "close",
							label: `Clear ${g}`,
							variant: "secondary",
							onClick: () => {
								w(), D.current?.focus();
							}
						})
					})
				]
			}),
			y && /* @__PURE__ */ m(n, {
				...e("search-field", "description"),
				id: `${k}-description`,
				className: "break-words",
				children: y
			}),
			b && /* @__PURE__ */ m(r, {
				...e("search-field", "error"),
				id: `${k}-error`,
				className: "break-words",
				children: b
			})
		]
	});
}
//#endregion
export { g as SearchField };
