//#region src/components/icon-button/icon-button.meta.ts
var e = {
	id: "icon-button",
	name: "IconButton",
	status: "experimental",
	sources: {
		contract: "src/components/icon-button/icon-button.contract.ts",
		implementation: "src/components/icon-button/icon-button.tsx",
		guidance: "src/components/icon-button/icon-button.mdx",
		fixtures: "src/components/icon-button/icon-button.fixtures.ts",
		stories: "src/components/icon-button/icon-button.stories.tsx",
		catalog: "src/components/ui/button.tsx"
	},
	tokens: [
		"primary",
		"primary-foreground",
		"background",
		"foreground",
		"border",
		"input",
		"muted",
		"ring"
	],
	origin: {
		kind: "shadcn-wrapper",
		catalogSources: ["catalog"]
	},
	dependencies: []
};
//#endregion
export { e as iconButtonMeta };
