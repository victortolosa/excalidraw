//#region src/components/icon-button/icon-button.runtime.ts
var e = {
	variant: "secondary",
	type: "button",
	disabled: !1
};
//#endregion
export { e as iconButtonDefaults };
