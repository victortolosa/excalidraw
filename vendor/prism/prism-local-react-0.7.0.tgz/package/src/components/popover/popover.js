import { typographyProps as e } from "../../lib/typography.js";
import { Popover as t, PopoverContent as n, PopoverTrigger as r } from "../ui/popover.js";
import { popoverDefaults as i } from "./popover.runtime.js";
import { useId as a } from "react";
import { jsx as o, jsxs as s } from "react/jsx-runtime";
//#region src/components/popover/popover.tsx
function c({ title: c, description: l, trigger: u, children: d, side: f = i.side, align: p = i.align, defaultOpen: m = i.defaultOpen, ...h }) {
	let g = a(), _ = a();
	return /* @__PURE__ */ s(t, {
		...h,
		defaultOpen: m,
		children: [/* @__PURE__ */ o(r, {
			asChild: !0,
			children: u
		}), /* @__PURE__ */ s(n, {
			"data-component": "popover",
			tabIndex: 0,
			side: f,
			align: p,
			"aria-labelledby": g,
			"aria-describedby": l ? _ : void 0,
			className: "max-w-[calc(100vw-2rem)] max-h-(--radix-popover-content-available-height) overflow-y-auto wrap-anywhere focus-visible:ring-2 focus-visible:ring-ring",
			children: [
				/* @__PURE__ */ o("h2", {
					...e("popover", "title"),
					id: g,
					className: "font-heading font-semibold",
					children: c
				}),
				l && /* @__PURE__ */ o("p", {
					...e("popover", "description"),
					id: _,
					className: "text-muted-foreground",
					children: l
				}),
				/* @__PURE__ */ o("div", {
					...e("popover", "body"),
					className: "contents",
					children: d
				})
			]
		})]
	});
}
//#endregion
export { c as Popover };
