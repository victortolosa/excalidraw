//#region src/components/popover/popover.runtime.ts
var e = {
	defaultOpen: !1,
	side: "bottom",
	align: "center"
};
//#endregion
export { e as popoverDefaults };
