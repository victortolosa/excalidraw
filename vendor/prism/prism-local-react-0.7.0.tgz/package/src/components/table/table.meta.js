//#region src/components/table/table.meta.ts
var e = {
	id: "table",
	name: "Table",
	status: "experimental",
	sources: {
		contract: "src/components/table/table.contract.ts",
		implementation: "src/components/table/table.tsx",
		guidance: "src/components/table/table.mdx",
		fixtures: "src/components/table/table.fixtures.ts",
		stories: "src/components/table/table.stories.tsx",
		catalog: "src/components/ui/table.tsx"
	},
	tokens: [
		"border",
		"foreground",
		"muted",
		"muted-foreground"
	],
	origin: {
		kind: "shadcn-wrapper",
		catalogSources: ["catalog"]
	},
	dependencies: []
};
//#endregion
export { e as tableMeta };
