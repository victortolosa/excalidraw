import { typographyProps as e } from "../../lib/typography.js";
import { Table as t, TableBody as n, TableCaption as r, TableCell as i, TableHead as a, TableHeader as o, TableRow as s } from "../ui/table.js";
import { tableColumnDefaults as c, tableDefaults as l } from "./table.runtime.js";
import { tableMeta as u } from "./table.meta.js";
import { createElement as d } from "react";
import { jsx as f, jsxs as p } from "react/jsx-runtime";
//#region src/components/table/table.tsx
var m = {
	start: "text-start",
	end: "text-end"
}, h = "whitespace-normal wrap-anywhere";
function g({ caption: g, hideCaption: _ = l.hideCaption, columns: v, rows: y, emptyMessage: b = l.emptyMessage, renderCell: x }) {
	return /* @__PURE__ */ p(t, {
		"data-component": u.id,
		className: "caption-top",
		children: [
			/* @__PURE__ */ f(r, {
				...e("table", "caption"),
				className: _ ? "sr-only" : "mt-0 mb-2 text-start",
				children: g
			}),
			/* @__PURE__ */ f(o, { children: /* @__PURE__ */ f(s, { children: v.map((t) => /* @__PURE__ */ d(a, {
				...e("table", "header"),
				key: t.key,
				scope: "col",
				className: `${h} ${m[t.align ?? c.align]}`
			}, t.header)) }) }),
			/* @__PURE__ */ f(n, { children: y.length === 0 ? /* @__PURE__ */ f(s, { children: /* @__PURE__ */ f(i, {
				...e("table", "empty"),
				colSpan: v.length,
				className: `${h} py-6 text-center text-muted-foreground`,
				children: b
			}) }) : y.map((t) => /* @__PURE__ */ f(s, { children: v.map((n, r) => {
				let o = x?.(n.key, t), s = o === void 0 ? t[n.key] : o, l = `${h} ${m[n.align ?? c.align]}`;
				return r === 0 ? /* @__PURE__ */ d(a, {
					...e("table", "row-header"),
					key: n.key,
					scope: "row",
					className: `h-auto p-2 ${l}`
				}, s) : /* @__PURE__ */ d(i, {
					...e("table", "cell"),
					key: n.key,
					className: l
				}, s);
			}) }, t.id)) })
		]
	});
}
//#endregion
export { g as Table };
