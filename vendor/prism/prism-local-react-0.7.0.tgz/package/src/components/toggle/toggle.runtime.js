//#region src/components/toggle/toggle.runtime.ts
var e = {
	variant: "plain",
	disabled: !1,
	pending: !1,
	defaultPressed: !1
};
//#endregion
export { e as toggleDefaults };
