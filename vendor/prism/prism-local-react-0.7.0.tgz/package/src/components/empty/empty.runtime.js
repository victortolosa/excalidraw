//#region src/components/empty/empty.runtime.ts
var e = { headingLevel: "3" };
//#endregion
export { e as emptyDefaults };
