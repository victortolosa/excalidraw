import { typographyProps as e } from "../../lib/typography.js";
import { Empty as t, EmptyContent as n, EmptyDescription as r, EmptyHeader as i } from "../ui/empty.js";
import { emptyDefaults as a } from "./empty.runtime.js";
import { useId as o } from "react";
import { jsx as s, jsxs as c } from "react/jsx-runtime";
//#region src/components/empty/empty.tsx
function l({ title: l, description: u, headingLevel: d = a.headingLevel, children: f }) {
	let p = o(), m = `h${d}`;
	return /* @__PURE__ */ c(t, {
		"data-component": "empty",
		role: "group",
		"aria-labelledby": p,
		children: [/* @__PURE__ */ c(i, { children: [/* @__PURE__ */ s(m, {
			...e("empty", "title"),
			id: p,
			className: "font-heading text-sm font-medium tracking-tight",
			children: l
		}), u && /* @__PURE__ */ s(r, {
			...e("empty", "description"),
			children: u
		})] }), f && /* @__PURE__ */ s(n, {
			...e("empty", "body"),
			children: f
		})]
	});
}
//#endregion
export { l as Empty };
