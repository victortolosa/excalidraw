import { isSafeRichTextLink as e } from "./rich-text-composer.runtime.js";
import { marked as t } from "marked";
//#region src/components/rich-text-composer/rich-text-composer.markdown.ts
var n = /* @__PURE__ */ new Set([
	"space",
	"paragraph",
	"text",
	"heading",
	"list",
	"list_item",
	"strong",
	"em",
	"link",
	"br",
	"escape",
	"def"
]);
function r(r) {
	t.walkTokens(t.lexer(r), (t) => {
		if (t.type !== "html" || t.raw.trim() !== "&nbsp;") {
			if (!n.has(t.type)) throw Error(`Unsupported Markdown syntax: ${t.type}.`);
			if (t.type === "heading" && t.depth > 3) throw Error("Markdown headings support levels 1–3.");
			if (t.type === "list_item" && t.task) throw Error("Markdown task lists are not supported.");
			if ((t.type === "link" || t.type === "def") && !e(t.href)) throw Error("Use an absolute http, https or mailto URL.");
			if ((t.type === "link" || t.type === "def") && t.title) throw Error("Markdown link titles are not supported.");
		}
	});
}
//#endregion
export { r as validateRichTextMarkdown };
