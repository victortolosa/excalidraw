import { emptyRichTextDocument as e, isSafeRichTextLink as t } from "./rich-text-composer.runtime.js";
import { validateRichTextMarkdown as n } from "./rich-text-composer.markdown.js";
import { richTextDocumentSchema as r } from "./rich-text-composer.contract.js";
import "@tiptap/core";
import i from "@tiptap/starter-kit";
import { MarkdownManager as a } from "@tiptap/markdown";
//#region src/components/rich-text-composer/rich-text-composer.document.ts
var o = [i.configure({
	heading: { levels: [
		1,
		2,
		3
	] },
	blockquote: !1,
	code: !1,
	codeBlock: !1,
	horizontalRule: !1,
	strike: !1,
	underline: !1,
	trailingNode: !1,
	link: {
		openOnClick: !1,
		autolink: !1,
		linkOnPaste: !1,
		isAllowedUri: t,
		HTMLAttributes: {
			target: null,
			rel: "noopener noreferrer"
		}
	}
})];
function s(e) {
	let t = (e) => ({
		type: e.type,
		...e.text === void 0 ? {} : { text: e.text },
		...e.type === "heading" ? { attrs: { level: e.attrs?.level } } : {},
		...e.type === "orderedList" ? { attrs: { start: e.attrs?.start ?? 1 } } : {},
		...e.marks ? { marks: e.marks.map((e) => e.type === "link" ? {
			type: "link",
			attrs: { href: e.attrs?.href }
		} : { type: e.type }) } : {},
		...e.content ? { content: e.content.map(t) } : {}
	});
	return r.parse(t(e));
}
var c;
function l() {
	return c ??= new a({ extensions: o });
}
function u(t, i) {
	if (i === "json") return r.parse(t ?? e);
	if (t !== void 0 && typeof t != "string") throw Error("Markdown format requires a string value.");
	let a = t ?? "";
	n(a);
	let o = l().parse(a);
	return s(o.content?.length ? o : e);
}
function d(e) {
	return l().serialize(r.parse(e));
}
//#endregion
export { u as parseRichTextValue, s as portable, o as richTextExtensions, d as serializeRichTextMarkdown };
