import { composerConstraints as e, composerFieldsSchema as t } from "../composer/composer.contract.js";
import { isSafeRichTextLink as n } from "./rich-text-composer.runtime.js";
import { validateRichTextMarkdown as r } from "./rich-text-composer.markdown.js";
import { z as i } from "zod";
//#region src/components/rich-text-composer/rich-text-composer.contract.ts
var a = i.union([
	i.strictObject({ type: i.literal("bold") }),
	i.strictObject({ type: i.literal("italic") }),
	i.strictObject({
		type: i.literal("link"),
		attrs: i.strictObject({ href: i.string().refine(n, "Use an absolute http, https or mailto URL.") })
	})
]), o = i.union([i.strictObject({
	type: i.literal("text"),
	text: i.string().min(1),
	marks: i.array(a).optional()
}), i.strictObject({ type: i.literal("hardBreak") })]), s = i.strictObject({
	type: i.literal("paragraph"),
	content: i.array(o).optional()
}), c = i.strictObject({
	type: i.literal("heading"),
	attrs: i.strictObject({ level: i.union([
		i.literal(1),
		i.literal(2),
		i.literal(3)
	]) }),
	content: i.array(o).optional()
}), l = i.lazy(() => i.union([i.strictObject({
	type: i.literal("bulletList"),
	content: i.array(u).min(1)
}), i.strictObject({
	type: i.literal("orderedList"),
	attrs: i.strictObject({ start: i.number().int().positive() }).optional(),
	content: i.array(u).min(1)
})])), u = i.lazy(() => i.strictObject({
	type: i.literal("listItem"),
	content: i.tuple([s]).rest(i.union([s, l]))
})), d = i.strictObject({
	type: i.literal("doc"),
	content: i.array(i.union([
		s,
		c,
		l
	])).min(1)
}), f = t.omit({
	maxLength: !0,
	required: !0
}), p = i.string().superRefine((e, t) => {
	try {
		r(e);
	} catch (e) {
		t.addIssue({
			code: "custom",
			message: e instanceof Error ? e.message : "Invalid Markdown."
		});
	}
});
f.extend({
	format: i.enum(["json", "markdown"]).optional().describe("Input/output format. Defaults to json; markdown uses strings with the same visual toolbar."),
	defaultValue: i.union([d, p]).optional().describe("Initial document for json, or supported Markdown string for markdown.")
}).superRefine((t, n) => {
	e(t, n), t.defaultValue !== void 0 && typeof t.defaultValue == "string" != (t.format === "markdown") && n.addIssue({
		code: "custom",
		path: ["defaultValue"],
		message: "defaultValue must match the selected format."
	});
}).meta({
	title: "RichTextComposer",
	description: "Text editing with JSON or Markdown input/output, headings, bold, italic, lists and links in the shared Composer panel. Use Composer for plain text; images are not supported."
});
//#endregion
export { d as richTextDocumentSchema };
