//#region src/components/rich-text-composer/rich-text-composer.runtime.ts
var e = {
	type: "doc",
	content: [{ type: "paragraph" }]
};
function t(e) {
	if (/\s/.test(e) || Array.from(e).some((e) => e.charCodeAt(0) < 32 || e.charCodeAt(0) === 127)) return !1;
	try {
		let t = new URL(e);
		return t.protocol === "https:" || t.protocol === "http:" ? !!t.hostname : t.protocol === "mailto:" && t.pathname.length > 0;
	} catch {
		return !1;
	}
}
function n(e) {
	let t = (e) => (e.content ?? []).map((e) => e.type === "text" ? e.text : "\n").join(""), n = (e) => e.type === "paragraph" || e.type === "heading" ? t(e) : e.content.map((e) => e.content.map(n).join("\n")).join("\n");
	return e.content.map(n).join("\n");
}
//#endregion
export { e as emptyRichTextDocument, t as isSafeRichTextLink, n as richTextContentText };
