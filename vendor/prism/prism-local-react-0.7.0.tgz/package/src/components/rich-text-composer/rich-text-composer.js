import { typographyProps as e } from "../../lib/typography.js";
import { Button as t } from "../button/button.js";
import { composerDefaults as n } from "../composer/composer.runtime.js";
import { ComposerPanel as r } from "../composer/composer-panel.js";
import { DropdownMenu as i, DropdownMenuContent as a, DropdownMenuRadioGroup as ee, DropdownMenuRadioItem as o, DropdownMenuTrigger as te } from "../ui/dropdown-menu.js";
import { Dialog as ne } from "../dialog/dialog.js";
import { TextField as re } from "../text-field/text-field.js";
import { isSafeRichTextLink as ie, richTextContentText as ae } from "./rich-text-composer.runtime.js";
import "./rich-text-composer.contract.js";
import { parseRichTextValue as s, portable as c, richTextExtensions as oe, serializeRichTextMarkdown as l } from "./rich-text-composer.document.js";
import { useEffect as u, useId as se, useImperativeHandle as ce, useRef as d, useState as f } from "react";
import { Toolbar as p } from "radix-ui";
import { Bold as le, ChevronDown as ue, Italic as de, Link as fe, List as pe, ListOrdered as me, Redo2 as he, Undo2 as ge } from "lucide-react";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { EditorContent as _e, useEditor as ve, useEditorState as ye } from "@tiptap/react";
import "@tiptap/core";
import { EditorState as _ } from "@tiptap/pm/state";
import { closeHistory as v } from "@tiptap/pm/history";
//#region src/components/rich-text-composer/rich-text-composer.tsx
function y(e, t) {
	e.view.updateState(_.create({
		schema: e.schema,
		doc: e.schema.nodeFromJSON(t),
		plugins: e.state.plugins
	})), e.commands.setTextSelection(1);
}
function be(e, t, n) {
	let r = getComputedStyle(e), i = parseFloat(r.lineHeight), a = parseFloat(r.paddingTop) + parseFloat(r.paddingBottom);
	e.style.minHeight = `${t * i + a}px`, e.style.maxHeight = `${n * i + a}px`, e.style.overflowY = "auto";
}
var xe = "shrink-0 rounded-(--button-radius) border border-border bg-secondary text-secondary-foreground hover:bg-accent hover:text-accent-foreground focus-visible:outline-2 focus-visible:outline-ring disabled:opacity-50 data-[state=on]:bg-accent data-[state=on]:text-accent-foreground", b = `size-(--icon-button-size) ${xe}`;
function Se(_) {
	let { label: Se, labelVisibility: Ce = n.labelVisibility, description: x, error: S, submissionError: C, status: we, id: Te, rows: w = n.rows, maxRows: T, disabled: E = !1, readOnly: D = !1, busy: O = !1, clearable: k = !1, clearLabel: Ee = n.clearLabel, undoLabel: De = n.undoLabel, format: A = "json", value: j, defaultValue: M, ref: Oe, name: N, form: P, headerActions: F, secondaryActions: ke, actions: Ae } = _, je = se(), I = Te ?? je, L = E || D || O, R = d(null), z = d(null), Me = d(null), [B] = f(() => s(j ?? M, A)), V = d(null), H = d(() => {});
	u(() => {
		H.current = (e) => {
			if (_.format === "markdown") {
				let t = l(e);
				V.current = {
					format: "markdown",
					value: t,
					document: JSON.stringify(e)
				}, _.onValueChange?.(t);
			} else V.current = {
				format: "json",
				value: e,
				document: JSON.stringify(e)
			}, _.onValueChange?.(e);
		};
	}, [_.format, _.onValueChange]);
	let [Ne, U] = f(""), [Pe, Fe] = f(1), Ie = d({
		from: 1,
		to: 1
	}), W = d(!1), [Le, G] = f(!1), [K, Re] = f(""), [q, ze] = f(""), [Be, J] = f(), Y = d({
		from: 1,
		to: 1
	}), X = ve({
		extensions: oe,
		content: B,
		immediatelyRender: !1,
		editable: !L,
		onUpdate: ({ editor: e }) => {
			H.current?.(c(e.getJSON())), U("");
		},
		editorProps: { attributes: {
			role: "textbox",
			"aria-multiline": "true",
			id: I,
			"aria-labelledby": `${I}-label`,
			"data-typography": "textarea.control",
			"aria-readonly": String(D || O),
			"aria-disabled": String(E),
			tabindex: E ? "-1" : "0",
			"aria-invalid": S ? "true" : "false",
			"aria-describedby": [
				x && `${I}-description`,
				S && `${I}-error`,
				C && `${I}-submission-error`
			].filter(Boolean).join(" "),
			"data-slot": "input-group-control",
			class: "w-full min-w-0 break-words py-2 text-foreground outline-none [&_p]:m-0 [&_h1]:m-0 [&_h1]:font-heading [&_h1]:text-3xl [&_h1]:font-semibold [&_h2]:m-0 [&_h2]:font-heading [&_h2]:text-2xl [&_h2]:font-semibold [&_h3]:m-0 [&_h3]:font-heading [&_h3]:text-xl [&_h3]:font-semibold [&_ul]:list-disc [&_ul]:pl-6 [&_ol]:list-decimal [&_ol]:pl-6 [&_a]:text-primary [&_a]:underline"
		} }
	}), Z = ye({
		editor: X,
		selector: ({ editor: e }) => e ? {
			heading: [
				1,
				2,
				3
			].find((t) => e.isActive("heading", { level: t })),
			bold: e.isActive("bold"),
			italic: e.isActive("italic"),
			bulletList: e.isActive("bulletList"),
			orderedList: e.isActive("orderedList"),
			link: e.isActive("link"),
			undo: e.can().undo(),
			redo: e.can().redo(),
			empty: e.isEmpty,
			document: c(e.getJSON())
		} : null
	});
	ce(Oe, () => ({
		focus: () => X?.commands.focus(),
		getDocument: () => X ? c(X.getJSON()) : B,
		getText: () => ae(X ? c(X.getJSON()) : B),
		getMarkdown: () => l(X ? c(X.getJSON()) : B)
	}), [X, B]), u(() => {
		X && (X.setEditable(!L, !1), Me.current = X.view.dom);
	}, [
		X,
		L,
		E,
		D,
		O,
		I,
		x,
		S,
		C
	]), u(() => {
		if (!X || j === void 0) return;
		let e = JSON.stringify(c(X.getJSON())), t = V.current;
		if (t?.format === A && t.value === j && t.document === e) return;
		let n = c(X.schema.nodeFromJSON(s(j, A)).toJSON());
		JSON.stringify(n) !== e && y(X, n);
	}, [
		X,
		j,
		A
	]), u(() => {
		if (!X || !z.current) return;
		let e = X.view.dom;
		function t() {
			be(e, w, T ?? Math.max(w, n.maxRows));
		}
		t();
		let r = new MutationObserver(t);
		for (let e = z.current; e; e = e.parentElement) r.observe(e, {
			attributes: !0,
			attributeFilter: [
				"data-density",
				"data-mode",
				"class",
				"style"
			]
		});
		return window.addEventListener("resize", t), () => {
			r.disconnect(), window.removeEventListener("resize", t);
		};
	}, [
		X,
		w,
		T
	]), u(() => {
		if (!X) return;
		let e = R.current?.form ?? z.current?.closest("form");
		if (!e) return;
		let t = (e) => queueMicrotask(() => {
			if (e.defaultPrevented || X.isDestroyed) return;
			let t = s(j ?? M, A);
			y(X, t), j === void 0 && H.current?.(c(X.getJSON())), U(""), G(!1);
		});
		return e.addEventListener("reset", t), () => e.removeEventListener("reset", t);
	}, [
		X,
		j,
		M,
		P,
		A
	]);
	let Ve = (e) => {
		if (!X || L) return;
		X.view.dispatch(v(X.state.tr));
		let t = X.chain().focus();
		e === "bold" && t.toggleBold().run(), e === "italic" && t.toggleItalic().run(), e === "bulletList" && t.toggleBulletList().run(), e === "orderedList" && t.toggleOrderedList().run();
	};
	function He() {
		X && !L && (X.isActive("link") && X.commands.extendMarkRange("link"), Y.current = {
			from: X.state.selection.from,
			to: X.state.selection.to
		}, Re(X.state.doc.textBetween(Y.current.from, Y.current.to, " ")), ze(X.getAttributes("link").href ?? ""), J(void 0), G(!0));
	}
	function Ue() {
		G(!1), X && !X.isDestroyed && X.chain().focus().setTextSelection(Y.current).run();
	}
	function We() {
		if (!X || L) return Promise.reject(/* @__PURE__ */ Error("Editor unavailable"));
		if (!K.trim() || !ie(q)) return J(K.trim() ? "Use an absolute http, https or mailto URL." : "Enter link text."), Promise.reject(/* @__PURE__ */ Error("Invalid link"));
		J(void 0), X.view.dispatch(v(X.state.tr)), X.chain().focus().insertContentAt(Y.current, {
			type: "text",
			text: K,
			marks: [{
				type: "link",
				attrs: { href: q }
			}]
		}).setTextSelection(Y.current.from + K.length).command(({ tr: e }) => (e.setStoredMarks([]), !0)).run(), Y.current = {
			from: X.state.selection.from,
			to: X.state.selection.to
		};
	}
	let Q = Z?.heading ?? Pe, $ = Z?.empty ?? X?.isEmpty ?? !0, Ge = X && /* @__PURE__ */ g(p.Root, {
		"aria-label": "Text formatting",
		className: "flex w-full gap-1 overflow-x-auto py-1",
		loop: !0,
		onFocusCapture: (e) => e.target.scrollIntoView({
			block: "nearest",
			inline: "nearest"
		}),
		children: [
			/* @__PURE__ */ g("div", {
				className: "flex shrink-0",
				role: "group",
				"aria-label": "Heading style",
				children: [/* @__PURE__ */ g(p.Button, {
					"aria-label": `Toggle heading ${Q}`,
					"aria-pressed": !!Z?.heading,
					disabled: L || !X.can().toggleHeading({ level: Q }),
					className: `${b} rounded-r-none data-[active=true]:bg-accent data-[active=true]:text-accent-foreground`,
					"data-active": !!Z?.heading,
					onClick: () => {
						X.view.dispatch(v(X.state.tr)), X.chain().focus().toggleHeading({ level: Q }).run(), Fe(Q);
					},
					children: ["H", Q]
				}), /* @__PURE__ */ g(i, {
					modal: !1,
					onOpenChange: (e) => {
						e && (Ie.current = {
							from: X.state.selection.from,
							to: X.state.selection.to
						}, W.current = !1);
					},
					children: [/* @__PURE__ */ h(te, {
						asChild: !0,
						children: /* @__PURE__ */ h(p.Button, {
							"aria-label": "Choose heading level",
							disabled: L,
							className: `h-(--icon-button-size) w-6 min-w-[1.5rem] ${xe} rounded-l-none border-l-0`,
							children: /* @__PURE__ */ h(ue, {
								"aria-hidden": "true",
								className: "mx-auto size-4"
							})
						})
					}), /* @__PURE__ */ h(a, {
						"aria-label": "Heading level",
						className: "max-w-[calc(100vw-2rem)]",
						onCloseAutoFocus: (e) => {
							W.current &&= (e.preventDefault(), X.commands.focus(), !1);
						},
						children: /* @__PURE__ */ g(ee, {
							value: Z?.heading ? String(Z.heading) : "paragraph",
							onValueChange: (e) => {
								if (L) return;
								X.view.dispatch(v(X.state.tr));
								let t = X.chain().setTextSelection(Ie.current);
								if (e === "paragraph") t.setParagraph().run();
								else {
									let n = Number(e);
									t.setHeading({ level: n }).run(), Fe(n);
								}
								W.current = !0;
							},
							children: [/* @__PURE__ */ h(o, {
								value: "paragraph",
								disabled: L || !X.can().setParagraph(),
								...e("dropdown-menu", "option"),
								children: "Paragraph"
							}), [
								1,
								2,
								3
							].map((t) => /* @__PURE__ */ g(o, {
								value: String(t),
								disabled: L || !X.can().setHeading({ level: t }),
								...e("dropdown-menu", "option"),
								children: ["Heading ", t]
							}, t))]
						})
					})]
				})]
			}),
			/* @__PURE__ */ h(p.ToggleGroup, {
				type: "multiple",
				value: [
					"bold",
					"italic",
					"bulletList",
					"orderedList"
				].filter((e) => Z?.[e]),
				onValueChange: () => {},
				className: "flex gap-1",
				children: [
					{
						key: "bold",
						label: "Bold",
						Icon: le
					},
					{
						key: "italic",
						label: "Italic",
						Icon: de
					},
					{
						key: "bulletList",
						label: "Bulleted list",
						Icon: pe
					},
					{
						key: "orderedList",
						label: "Numbered list",
						Icon: me
					}
				].map(({ key: e, label: t, Icon: n }) => /* @__PURE__ */ h(p.ToggleItem, {
					value: e,
					"aria-label": t,
					disabled: L,
					className: b,
					onClick: () => Ve(e),
					onFocus: (e) => e.currentTarget.scrollIntoView({
						block: "nearest",
						inline: "nearest"
					}),
					children: /* @__PURE__ */ h(n, {
						"aria-hidden": "true",
						className: "mx-auto size-4"
					})
				}, e))
			}),
			/* @__PURE__ */ h(p.Button, {
				"aria-label": "Edit link",
				"aria-haspopup": "dialog",
				"aria-expanded": Le,
				disabled: L,
				className: b,
				onClick: He,
				children: /* @__PURE__ */ h(fe, {
					"aria-hidden": "true",
					className: "mx-auto size-4"
				})
			}),
			/* @__PURE__ */ h(p.Button, {
				"aria-label": "Undo edit",
				disabled: L || !Z?.undo,
				className: b,
				onClick: () => X.chain().focus().undo().run(),
				children: /* @__PURE__ */ h(ge, {
					"aria-hidden": "true",
					className: "mx-auto size-4"
				})
			}),
			/* @__PURE__ */ h(p.Button, {
				"aria-label": "Redo edit",
				disabled: L || !Z?.redo,
				className: b,
				onClick: () => X.chain().focus().redo().run(),
				children: /* @__PURE__ */ h(he, {
					"aria-hidden": "true",
					className: "mx-auto size-4"
				})
			})
		]
	});
	return /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g(r, {
		component: "rich-text-composer",
		label: Se,
		labelVisibility: Ce,
		description: x,
		error: S,
		submissionError: C,
		status: we,
		inputId: I,
		disabled: E,
		readOnly: D,
		busy: O,
		announcement: Ne,
		onLabelClick: () => X?.commands.focus(),
		toolbar: Ge,
		secondaryActions: ke,
		actions: Ae,
		headerActions: F || k && X && (!$ || Z?.undo) ? /* @__PURE__ */ g(m, { children: [F, k && X && ($ ? Z?.undo && /* @__PURE__ */ h(t, {
			variant: "ghost",
			disabled: L,
			onClick: () => {
				X.chain().focus().undo().run(), U("Draft restored.");
			},
			children: De
		}) : /* @__PURE__ */ h(t, {
			variant: "ghost",
			disabled: L,
			onClick: () => {
				X.view.dispatch(v(X.state.tr)), X.chain().focus().clearContent().run(), U("Draft cleared. Undo is available.");
			},
			children: Ee
		}))] }) : void 0,
		children: [/* @__PURE__ */ h("div", {
			ref: z,
			className: "w-full min-w-0",
			children: /* @__PURE__ */ h(_e, { editor: X })
		}), N && /* @__PURE__ */ h("input", {
			ref: R,
			type: "hidden",
			name: N,
			form: P,
			value: A === "markdown" ? l(Z?.document ?? B) : JSON.stringify(Z?.document ?? B)
		})]
	}), /* @__PURE__ */ h(ne, {
		title: "Edit link",
		description: "Set the text and destination for this link.",
		open: Le,
		onOpenChange: (e) => {
			e || Ue();
		},
		confirmLabel: "Save link",
		cancelLabel: "Cancel",
		error: Be,
		onConfirm: We,
		returnFocusRef: Me,
		children: /* @__PURE__ */ g("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ h(re, {
					label: "Link text",
					value: K,
					onChange: (e) => Re(e.target.value)
				}),
				/* @__PURE__ */ h(re, {
					label: "Destination",
					value: q,
					onChange: (e) => ze(e.target.value)
				}),
				Z?.link && /* @__PURE__ */ h(t, {
					variant: "secondary",
					onClick: () => {
						X?.chain().focus().setTextSelection(Y.current).unsetLink().run(), Ue();
					},
					children: "Remove link"
				})
			]
		})
	})] });
}
//#endregion
export { Se as RichTextComposer };
