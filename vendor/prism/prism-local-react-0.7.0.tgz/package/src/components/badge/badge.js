import { typographyProps as e } from "../../lib/typography.js";
import { Badge as t } from "../ui/badge.js";
import { badgeDefaults as n } from "./badge.runtime.js";
import { badgeMeta as r } from "./badge.meta.js";
import { RefreshCwIcon as i } from "lucide-react";
import { jsx as a, jsxs as o } from "react/jsx-runtime";
//#region src/components/badge/badge.tsx
var s = {
	neutral: "secondary",
	info: "secondary",
	success: "secondary",
	warning: "secondary",
	destructive: "destructive"
}, c = {
	info: "bg-info/10 text-info dark:bg-info/20",
	success: "bg-success/10 text-success dark:bg-success/20",
	warning: "bg-warning/10 text-warning dark:bg-warning/20"
}, l = "h-auto min-h-5 max-w-full whitespace-normal break-words text-center";
function u({ children: u, variant: d = n.variant, indicator: f }) {
	return /* @__PURE__ */ o(t, {
		variant: s[d],
		"data-component": r.id,
		...e("badge", "label"),
		"data-variant": d,
		className: [l, c[d]].filter(Boolean).join(" "),
		children: [
			f === "dot" && /* @__PURE__ */ a("span", {
				"aria-hidden": "true",
				"data-indicator": "dot",
				className: "size-1.5 shrink-0 rounded-full bg-current"
			}),
			f === "sync" && /* @__PURE__ */ a(i, {
				"aria-hidden": "true",
				"data-indicator": "sync",
				className: "motion-safe:animate-spin"
			}),
			u
		]
	});
}
//#endregion
export { u as Badge };
