//#region src/components/badge/badge.meta.ts
var e = {
	id: "badge",
	name: "Badge",
	status: "experimental",
	sources: {
		contract: "src/components/badge/badge.contract.ts",
		implementation: "src/components/badge/badge.tsx",
		guidance: "src/components/badge/badge.mdx",
		fixtures: "src/components/badge/badge.fixtures.ts",
		stories: "src/components/badge/badge.stories.tsx",
		catalog: "src/components/ui/badge.tsx"
	},
	tokens: [
		"destructive",
		"info",
		"secondary",
		"secondary-foreground",
		"success",
		"warning"
	],
	origin: {
		kind: "shadcn-wrapper",
		catalogSources: ["catalog"]
	},
	dependencies: []
};
//#endregion
export { e as badgeMeta };
