//#region src/components/badge/badge.runtime.ts
var e = { variant: "neutral" };
//#endregion
export { e as badgeDefaults };
