import { CircleCheckIcon as e, InfoIcon as t, Loader2Icon as n, OctagonXIcon as r, TriangleAlertIcon as i } from "lucide-react";
import { jsx as a } from "react/jsx-runtime";
import { Toaster as o } from "sonner";
import { useTheme as s } from "next-themes";
//#region src/components/ui/sonner.tsx
var c = ({ ...c }) => {
	let { theme: l = "system" } = s();
	return /* @__PURE__ */ a(o, {
		theme: l,
		className: "toaster group",
		icons: {
			success: /* @__PURE__ */ a(e, { className: "size-4" }),
			info: /* @__PURE__ */ a(t, { className: "size-4" }),
			warning: /* @__PURE__ */ a(i, { className: "size-4" }),
			error: /* @__PURE__ */ a(r, { className: "size-4" }),
			loading: /* @__PURE__ */ a(n, { className: "size-4 animate-spin" })
		},
		style: {
			"--normal-bg": "var(--popover)",
			"--normal-text": "var(--popover-foreground)",
			"--normal-border": "var(--border)",
			"--border-radius": "var(--radius)"
		},
		toastOptions: { classNames: { toast: "cn-toast" } },
		...c
	});
};
//#endregion
export { c as Toaster };
