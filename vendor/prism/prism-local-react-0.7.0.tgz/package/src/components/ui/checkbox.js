import "react";
import { cn as e } from "cn";
import { Checkbox as t } from "radix-ui";
import { CheckIcon as n } from "lucide-react";
import { jsx as r } from "react/jsx-runtime";
//#region src/components/ui/checkbox.tsx
function i({ className: i, ...a }) {
	return /* @__PURE__ */ r(t.Root, {
		"data-slot": "checkbox",
		className: e("peer relative flex size-4 shrink-0 items-center justify-center rounded-[4px] border border-input transition-colors outline-none group-has-disabled/field:opacity-50 group-has-[:focus-visible]/field-label:ring-0 group-has-[:focus-visible]/field-label:not-data-checked:border-input after:absolute after:-inset-x-3 after:-inset-y-2 focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 aria-invalid:aria-checked:border-primary dark:bg-input/30 dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40 data-checked:border-primary data-checked:bg-primary data-checked:text-primary-foreground group-has-[:focus-visible]/field-label:data-checked:border-primary dark:data-checked:bg-primary", i),
		...a,
		children: /* @__PURE__ */ r(t.Indicator, {
			"data-slot": "checkbox-indicator",
			className: "grid place-content-center text-current transition-none [&>svg]:size-3.5",
			children: /* @__PURE__ */ r(n, {})
		})
	});
}
//#endregion
export { i as Checkbox };
