import "react";
import { cn as e } from "cn";
import { Separator as t } from "radix-ui";
import { jsx as n } from "react/jsx-runtime";
//#region src/components/ui/separator.tsx
function r({ className: r, orientation: i = "horizontal", decorative: a = !0, ...o }) {
	return /* @__PURE__ */ n(t.Root, {
		"data-slot": "separator",
		decorative: a,
		orientation: i,
		className: e("shrink-0 bg-border data-horizontal:h-px data-horizontal:w-full data-vertical:w-px data-vertical:self-stretch", r),
		...o
	});
}
//#endregion
export { r as Separator };
