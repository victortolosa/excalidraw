import "react";
import { cn as e } from "cn";
import { NavigationMenu as t } from "radix-ui";
import "lucide-react";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
import { cva as i } from "class-variance-authority";
//#region src/components/ui/navigation-menu.tsx
function a({ className: i, children: a, viewport: o = !0, ...s }) {
	return /* @__PURE__ */ r(t.Root, {
		"data-slot": "navigation-menu",
		"data-viewport": o,
		className: e("group/navigation-menu relative flex max-w-max flex-1 items-center justify-center", i),
		...s,
		children: [a, o && /* @__PURE__ */ n(c, {})]
	});
}
function o({ className: r, ...i }) {
	return /* @__PURE__ */ n(t.List, {
		"data-slot": "navigation-menu-list",
		className: e("group flex flex-1 list-none items-center justify-center gap-0", r),
		...i
	});
}
function s({ className: r, ...i }) {
	return /* @__PURE__ */ n(t.Item, {
		"data-slot": "navigation-menu-item",
		className: e("relative", r),
		...i
	});
}
i("group/navigation-menu-trigger inline-flex h-9 w-max items-center justify-center rounded-lg px-2.5 py-1.5 text-sm font-medium transition-all outline-none hover:bg-muted focus:bg-muted focus-visible:ring-3 focus-visible:ring-ring/50 focus-visible:outline-1 disabled:pointer-events-none disabled:opacity-50 data-popup-open:bg-muted/50 data-popup-open:hover:bg-muted data-open:bg-muted/50 data-open:hover:bg-muted data-open:focus:bg-muted");
function c({ className: r, ...i }) {
	return /* @__PURE__ */ n("div", {
		className: e("absolute top-full left-0 isolate z-50 flex justify-center"),
		children: /* @__PURE__ */ n(t.Viewport, {
			"data-slot": "navigation-menu-viewport",
			className: e("origin-top-center relative mt-1.5 h-(--radix-navigation-menu-viewport-height) w-full overflow-hidden rounded-lg bg-popover text-popover-foreground shadow ring-1 ring-foreground/10 duration-100 md:w-(--radix-navigation-menu-viewport-width) data-open:animate-in data-open:zoom-in-90 data-closed:animate-out data-closed:zoom-out-90", r),
			...i
		})
	});
}
function l({ className: r, ...i }) {
	return /* @__PURE__ */ n(t.Link, {
		"data-slot": "navigation-menu-link",
		className: e("flex items-center gap-2 rounded-lg p-2 text-sm transition-all outline-none hover:bg-muted focus:bg-muted focus-visible:ring-3 focus-visible:ring-ring/50 focus-visible:outline-1 in-data-[slot=navigation-menu-content]:rounded-md data-active:bg-muted/50 data-active:hover:bg-muted data-active:focus:bg-muted [&_svg:not([class*='size-'])]:size-4", r),
		...i
	});
}
//#endregion
export { a as NavigationMenu, s as NavigationMenuItem, l as NavigationMenuLink, o as NavigationMenuList, c as NavigationMenuViewport };
