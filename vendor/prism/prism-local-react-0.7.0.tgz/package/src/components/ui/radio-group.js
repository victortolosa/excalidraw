import "react";
import { cn as e } from "cn";
import { RadioGroup as t } from "radix-ui";
import { jsx as n } from "react/jsx-runtime";
//#region src/components/ui/radio-group.tsx
function r({ className: r, ...i }) {
	return /* @__PURE__ */ n(t.Root, {
		"data-slot": "radio-group",
		className: e("grid w-full gap-2", r),
		...i
	});
}
function i({ className: r, ...i }) {
	return /* @__PURE__ */ n(t.Item, {
		"data-slot": "radio-group-item",
		className: e("group/radio-group-item peer relative flex aspect-square size-4 shrink-0 rounded-full border border-input outline-none group-has-[:focus-visible]/field-label:ring-0 group-has-[:focus-visible]/field-label:not-data-checked:border-input after:absolute after:-inset-x-3 after:-inset-y-2 focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 aria-invalid:aria-checked:border-primary dark:bg-input/30 dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40 data-checked:border-primary data-checked:bg-primary data-checked:text-primary-foreground group-has-[:focus-visible]/field-label:data-checked:border-primary dark:data-checked:bg-primary", r),
		...i,
		children: /* @__PURE__ */ n(t.Indicator, {
			"data-slot": "radio-group-indicator",
			className: "flex size-4 items-center justify-center",
			children: /* @__PURE__ */ n("span", { className: "absolute top-1/2 left-1/2 size-2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary-foreground" })
		})
	});
}
//#endregion
export { r as RadioGroup, i as RadioGroupItem };
