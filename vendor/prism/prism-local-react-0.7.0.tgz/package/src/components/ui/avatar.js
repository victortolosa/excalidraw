import "react";
import { cn as e } from "cn";
import { Avatar as t } from "radix-ui";
import { jsx as n } from "react/jsx-runtime";
//#region src/components/ui/avatar.tsx
function r({ className: r, size: i = "default", ...a }) {
	return /* @__PURE__ */ n(t.Root, {
		"data-slot": "avatar",
		"data-size": i,
		className: e("group/avatar relative flex size-8 shrink-0 rounded-full select-none after:absolute after:inset-0 after:rounded-full after:border after:border-border after:mix-blend-darken data-[size=lg]:size-10 data-[size=sm]:size-6 dark:after:mix-blend-lighten", r),
		...a
	});
}
function i({ className: r, ...i }) {
	return /* @__PURE__ */ n(t.Image, {
		"data-slot": "avatar-image",
		className: e("aspect-square size-full rounded-full object-cover", r),
		...i
	});
}
function a({ className: r, ...i }) {
	return /* @__PURE__ */ n(t.Fallback, {
		"data-slot": "avatar-fallback",
		className: e("flex size-full items-center justify-center rounded-full bg-muted text-sm text-muted-foreground group-data-[size=sm]/avatar:text-xs", r),
		...i
	});
}
//#endregion
export { r as Avatar, a as AvatarFallback, i as AvatarImage };
