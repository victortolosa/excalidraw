"use client";
import "./separator.js";
import { Label as e } from "./label.js";
import { useMemo as t } from "react";
import { cn as n } from "cn";
import { jsx as r } from "react/jsx-runtime";
import { cva as i } from "class-variance-authority";
//#region src/components/ui/field.tsx
function a({ className: e, ...t }) {
	return /* @__PURE__ */ r("fieldset", {
		"data-slot": "field-set",
		className: n("flex flex-col gap-4 has-[>[data-slot=checkbox-group]]:gap-3 has-[>[data-slot=radio-group]]:gap-3", e),
		...t
	});
}
function o({ className: e, variant: t = "legend", ...i }) {
	return /* @__PURE__ */ r("legend", {
		"data-slot": "field-legend",
		"data-variant": t,
		className: n("mb-1.5 font-medium data-[variant=label]:text-sm data-[variant=legend]:text-base", e),
		...i
	});
}
var s = i("group/field flex w-full gap-2 data-[invalid=true]:text-destructive", {
	variants: { orientation: {
		vertical: "flex-col *:w-full [&>.sr-only]:w-auto",
		horizontal: "flex-row items-center has-[>[data-slot=field-content]]:items-start *:data-[slot=field-label]:flex-auto has-[>[data-slot=field-content]]:[&>[role=checkbox],[role=radio]]:mt-px",
		responsive: "flex-col *:w-full @md/field-group:flex-row @md/field-group:items-center @md/field-group:*:w-auto @md/field-group:has-[>[data-slot=field-content]]:items-start @md/field-group:*:data-[slot=field-label]:flex-auto [&>.sr-only]:w-auto @md/field-group:has-[>[data-slot=field-content]]:[&>[role=checkbox],[role=radio]]:mt-px"
	} },
	defaultVariants: { orientation: "vertical" }
});
function c({ className: e, orientation: t = "vertical", ...i }) {
	return /* @__PURE__ */ r("div", {
		role: "group",
		"data-slot": "field",
		"data-orientation": t,
		className: n(s({ orientation: t }), e),
		...i
	});
}
function l({ className: e, ...t }) {
	return /* @__PURE__ */ r("div", {
		"data-slot": "field-content",
		className: n("group/field-content flex flex-1 flex-col gap-0.5 leading-snug", e),
		...t
	});
}
function u({ className: t, ...i }) {
	return /* @__PURE__ */ r(e, {
		"data-slot": "field-label",
		className: n("group/field-label peer/field-label flex w-fit gap-2 leading-snug group-data-[disabled=true]/field:opacity-50 has-data-checked:border-primary/30 has-data-checked:bg-primary/5 has-[>[data-slot=field]]:rounded-lg has-[>[data-slot=field]]:border has-[>[data-slot=field]]:not-has-[:disabled,[data-disabled]]:hover:bg-muted/50 has-[>[data-slot=field]]:has-[:focus-visible]:border-ring has-[>[data-slot=field]]:has-[:focus-visible]:ring-3 has-[>[data-slot=field]]:has-[:focus-visible]:ring-ring/50 *:data-[slot=field]:p-2.5 dark:has-data-checked:border-primary/20 dark:has-data-checked:bg-primary/10", "has-[>[data-slot=field]]:w-full has-[>[data-slot=field]]:flex-col", t),
		...i
	});
}
function d({ className: e, ...t }) {
	return /* @__PURE__ */ r("p", {
		"data-slot": "field-description",
		className: n("text-left text-sm leading-normal font-normal text-muted-foreground group-has-data-horizontal/field:text-balance [[data-variant=legend]+&]:-mt-1.5", "last:mt-0 nth-last-2:-mt-1", "[&>a]:underline [&>a]:underline-offset-4 [&>a:hover]:text-primary", e),
		...t
	});
}
function f({ className: e, children: i, errors: a, ...o }) {
	let s = t(() => {
		if (i) return i;
		if (!a?.length) return null;
		let e = [...new Map(a.map((e) => [e?.message, e])).values()];
		return e?.length == 1 ? e[0]?.message : /* @__PURE__ */ r("ul", {
			className: "ml-4 flex list-disc flex-col gap-1",
			children: e.map((e, t) => e?.message && /* @__PURE__ */ r("li", { children: e.message }, t))
		});
	}, [i, a]);
	return s ? /* @__PURE__ */ r("div", {
		role: "alert",
		"data-slot": "field-error",
		className: n("text-sm font-normal text-destructive", e),
		...o,
		children: s
	}) : null;
}
//#endregion
export { c as Field, l as FieldContent, d as FieldDescription, f as FieldError, u as FieldLabel, o as FieldLegend, a as FieldSet };
