"use client";
import "react";
import { cn as e } from "cn";
import { DropdownMenu as t } from "radix-ui";
import { CheckIcon as n } from "lucide-react";
import { jsx as r, jsxs as i } from "react/jsx-runtime";
//#region src/components/ui/dropdown-menu.tsx
function a({ ...e }) {
	return /* @__PURE__ */ r(t.Root, {
		"data-slot": "dropdown-menu",
		...e
	});
}
function o({ ...e }) {
	return /* @__PURE__ */ r(t.Trigger, {
		"data-slot": "dropdown-menu-trigger",
		...e
	});
}
function s({ className: n, align: i = "start", sideOffset: a = 4, ...o }) {
	return /* @__PURE__ */ r(t.Portal, { children: /* @__PURE__ */ r(t.Content, {
		"data-slot": "dropdown-menu-content",
		sideOffset: a,
		align: i,
		className: e("z-50 max-h-(--radix-dropdown-menu-content-available-height) w-(--radix-dropdown-menu-trigger-width) min-w-32 origin-(--radix-dropdown-menu-content-transform-origin) overflow-x-hidden overflow-y-auto rounded-lg bg-popover p-1 text-popover-foreground shadow-md ring-1 ring-foreground/10 duration-100 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 data-[state=closed]:overflow-hidden data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95", n),
		...o
	}) });
}
function c({ className: n, inset: i, variant: a = "default", ...o }) {
	return /* @__PURE__ */ r(t.Item, {
		"data-slot": "dropdown-menu-item",
		"data-inset": i,
		"data-variant": a,
		className: e("group/dropdown-menu-item relative flex cursor-default items-center gap-1.5 rounded-md px-1.5 py-1 text-sm outline-hidden select-none focus:bg-accent focus:text-accent-foreground not-data-[variant=destructive]:focus:**:text-accent-foreground data-inset:pl-7 data-[variant=destructive]:text-destructive data-[variant=destructive]:focus:bg-destructive/10 data-[variant=destructive]:focus:text-destructive dark:data-[variant=destructive]:focus:bg-destructive/20 data-disabled:pointer-events-none data-disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4 data-[variant=destructive]:*:[svg]:text-destructive", n),
		...o
	});
}
function l({ ...e }) {
	return /* @__PURE__ */ r(t.RadioGroup, {
		"data-slot": "dropdown-menu-radio-group",
		...e
	});
}
function u({ className: a, children: o, inset: s, ...c }) {
	return /* @__PURE__ */ i(t.RadioItem, {
		"data-slot": "dropdown-menu-radio-item",
		"data-inset": s,
		className: e("relative flex cursor-default items-center gap-1.5 rounded-md py-1 pr-8 pl-1.5 text-sm outline-hidden select-none focus:bg-accent focus:text-accent-foreground focus:**:text-accent-foreground data-inset:pl-7 data-disabled:pointer-events-none data-disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", a),
		...c,
		children: [/* @__PURE__ */ r("span", {
			className: "pointer-events-none absolute right-2 flex items-center justify-center",
			"data-slot": "dropdown-menu-radio-item-indicator",
			children: /* @__PURE__ */ r(t.ItemIndicator, { children: /* @__PURE__ */ r(n, {}) })
		}), o]
	});
}
//#endregion
export { a as DropdownMenu, s as DropdownMenuContent, c as DropdownMenuItem, l as DropdownMenuRadioGroup, u as DropdownMenuRadioItem, o as DropdownMenuTrigger };
