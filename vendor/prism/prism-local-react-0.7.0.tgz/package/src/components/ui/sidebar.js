import { Button as e } from "./button.js";
import "./separator.js";
import "./input.js";
import { useIsMobile as t } from "../../hooks/use-mobile.js";
import { Sheet as n, SheetContent as r, SheetDescription as i, SheetHeader as a, SheetTitle as o } from "./sheet.js";
import "./skeleton.js";
import { Tooltip as s, TooltipContent as c, TooltipTrigger as l } from "./tooltip.js";
import * as u from "react";
import { cn as d } from "cn";
import { Slot as f } from "radix-ui";
import { PanelLeftIcon as p } from "lucide-react";
import { jsx as m, jsxs as h } from "react/jsx-runtime";
import { cva as g } from "class-variance-authority";
//#region src/components/ui/sidebar.tsx
var _ = "sidebar_state", v = 604800, y = "16rem", b = "18rem", x = "3rem", S = "b", C = u.createContext(null);
function w() {
	let e = u.useContext(C);
	if (!e) throw Error("useSidebar must be used within a SidebarProvider.");
	return e;
}
function T({ defaultOpen: e = !0, open: n, onOpenChange: r, className: i, style: a, children: o, ...s }) {
	let c = t(), [l, f] = u.useState(!1), [p, h] = u.useState(e), g = n ?? p, b = u.useCallback((e) => {
		let t = typeof e == "function" ? e(g) : e;
		r ? r(t) : h(t), document.cookie = `${_}=${t}; path=/; max-age=${v}`;
	}, [r, g]), w = u.useCallback(() => c ? f((e) => !e) : b((e) => !e), [
		c,
		b,
		f
	]);
	u.useEffect(() => {
		let e = (e) => {
			e.key === S && (e.metaKey || e.ctrlKey) && (e.preventDefault(), w());
		};
		return window.addEventListener("keydown", e), () => window.removeEventListener("keydown", e);
	}, [w]);
	let T = g ? "expanded" : "collapsed", E = u.useMemo(() => ({
		state: T,
		open: g,
		setOpen: b,
		isMobile: c,
		openMobile: l,
		setOpenMobile: f,
		toggleSidebar: w
	}), [
		T,
		g,
		b,
		c,
		l,
		f,
		w
	]);
	return /* @__PURE__ */ m(C.Provider, {
		value: E,
		children: /* @__PURE__ */ m("div", {
			"data-slot": "sidebar-wrapper",
			style: {
				"--sidebar-width": y,
				"--sidebar-width-icon": x,
				...a
			},
			className: d("group/sidebar-wrapper flex min-h-svh w-full has-data-[variant=inset]:bg-sidebar", i),
			...s,
			children: o
		})
	});
}
function E({ side: e = "left", variant: t = "sidebar", collapsible: s = "offcanvas", className: c, children: l, dir: u, ...f }) {
	let { isMobile: p, state: g, openMobile: _, setOpenMobile: v } = w();
	return s === "none" ? /* @__PURE__ */ m("div", {
		"data-slot": "sidebar",
		className: d("flex h-full w-(--sidebar-width) flex-col bg-sidebar text-sidebar-foreground", c),
		...f,
		children: l
	}) : p ? /* @__PURE__ */ m(n, {
		open: _,
		onOpenChange: v,
		...f,
		children: /* @__PURE__ */ h(r, {
			dir: u,
			"data-sidebar": "sidebar",
			"data-slot": "sidebar",
			"data-mobile": "true",
			className: "w-(--sidebar-width) bg-sidebar p-0 text-sidebar-foreground [&>button]:hidden",
			style: { "--sidebar-width": b },
			side: e,
			children: [/* @__PURE__ */ h(a, {
				className: "sr-only",
				children: [/* @__PURE__ */ m(o, { children: "Sidebar" }), /* @__PURE__ */ m(i, { children: "Displays the mobile sidebar." })]
			}), /* @__PURE__ */ m("div", {
				className: "flex h-full w-full flex-col",
				children: l
			})]
		})
	}) : /* @__PURE__ */ h("div", {
		className: "group peer hidden text-sidebar-foreground md:block",
		"data-state": g,
		"data-collapsible": g === "collapsed" ? s : "",
		"data-variant": t,
		"data-side": e,
		"data-slot": "sidebar",
		children: [/* @__PURE__ */ m("div", {
			"data-slot": "sidebar-gap",
			className: d("relative w-(--sidebar-width) bg-transparent transition-[width] duration-200 ease-linear", "group-data-[collapsible=offcanvas]:w-0", "group-data-[side=right]:rotate-180", t === "floating" || t === "inset" ? "group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+(--spacing(4)))]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon)")
		}), /* @__PURE__ */ m("div", {
			"data-slot": "sidebar-container",
			"data-side": e,
			className: d("fixed inset-y-0 z-10 hidden h-svh w-(--sidebar-width) transition-[left,right,width] duration-200 ease-linear data-[side=left]:left-0 data-[side=left]:group-data-[collapsible=offcanvas]:left-[calc(var(--sidebar-width)*-1)] data-[side=right]:right-0 data-[side=right]:group-data-[collapsible=offcanvas]:right-[calc(var(--sidebar-width)*-1)] md:flex", t === "floating" || t === "inset" ? "p-2 group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+(--spacing(4))+2px)]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon) group-data-[side=left]:border-r group-data-[side=right]:border-l", c),
			...f,
			children: /* @__PURE__ */ m("div", {
				"data-sidebar": "sidebar",
				"data-slot": "sidebar-inner",
				className: "flex size-full flex-col bg-sidebar group-data-[variant=floating]:rounded-lg group-data-[variant=floating]:shadow-sm group-data-[variant=floating]:ring-1 group-data-[variant=floating]:ring-sidebar-border",
				children: l
			})
		})]
	});
}
function D({ className: t, onClick: n, ...r }) {
	let { toggleSidebar: i } = w();
	return /* @__PURE__ */ h(e, {
		"data-sidebar": "trigger",
		"data-slot": "sidebar-trigger",
		variant: "ghost",
		size: "icon-sm",
		className: d(t),
		onClick: (e) => {
			n?.(e), i();
		},
		...r,
		children: [/* @__PURE__ */ m(p, {}), /* @__PURE__ */ m("span", {
			className: "sr-only",
			children: "Toggle Sidebar"
		})]
	});
}
function O({ className: e, ...t }) {
	return /* @__PURE__ */ m("div", {
		"data-slot": "sidebar-content",
		"data-sidebar": "content",
		className: d("no-scrollbar flex min-h-0 flex-1 flex-col gap-0 overflow-auto group-data-[collapsible=icon]:overflow-hidden", e),
		...t
	});
}
function k({ className: e, ...t }) {
	return /* @__PURE__ */ m("div", {
		"data-slot": "sidebar-group",
		"data-sidebar": "group",
		className: d("relative flex w-full min-w-0 flex-col p-2", e),
		...t
	});
}
function A({ className: e, asChild: t = !1, ...n }) {
	let r = t ? f.Root : "div";
	return /* @__PURE__ */ m(r, {
		"data-slot": "sidebar-group-label",
		"data-sidebar": "group-label",
		className: d("flex h-8 shrink-0 items-center rounded-md px-2 text-xs font-medium text-sidebar-foreground/70 ring-sidebar-ring outline-hidden transition-[margin,opacity] duration-200 ease-linear group-data-[collapsible=icon]:-mt-8 group-data-[collapsible=icon]:opacity-0 focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0", e),
		...n
	});
}
function j({ className: e, ...t }) {
	return /* @__PURE__ */ m("div", {
		"data-slot": "sidebar-group-content",
		"data-sidebar": "group-content",
		className: d("w-full text-sm", e),
		...t
	});
}
function M({ className: e, ...t }) {
	return /* @__PURE__ */ m("ul", {
		"data-slot": "sidebar-menu",
		"data-sidebar": "menu",
		className: d("flex w-full min-w-0 flex-col gap-0", e),
		...t
	});
}
function N({ className: e, ...t }) {
	return /* @__PURE__ */ m("li", {
		"data-slot": "sidebar-menu-item",
		"data-sidebar": "menu-item",
		className: d("group/menu-item relative", e),
		...t
	});
}
var P = g("peer/menu-button group/menu-button flex w-full items-center gap-2 overflow-hidden rounded-md p-2 text-left text-sm ring-sidebar-ring outline-hidden transition-[width,height,padding] group-has-data-[sidebar=menu-action]/menu-item:pr-8 group-data-[collapsible=icon]:size-8! group-data-[collapsible=icon]:p-2! hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50 data-open:hover:bg-sidebar-accent data-open:hover:text-sidebar-accent-foreground data-active:bg-sidebar-accent data-active:font-medium data-active:text-sidebar-accent-foreground [&_svg]:size-4 [&_svg]:shrink-0 [&>span:last-child]:truncate", {
	variants: {
		variant: {
			default: "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
			outline: "bg-background shadow-[0_0_0_1px_var(--sidebar-border)] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:shadow-[0_0_0_1px_var(--sidebar-accent)]"
		},
		size: {
			default: "h-8 text-sm",
			sm: "h-7 text-xs",
			lg: "h-12 text-sm group-data-[collapsible=icon]:p-0!"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function F({ asChild: e = !1, isActive: t = !1, variant: n = "default", size: r = "default", tooltip: i, className: a, ...o }) {
	let u = e ? f.Root : "button", { isMobile: p, state: g } = w(), _ = /* @__PURE__ */ m(u, {
		"data-slot": "sidebar-menu-button",
		"data-sidebar": "menu-button",
		"data-size": r,
		"data-active": t,
		className: d(P({
			variant: n,
			size: r
		}), a),
		...o
	});
	return i ? (typeof i == "string" && (i = { children: i }), /* @__PURE__ */ h(s, { children: [/* @__PURE__ */ m(l, {
		asChild: !0,
		children: _
	}), /* @__PURE__ */ m(c, {
		side: "right",
		align: "center",
		hidden: g !== "collapsed" || p,
		...i
	})] })) : _;
}
//#endregion
export { E as Sidebar, O as SidebarContent, k as SidebarGroup, j as SidebarGroupContent, A as SidebarGroupLabel, M as SidebarMenu, F as SidebarMenuButton, N as SidebarMenuItem, T as SidebarProvider, D as SidebarTrigger, w as useSidebar };
