import "react";
import { cn as e } from "cn";
import { Label as t } from "radix-ui";
import { jsx as n } from "react/jsx-runtime";
//#region src/components/ui/label.tsx
function r({ className: r, ...i }) {
	return /* @__PURE__ */ n(t.Root, {
		"data-slot": "label",
		className: e("flex items-center gap-2 text-sm leading-none font-medium select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50", r),
		...i
	});
}
//#endregion
export { r as Label };
