import "react";
import { cn as e } from "cn";
import { jsx as t } from "react/jsx-runtime";
//#region src/components/ui/card.tsx
function n({ className: n, size: r = "default", ...i }) {
	return /* @__PURE__ */ t("div", {
		"data-slot": "card",
		"data-size": r,
		className: e("group/card flex flex-col gap-(--card-spacing) overflow-hidden rounded-xl bg-card py-(--card-spacing) text-sm text-card-foreground ring-1 ring-foreground/10 [--card-spacing:--spacing(4)] has-data-[slot=card-footer]:pb-0 has-[>img:first-child]:pt-0 data-[size=sm]:[--card-spacing:--spacing(3)] data-[size=sm]:has-data-[slot=card-footer]:pb-0 *:[img:first-child]:rounded-t-xl *:[img:last-child]:rounded-b-xl", n),
		...i
	});
}
function r({ className: n, ...r }) {
	return /* @__PURE__ */ t("div", {
		"data-slot": "card-header",
		className: e("group/card-header @container/card-header grid auto-rows-min items-start gap-1 rounded-t-xl px-(--card-spacing) has-data-[slot=card-action]:grid-cols-[1fr_auto] has-data-[slot=card-description]:grid-rows-[auto_auto] [.border-b]:pb-(--card-spacing)", n),
		...r
	});
}
function i({ className: n, ...r }) {
	return /* @__PURE__ */ t("div", {
		"data-slot": "card-description",
		className: e("text-sm text-muted-foreground", n),
		...r
	});
}
function a({ className: n, ...r }) {
	return /* @__PURE__ */ t("div", {
		"data-slot": "card-content",
		className: e("px-(--card-spacing)", n),
		...r
	});
}
//#endregion
export { n as Card, a as CardContent, i as CardDescription, r as CardHeader };
