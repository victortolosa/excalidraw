"use client";
import "react";
import { cn as e } from "cn";
import { Tabs as t } from "radix-ui";
import { jsx as n } from "react/jsx-runtime";
import { cva as r } from "class-variance-authority";
//#region src/components/ui/tabs.tsx
function i({ className: r, orientation: i = "horizontal", ...a }) {
	return /* @__PURE__ */ n(t.Root, {
		"data-slot": "tabs",
		"data-orientation": i,
		className: e("group/tabs flex gap-2 data-horizontal:flex-col", r),
		...a
	});
}
var a = r("group/tabs-list inline-flex w-fit items-center justify-center rounded-lg p-[3px] text-muted-foreground group-data-horizontal/tabs:h-8 group-data-vertical/tabs:h-fit group-data-vertical/tabs:flex-col data-[variant=line]:rounded-none", {
	variants: { variant: {
		default: "bg-muted",
		line: "gap-1 bg-transparent"
	} },
	defaultVariants: { variant: "default" }
});
function o({ className: r, variant: i = "default", ...o }) {
	return /* @__PURE__ */ n(t.List, {
		"data-slot": "tabs-list",
		"data-variant": i,
		className: e(a({ variant: i }), r),
		...o
	});
}
function s({ className: r, ...i }) {
	return /* @__PURE__ */ n(t.Trigger, {
		"data-slot": "tabs-trigger",
		className: e("relative inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center gap-1.5 rounded-md border border-transparent px-1.5 py-0.5 text-sm font-medium whitespace-nowrap text-foreground/60 transition-all group-data-vertical/tabs:w-full group-data-vertical/tabs:justify-start hover:text-foreground focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:outline-1 focus-visible:outline-ring disabled:pointer-events-none disabled:opacity-50 has-data-[icon=inline-end]:pr-1 has-data-[icon=inline-start]:pl-1 dark:text-muted-foreground dark:hover:text-foreground group-data-[variant=default]/tabs-list:data-active:shadow-sm group-data-[variant=line]/tabs-list:data-active:shadow-none [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", "group-data-[variant=line]/tabs-list:bg-transparent group-data-[variant=line]/tabs-list:data-active:bg-transparent dark:group-data-[variant=line]/tabs-list:data-active:border-transparent dark:group-data-[variant=line]/tabs-list:data-active:bg-transparent", "data-active:bg-background data-active:text-foreground dark:data-active:border-input dark:data-active:bg-input/30 dark:data-active:text-foreground", "after:absolute after:bg-foreground after:opacity-0 after:transition-opacity group-data-horizontal/tabs:after:inset-x-0 group-data-horizontal/tabs:after:bottom-[-5px] group-data-horizontal/tabs:after:h-0.5 group-data-vertical/tabs:after:inset-y-0 group-data-vertical/tabs:after:-right-1 group-data-vertical/tabs:after:w-0.5 group-data-[variant=line]/tabs-list:data-active:after:opacity-100", r),
		...i
	});
}
function c({ className: r, ...i }) {
	return /* @__PURE__ */ n(t.Content, {
		"data-slot": "tabs-content",
		className: e("flex-1 text-sm outline-none", r),
		...i
	});
}
//#endregion
export { i as Tabs, c as TabsContent, o as TabsList, s as TabsTrigger, a as tabsListVariants };
