"use client";
import { Button as e } from "./button.js";
import "react";
import { cn as t } from "cn";
import { Dialog as n } from "radix-ui";
import { XIcon as r } from "lucide-react";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
//#region src/components/ui/dialog.tsx
function o({ ...e }) {
	return /* @__PURE__ */ i(n.Root, {
		"data-slot": "dialog",
		...e
	});
}
function s({ ...e }) {
	return /* @__PURE__ */ i(n.Trigger, {
		"data-slot": "dialog-trigger",
		...e
	});
}
function c({ ...e }) {
	return /* @__PURE__ */ i(n.Portal, {
		"data-slot": "dialog-portal",
		...e
	});
}
function l({ ...e }) {
	return /* @__PURE__ */ i(n.Close, {
		"data-slot": "dialog-close",
		...e
	});
}
function u({ className: e, ...r }) {
	return /* @__PURE__ */ i(n.Overlay, {
		"data-slot": "dialog-overlay",
		className: t("fixed inset-0 isolate z-50 bg-black/10 duration-100 supports-backdrop-filter:backdrop-blur-xs data-open:animate-in data-open:fade-in-0 data-closed:animate-out data-closed:fade-out-0", e),
		...r
	});
}
function d({ className: o, children: s, showCloseButton: l = !0, ...d }) {
	return /* @__PURE__ */ a(c, { children: [/* @__PURE__ */ i(u, {}), /* @__PURE__ */ a(n.Content, {
		"data-slot": "dialog-content",
		className: t("fixed top-1/2 left-1/2 z-50 grid w-full max-w-[calc(100%-2rem)] -translate-x-1/2 -translate-y-1/2 gap-4 rounded-xl bg-popover p-4 text-sm text-popover-foreground ring-1 ring-foreground/10 duration-100 outline-none sm:max-w-sm data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95", o),
		...d,
		children: [s, l && /* @__PURE__ */ i(n.Close, {
			"data-slot": "dialog-close",
			asChild: !0,
			children: /* @__PURE__ */ a(e, {
				variant: "ghost",
				className: "absolute top-2 right-2",
				size: "icon-sm",
				children: [/* @__PURE__ */ i(r, {}), /* @__PURE__ */ i("span", {
					className: "sr-only",
					children: "Close"
				})]
			})
		})]
	})] });
}
function f({ className: e, ...n }) {
	return /* @__PURE__ */ i("div", {
		"data-slot": "dialog-header",
		className: t("flex flex-col gap-2", e),
		...n
	});
}
function p({ className: r, showCloseButton: o = !1, children: s, ...c }) {
	return /* @__PURE__ */ a("div", {
		"data-slot": "dialog-footer",
		className: t("-mx-4 -mb-4 flex flex-col-reverse gap-2 rounded-b-xl border-t bg-muted/50 p-4 sm:flex-row sm:justify-end", r),
		...c,
		children: [s, o && /* @__PURE__ */ i(n.Close, {
			asChild: !0,
			children: /* @__PURE__ */ i(e, {
				variant: "outline",
				children: "Close"
			})
		})]
	});
}
function m({ className: e, ...r }) {
	return /* @__PURE__ */ i(n.Title, {
		"data-slot": "dialog-title",
		className: t("font-heading text-base leading-none font-medium", e),
		...r
	});
}
function h({ className: e, ...r }) {
	return /* @__PURE__ */ i(n.Description, {
		"data-slot": "dialog-description",
		className: t("text-sm text-muted-foreground *:[a]:underline *:[a]:underline-offset-3 *:[a]:hover:text-foreground", e),
		...r
	});
}
//#endregion
export { o as Dialog, l as DialogClose, d as DialogContent, h as DialogDescription, p as DialogFooter, f as DialogHeader, u as DialogOverlay, c as DialogPortal, m as DialogTitle, s as DialogTrigger };
