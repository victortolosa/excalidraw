"use client";
import "react";
import { cn as e } from "cn";
import { Tooltip as t } from "radix-ui";
import { jsx as n, jsxs as r } from "react/jsx-runtime";
//#region src/components/ui/tooltip.tsx
function i({ delayDuration: e = 0, ...r }) {
	return /* @__PURE__ */ n(t.Provider, {
		"data-slot": "tooltip-provider",
		delayDuration: e,
		...r
	});
}
function a({ ...e }) {
	return /* @__PURE__ */ n(t.Root, {
		"data-slot": "tooltip",
		...e
	});
}
function o({ ...e }) {
	return /* @__PURE__ */ n(t.Trigger, {
		"data-slot": "tooltip-trigger",
		...e
	});
}
function s({ className: i, sideOffset: a = 0, children: o, ...s }) {
	return /* @__PURE__ */ n(t.Portal, { children: /* @__PURE__ */ r(t.Content, {
		"data-slot": "tooltip-content",
		sideOffset: a,
		className: e("z-50 inline-flex w-fit max-w-xs origin-(--radix-tooltip-content-transform-origin) items-center gap-1.5 rounded-md bg-foreground px-3 py-1.5 text-xs text-background has-data-[slot=kbd]:pr-1.5 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 **:data-[slot=kbd]:relative **:data-[slot=kbd]:isolate **:data-[slot=kbd]:z-50 **:data-[slot=kbd]:rounded-sm data-[state=delayed-open]:animate-in data-[state=delayed-open]:fade-in-0 data-[state=delayed-open]:zoom-in-95 data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95", i),
		...s,
		children: [o, /* @__PURE__ */ n(t.Arrow, { className: "z-50 size-2.5 translate-y-[calc(-50%_-_2px)] rotate-45 rounded-[2px] bg-foreground fill-foreground" })]
	}) });
}
//#endregion
export { a as Tooltip, s as TooltipContent, i as TooltipProvider, o as TooltipTrigger };
