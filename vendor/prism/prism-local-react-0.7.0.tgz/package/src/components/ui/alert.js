import "react";
import { cn as e } from "cn";
import { jsx as t } from "react/jsx-runtime";
import { cva as n } from "class-variance-authority";
//#region src/components/ui/alert.tsx
var r = n("group/alert relative grid w-full gap-0.5 rounded-lg border px-2.5 py-2 text-left text-sm has-data-[slot=alert-action]:relative has-data-[slot=alert-action]:pr-18 has-[>svg]:grid-cols-[auto_1fr] has-[>svg]:gap-x-2 *:[svg]:row-span-2 *:[svg]:translate-y-0.5 *:[svg]:text-current *:[svg:not([class*='size-'])]:size-4", {
	variants: { variant: {
		default: "bg-card text-card-foreground",
		destructive: "bg-card text-destructive *:data-[slot=alert-description]:text-destructive/90 *:[svg]:text-current"
	} },
	defaultVariants: { variant: "default" }
});
function i({ className: n, variant: i, ...a }) {
	return /* @__PURE__ */ t("div", {
		"data-slot": "alert",
		role: "alert",
		className: e(r({ variant: i }), n),
		...a
	});
}
function a({ className: n, ...r }) {
	return /* @__PURE__ */ t("div", {
		"data-slot": "alert-title",
		className: e("font-medium group-has-[>svg]/alert:col-start-2 [&_a]:underline [&_a]:underline-offset-3 [&_a]:hover:text-foreground", n),
		...r
	});
}
function o({ className: n, ...r }) {
	return /* @__PURE__ */ t("div", {
		"data-slot": "alert-description",
		className: e("text-sm text-balance text-muted-foreground md:text-pretty [&_a]:underline [&_a]:underline-offset-3 [&_a]:hover:text-foreground [&_p:not(:last-child)]:mb-4", n),
		...r
	});
}
//#endregion
export { i as Alert, o as AlertDescription, a as AlertTitle };
