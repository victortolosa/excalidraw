"use client";
import "./button.js";
import { InputGroup as e, InputGroupAddon as t, InputGroupButton as n, InputGroupInput as r } from "./input-group.js";
import "react";
import { cn as i } from "cn";
import { CheckIcon as a, ChevronDownIcon as o, XIcon as s } from "lucide-react";
import { jsx as c, jsxs as l } from "react/jsx-runtime";
import { Combobox as u } from "@base-ui/react";
//#region src/components/ui/combobox.tsx
var d = u.Root;
function f({ className: e, children: t, ...n }) {
	return /* @__PURE__ */ l(u.Trigger, {
		"data-slot": "combobox-trigger",
		className: i("[&_svg:not([class*='size-'])]:size-4", e),
		...n,
		children: [t, /* @__PURE__ */ c(o, { className: "pointer-events-none size-4 text-muted-foreground" })]
	});
}
function p({ className: e, ...t }) {
	return /* @__PURE__ */ c(u.Clear, {
		"data-slot": "combobox-clear",
		render: /* @__PURE__ */ c(n, {
			variant: "ghost",
			size: "icon-xs"
		}),
		className: i(e),
		...t,
		children: /* @__PURE__ */ c(s, { className: "pointer-events-none" })
	});
}
function m({ className: a, children: o, disabled: s = !1, showTrigger: d = !0, showClear: m = !1, ...h }) {
	return /* @__PURE__ */ l(e, {
		className: i("w-auto", a),
		children: [
			/* @__PURE__ */ c(u.Input, {
				render: /* @__PURE__ */ c(r, { disabled: s }),
				...h
			}),
			/* @__PURE__ */ l(t, {
				align: "inline-end",
				children: [d && /* @__PURE__ */ c(n, {
					size: "icon-xs",
					variant: "ghost",
					asChild: !0,
					"data-slot": "input-group-button",
					className: "group-has-data-[slot=combobox-clear]/input-group:hidden data-pressed:bg-transparent",
					disabled: s,
					children: /* @__PURE__ */ c(f, {})
				}), m && /* @__PURE__ */ c(p, { disabled: s })]
			}),
			o
		]
	});
}
function h({ className: e, side: t = "bottom", sideOffset: n = 6, align: r = "start", alignOffset: a = 0, anchor: o, ...s }) {
	return /* @__PURE__ */ c(u.Portal, { children: /* @__PURE__ */ c(u.Positioner, {
		side: t,
		sideOffset: n,
		align: r,
		alignOffset: a,
		anchor: o,
		className: "isolate z-50",
		children: /* @__PURE__ */ c(u.Popup, {
			"data-slot": "combobox-content",
			"data-chips": !!o,
			className: i("group/combobox-content relative max-h-(--available-height) w-(--anchor-width) max-w-(--available-width) min-w-[calc(var(--anchor-width)+--spacing(7))] origin-(--transform-origin) overflow-hidden rounded-lg bg-popover text-popover-foreground shadow-md ring-1 ring-foreground/10 duration-100 data-[chips=true]:min-w-(--anchor-width) data-[side=bottom]:slide-in-from-top-2 data-[side=inline-end]:slide-in-from-left-2 data-[side=inline-start]:slide-in-from-right-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 *:data-[slot=input-group]:m-1 *:data-[slot=input-group]:mb-0 *:data-[slot=input-group]:h-8 *:data-[slot=input-group]:border-input/30 *:data-[slot=input-group]:bg-input/30 *:data-[slot=input-group]:shadow-none data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95", e),
			...s
		})
	}) });
}
function g({ className: e, ...t }) {
	return /* @__PURE__ */ c(u.List, {
		"data-slot": "combobox-list",
		className: i("no-scrollbar max-h-[min(calc(--spacing(72)---spacing(9)),calc(var(--available-height)---spacing(9)))] scroll-py-1 overflow-y-auto overscroll-contain p-1 data-empty:p-0", e),
		...t
	});
}
function _({ className: e, children: t, ...n }) {
	return /* @__PURE__ */ l(u.Item, {
		"data-slot": "combobox-item",
		className: i("relative flex w-full cursor-default items-center gap-2 rounded-md py-1 pr-8 pl-1.5 text-sm outline-hidden select-none data-highlighted:bg-accent data-highlighted:text-accent-foreground not-data-[variant=destructive]:data-highlighted:**:text-accent-foreground data-disabled:pointer-events-none data-disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", e),
		...n,
		children: [t, /* @__PURE__ */ c(u.ItemIndicator, {
			render: /* @__PURE__ */ c("span", { className: "pointer-events-none absolute right-2 flex size-4 items-center justify-center" }),
			children: /* @__PURE__ */ c(a, { className: "pointer-events-none" })
		})]
	});
}
function v({ className: e, ...t }) {
	return /* @__PURE__ */ c(u.Empty, {
		"data-slot": "combobox-empty",
		className: i("hidden w-full justify-center py-2 text-center text-sm text-muted-foreground group-data-empty/combobox-content:flex", e),
		...t
	});
}
//#endregion
export { d as Combobox, h as ComboboxContent, v as ComboboxEmpty, m as ComboboxInput, _ as ComboboxItem, g as ComboboxList, f as ComboboxTrigger };
