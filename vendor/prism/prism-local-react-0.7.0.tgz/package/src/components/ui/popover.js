import "react";
import { cn as e } from "cn";
import { Popover as t } from "radix-ui";
import { jsx as n } from "react/jsx-runtime";
//#region src/components/ui/popover.tsx
function r({ ...e }) {
	return /* @__PURE__ */ n(t.Root, {
		"data-slot": "popover",
		...e
	});
}
function i({ ...e }) {
	return /* @__PURE__ */ n(t.Trigger, {
		"data-slot": "popover-trigger",
		...e
	});
}
function a({ className: r, align: i = "center", sideOffset: a = 4, ...o }) {
	return /* @__PURE__ */ n(t.Portal, { children: /* @__PURE__ */ n(t.Content, {
		"data-slot": "popover-content",
		align: i,
		sideOffset: a,
		className: e("z-50 flex w-72 origin-(--radix-popover-content-transform-origin) flex-col gap-2.5 rounded-lg bg-popover p-2.5 text-sm text-popover-foreground shadow-md ring-1 ring-foreground/10 outline-hidden duration-100 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95", r),
		...o
	}) });
}
//#endregion
export { r as Popover, a as PopoverContent, i as PopoverTrigger };
