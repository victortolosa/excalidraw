import "./button.js";
import * as e from "react";
import { cn as t } from "cn";
import "lucide-react";
import { jsx as n } from "react/jsx-runtime";
import r from "embla-carousel-react";
//#region src/components/ui/carousel.tsx
var i = e.createContext(null);
function a() {
	let t = e.useContext(i);
	if (!t) throw Error("useCarousel must be used within a <Carousel />");
	return t;
}
function o({ orientation: a = "horizontal", opts: o, setApi: s, plugins: c, className: l, children: u, ...d }) {
	let [f, p] = r({
		...o,
		axis: a === "horizontal" ? "x" : "y"
	}, c), [m, h] = e.useState(!1), [g, _] = e.useState(!1), v = e.useCallback((e) => {
		e && (h(e.canScrollPrev()), _(e.canScrollNext()));
	}, []), y = e.useCallback(() => {
		p?.scrollPrev();
	}, [p]), b = e.useCallback(() => {
		p?.scrollNext();
	}, [p]), x = e.useCallback((e) => {
		e.key === "ArrowLeft" ? (e.preventDefault(), y()) : e.key === "ArrowRight" && (e.preventDefault(), b());
	}, [y, b]);
	return e.useEffect(() => {
		p && s && s(p);
	}, [p, s]), e.useEffect(() => {
		if (p) return v(p), p.on("reInit", v), p.on("select", v), () => {
			p?.off("select", v);
		};
	}, [p, v]), /* @__PURE__ */ n(i.Provider, {
		value: {
			carouselRef: f,
			api: p,
			opts: o,
			orientation: a || (o?.axis === "y" ? "vertical" : "horizontal"),
			scrollPrev: y,
			scrollNext: b,
			canScrollPrev: m,
			canScrollNext: g
		},
		children: /* @__PURE__ */ n("div", {
			onKeyDownCapture: x,
			className: t("relative", l),
			role: "region",
			"aria-roledescription": "carousel",
			"data-slot": "carousel",
			...d,
			children: u
		})
	});
}
function s({ className: e, ...r }) {
	let { carouselRef: i, orientation: o } = a();
	return /* @__PURE__ */ n("div", {
		ref: i,
		className: "overflow-hidden",
		"data-slot": "carousel-content",
		children: /* @__PURE__ */ n("div", {
			className: t("flex", o === "horizontal" ? "-ml-4" : "-mt-4 flex-col", e),
			...r
		})
	});
}
function c({ className: e, ...r }) {
	let { orientation: i } = a();
	return /* @__PURE__ */ n("div", {
		role: "group",
		"aria-roledescription": "slide",
		"data-slot": "carousel-item",
		className: t("min-w-0 shrink-0 grow-0 basis-full", i === "horizontal" ? "pl-4" : "pt-4", e),
		...r
	});
}
//#endregion
export { o as Carousel, s as CarouselContent, c as CarouselItem, a as useCarousel };
