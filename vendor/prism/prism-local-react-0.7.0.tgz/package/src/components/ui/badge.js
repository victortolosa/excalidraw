import "react";
import { cn as e } from "cn";
import { Slot as t } from "radix-ui";
import { jsx as n } from "react/jsx-runtime";
import { cva as r } from "class-variance-authority";
//#region src/components/ui/badge.tsx
var i = r("group/badge inline-flex h-5 w-fit shrink-0 items-center justify-center gap-1 overflow-hidden rounded-4xl border border-transparent px-2 py-0.5 text-xs font-medium whitespace-nowrap transition-all focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 aria-invalid:border-destructive aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 [&>svg]:pointer-events-none [&>svg]:size-3!", {
	variants: { variant: {
		default: "bg-primary text-primary-foreground [a]:hover:bg-primary/80",
		secondary: "bg-secondary text-secondary-foreground [a]:hover:bg-secondary/80",
		destructive: "bg-destructive/10 text-destructive focus-visible:ring-destructive/20 dark:bg-destructive/20 dark:focus-visible:ring-destructive/40 [a]:hover:bg-destructive/20",
		outline: "border-border text-foreground [a]:hover:bg-muted [a]:hover:text-muted-foreground",
		ghost: "hover:bg-muted hover:text-muted-foreground dark:hover:bg-muted/50",
		link: "text-primary underline-offset-4 hover:underline"
	} },
	defaultVariants: { variant: "default" }
});
function a({ className: r, variant: a = "default", asChild: o = !1, ...s }) {
	let c = o ? t.Root : "span";
	return /* @__PURE__ */ n(c, {
		"data-slot": "badge",
		"data-variant": a,
		className: e(i({ variant: a }), r),
		...s
	});
}
//#endregion
export { a as Badge, i as badgeVariants };
