"use client";
import "react";
import { cn as e } from "cn";
import { Select as t } from "radix-ui";
import { CheckIcon as n, ChevronDownIcon as r, ChevronUpIcon as i } from "lucide-react";
import { jsx as a, jsxs as o } from "react/jsx-runtime";
//#region src/components/ui/select.tsx
function s({ ...e }) {
	return /* @__PURE__ */ a(t.Root, {
		"data-slot": "select",
		...e
	});
}
function c({ ...e }) {
	return /* @__PURE__ */ a(t.Value, {
		"data-slot": "select-value",
		...e
	});
}
function l({ className: n, size: i = "default", children: s, ...c }) {
	return /* @__PURE__ */ o(t.Trigger, {
		"data-slot": "select-trigger",
		"data-size": i,
		className: e("flex w-fit items-center justify-between gap-1.5 rounded-lg border border-input bg-transparent py-2 pr-2 pl-2.5 text-sm whitespace-nowrap transition-colors outline-none select-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 data-placeholder:text-muted-foreground data-[size=default]:h-8 data-[size=sm]:h-7 data-[size=sm]:rounded-[min(var(--radius-md),10px)] *:data-[slot=select-value]:line-clamp-1 *:data-[slot=select-value]:flex *:data-[slot=select-value]:items-center *:data-[slot=select-value]:gap-1.5 dark:bg-input/30 dark:hover:bg-input/50 dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", n),
		...c,
		children: [s, /* @__PURE__ */ a(t.Icon, {
			asChild: !0,
			children: /* @__PURE__ */ a(r, { className: "pointer-events-none size-4 text-muted-foreground" })
		})]
	});
}
function u({ className: n, children: r, position: i = "item-aligned", align: s = "center", ...c }) {
	return /* @__PURE__ */ a(t.Portal, { children: /* @__PURE__ */ o(t.Content, {
		"data-slot": "select-content",
		"data-align-trigger": i === "item-aligned",
		className: e("relative z-50 max-h-(--radix-select-content-available-height) min-w-36 origin-(--radix-select-content-transform-origin) overflow-x-hidden overflow-y-auto rounded-lg bg-popover text-popover-foreground shadow-md ring-1 ring-foreground/10 duration-100 data-[align-trigger=true]:animate-none data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95", i === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1", n),
		position: i,
		align: s,
		...c,
		children: [
			/* @__PURE__ */ a(f, {}),
			/* @__PURE__ */ a(t.Viewport, {
				"data-position": i,
				className: e("data-[position=popper]:h-(--radix-select-trigger-height) data-[position=popper]:w-full data-[position=popper]:min-w-(--radix-select-trigger-width)", i === "popper" && ""),
				children: r
			}),
			/* @__PURE__ */ a(p, {})
		]
	}) });
}
function d({ className: r, children: i, ...s }) {
	return /* @__PURE__ */ o(t.Item, {
		"data-slot": "select-item",
		className: e("relative flex w-full cursor-default items-center gap-1.5 rounded-md py-1 pr-8 pl-1.5 text-sm outline-hidden select-none focus:bg-accent focus:text-accent-foreground not-data-[variant=destructive]:focus:**:text-accent-foreground data-disabled:pointer-events-none data-disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4 *:[span]:last:flex *:[span]:last:items-center *:[span]:last:gap-2", r),
		...s,
		children: [/* @__PURE__ */ a("span", {
			className: "pointer-events-none absolute right-2 flex size-4 items-center justify-center",
			children: /* @__PURE__ */ a(t.ItemIndicator, { children: /* @__PURE__ */ a(n, { className: "pointer-events-none" }) })
		}), /* @__PURE__ */ a(t.ItemText, { children: i })]
	});
}
function f({ className: n, ...r }) {
	return /* @__PURE__ */ a(t.ScrollUpButton, {
		"data-slot": "select-scroll-up-button",
		className: e("z-10 flex cursor-default items-center justify-center bg-popover py-1 [&_svg:not([class*='size-'])]:size-4", n),
		...r,
		children: /* @__PURE__ */ a(i, {})
	});
}
function p({ className: n, ...i }) {
	return /* @__PURE__ */ a(t.ScrollDownButton, {
		"data-slot": "select-scroll-down-button",
		className: e("z-10 flex cursor-default items-center justify-center bg-popover py-1 [&_svg:not([class*='size-'])]:size-4", n),
		...i,
		children: /* @__PURE__ */ a(r, {})
	});
}
//#endregion
export { s as Select, u as SelectContent, d as SelectItem, p as SelectScrollDownButton, f as SelectScrollUpButton, l as SelectTrigger, c as SelectValue };
