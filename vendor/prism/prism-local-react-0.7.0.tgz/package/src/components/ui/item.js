import "./separator.js";
import "react";
import { cn as e } from "cn";
import { Slot as t } from "radix-ui";
import { jsx as n } from "react/jsx-runtime";
import { cva as r } from "class-variance-authority";
//#region src/components/ui/item.tsx
function i({ className: t, ...r }) {
	return /* @__PURE__ */ n("div", {
		role: "list",
		"data-slot": "item-group",
		className: e("group/item-group flex w-full flex-col gap-4 has-data-[size=sm]:gap-2.5 has-data-[size=xs]:gap-2", t),
		...r
	});
}
var a = r("group/item flex w-full flex-wrap items-center rounded-lg border text-sm transition-colors duration-100 outline-none focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 [a]:transition-colors [a]:hover:bg-muted", {
	variants: {
		variant: {
			default: "border-transparent",
			outline: "border-border",
			muted: "border-transparent bg-muted/50"
		},
		size: {
			default: "gap-2.5 px-3 py-2.5",
			sm: "gap-2.5 px-3 py-2.5",
			xs: "gap-2 px-2.5 py-2 in-data-[slot=dropdown-menu-content]:p-0"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function o({ className: r, variant: i = "default", size: o = "default", asChild: s = !1, ...c }) {
	let l = s ? t.Root : "div";
	return /* @__PURE__ */ n(l, {
		"data-slot": "item",
		"data-variant": i,
		"data-size": o,
		className: e(a({
			variant: i,
			size: o,
			className: r
		})),
		...c
	});
}
r("flex shrink-0 items-center justify-center gap-2 group-has-data-[slot=item-description]/item:translate-y-0.5 group-has-data-[slot=item-description]/item:self-start [&_svg]:pointer-events-none", {
	variants: { variant: {
		default: "bg-transparent",
		icon: "[&_svg:not([class*='size-'])]:size-4",
		image: "size-10 overflow-hidden rounded-sm group-data-[size=sm]/item:size-8 group-data-[size=xs]/item:size-6 [&_img]:size-full [&_img]:object-cover"
	} },
	defaultVariants: { variant: "default" }
});
function s({ className: t, ...r }) {
	return /* @__PURE__ */ n("div", {
		"data-slot": "item-content",
		className: e("flex flex-1 flex-col gap-1 group-data-[size=xs]/item:gap-0 [&+[data-slot=item-content]]:flex-none", t),
		...r
	});
}
function c({ className: t, ...r }) {
	return /* @__PURE__ */ n("div", {
		"data-slot": "item-title",
		className: e("line-clamp-1 flex w-fit items-center gap-2 text-sm leading-snug font-medium underline-offset-4", t),
		...r
	});
}
function l({ className: t, ...r }) {
	return /* @__PURE__ */ n("p", {
		"data-slot": "item-description",
		className: e("line-clamp-2 text-left text-sm leading-normal font-normal text-muted-foreground group-data-[size=xs]/item:text-xs [&>a]:underline [&>a]:underline-offset-4 [&>a:hover]:text-primary", t),
		...r
	});
}
function u({ className: t, ...r }) {
	return /* @__PURE__ */ n("div", {
		"data-slot": "item-actions",
		className: e("flex items-center gap-2", t),
		...r
	});
}
//#endregion
export { o as Item, u as ItemActions, s as ItemContent, l as ItemDescription, i as ItemGroup, c as ItemTitle };
