import "./separator.js";
import { cn as e } from "cn";
import "radix-ui";
import { jsx as t } from "react/jsx-runtime";
import { cva as n } from "class-variance-authority";
//#region src/components/ui/button-group.tsx
var r = n("group/button-group flex w-fit items-stretch *:focus-visible:relative *:focus-visible:z-10 has-[>[data-slot=button-group]]:gap-2 has-[select[aria-hidden=true]:last-child]:[&>[data-slot=select-trigger]:last-of-type]:rounded-r-lg [&>[data-slot=select-trigger]:not([class*='w-'])]:w-fit [&>input]:flex-1", {
	variants: { orientation: {
		horizontal: "[&>*:not(:first-child)]:rounded-l-none [&>*:not(:first-child)]:border-l-0 [&>*:not(:last-child)]:rounded-r-none [&>[data-slot]:not(:has(~[data-slot]))]:rounded-r-lg!",
		vertical: "flex-col [&>*:not(:first-child)]:rounded-t-none [&>*:not(:first-child)]:border-t-0 [&>*:not(:last-child)]:rounded-b-none [&>[data-slot]:not(:has(~[data-slot]))]:rounded-b-lg!"
	} },
	defaultVariants: { orientation: "horizontal" }
});
function i({ className: n, orientation: i, ...a }) {
	return /* @__PURE__ */ t("div", {
		role: "group",
		"data-slot": "button-group",
		"data-orientation": i,
		className: e(r({ orientation: i }), n),
		...a
	});
}
//#endregion
export { i as ButtonGroup, r as buttonGroupVariants };
