import "react";
import { cn as e } from "cn";
import { Slot as t } from "radix-ui";
import { ChevronRightIcon as n } from "lucide-react";
import { jsx as r } from "react/jsx-runtime";
//#region src/components/ui/breadcrumb.tsx
function i({ className: t, ...n }) {
	return /* @__PURE__ */ r("nav", {
		"aria-label": "breadcrumb",
		"data-slot": "breadcrumb",
		className: e(t),
		...n
	});
}
function a({ className: t, ...n }) {
	return /* @__PURE__ */ r("ol", {
		"data-slot": "breadcrumb-list",
		className: e("flex flex-wrap items-center gap-1.5 text-sm wrap-break-word text-muted-foreground", t),
		...n
	});
}
function o({ className: t, ...n }) {
	return /* @__PURE__ */ r("li", {
		"data-slot": "breadcrumb-item",
		className: e("inline-flex items-center gap-1", t),
		...n
	});
}
function s({ asChild: n, className: i, ...a }) {
	let o = n ? t.Root : "a";
	return /* @__PURE__ */ r(o, {
		"data-slot": "breadcrumb-link",
		className: e("transition-colors hover:text-foreground", i),
		...a
	});
}
function c({ className: t, ...n }) {
	return /* @__PURE__ */ r("span", {
		"data-slot": "breadcrumb-page",
		role: "link",
		"aria-disabled": "true",
		"aria-current": "page",
		className: e("font-normal text-foreground", t),
		...n
	});
}
function l({ children: t, className: i, ...a }) {
	return /* @__PURE__ */ r("li", {
		"data-slot": "breadcrumb-separator",
		role: "presentation",
		"aria-hidden": "true",
		className: e("[&>svg]:size-3.5", i),
		...a,
		children: t ?? /* @__PURE__ */ r(n, {})
	});
}
//#endregion
export { i as Breadcrumb, o as BreadcrumbItem, s as BreadcrumbLink, a as BreadcrumbList, c as BreadcrumbPage, l as BreadcrumbSeparator };
