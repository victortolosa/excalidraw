import { cn as e } from "cn";
import { Loader2Icon as t } from "lucide-react";
import { jsx as n } from "react/jsx-runtime";
//#region src/components/ui/spinner.tsx
function r({ className: r, ...i }) {
	return /* @__PURE__ */ n(t, {
		"data-slot": "spinner",
		role: "status",
		"aria-label": "Loading",
		className: e("size-4 animate-spin", r),
		...i
	});
}
//#endregion
export { r as Spinner };
