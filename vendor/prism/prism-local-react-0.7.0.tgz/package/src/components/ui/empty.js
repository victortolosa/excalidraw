import { cn as e } from "cn";
import { jsx as t } from "react/jsx-runtime";
import { cva as n } from "class-variance-authority";
//#region src/components/ui/empty.tsx
function r({ className: n, ...r }) {
	return /* @__PURE__ */ t("div", {
		"data-slot": "empty",
		className: e("flex w-full min-w-0 flex-1 flex-col items-center justify-center gap-4 rounded-xl border-dashed p-6 text-center text-balance", n),
		...r
	});
}
function i({ className: n, ...r }) {
	return /* @__PURE__ */ t("div", {
		"data-slot": "empty-header",
		className: e("flex max-w-sm flex-col items-center gap-2", n),
		...r
	});
}
n("mb-2 flex shrink-0 items-center justify-center [&_svg]:pointer-events-none [&_svg]:shrink-0", {
	variants: { variant: {
		default: "bg-transparent",
		icon: "flex size-8 shrink-0 items-center justify-center rounded-lg bg-muted text-foreground [&_svg:not([class*='size-'])]:size-4"
	} },
	defaultVariants: { variant: "default" }
});
function a({ className: n, ...r }) {
	return /* @__PURE__ */ t("div", {
		"data-slot": "empty-description",
		className: e("text-sm/relaxed text-muted-foreground [&>a]:underline [&>a]:underline-offset-4 [&>a:hover]:text-primary", n),
		...r
	});
}
function o({ className: n, ...r }) {
	return /* @__PURE__ */ t("div", {
		"data-slot": "empty-content",
		className: e("flex w-full max-w-sm min-w-0 flex-col items-center gap-2.5 text-sm text-balance", n),
		...r
	});
}
//#endregion
export { r as Empty, o as EmptyContent, a as EmptyDescription, i as EmptyHeader };
