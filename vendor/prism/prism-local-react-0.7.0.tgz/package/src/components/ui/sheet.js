import { Button as e } from "./button.js";
import "react";
import { cn as t } from "cn";
import { Dialog as n } from "radix-ui";
import { XIcon as r } from "lucide-react";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
//#region src/components/ui/sheet.tsx
function o({ ...e }) {
	return /* @__PURE__ */ i(n.Root, {
		"data-slot": "sheet",
		...e
	});
}
function s({ ...e }) {
	return /* @__PURE__ */ i(n.Portal, {
		"data-slot": "sheet-portal",
		...e
	});
}
function c({ className: e, ...r }) {
	return /* @__PURE__ */ i(n.Overlay, {
		"data-slot": "sheet-overlay",
		className: t("fixed inset-0 z-50 bg-black/10 duration-100 supports-backdrop-filter:backdrop-blur-xs data-open:animate-in data-open:fade-in-0 data-closed:animate-out data-closed:fade-out-0", e),
		...r
	});
}
function l({ className: o, children: l, side: u = "right", showCloseButton: d = !0, ...f }) {
	return /* @__PURE__ */ a(s, { children: [/* @__PURE__ */ i(c, {}), /* @__PURE__ */ a(n.Content, {
		"data-slot": "sheet-content",
		"data-side": u,
		className: t("fixed z-50 flex flex-col gap-4 bg-popover bg-clip-padding text-sm text-popover-foreground shadow-lg transition duration-200 ease-in-out data-[side=bottom]:inset-x-0 data-[side=bottom]:bottom-0 data-[side=bottom]:h-auto data-[side=bottom]:border-t data-[side=left]:inset-y-0 data-[side=left]:left-0 data-[side=left]:h-full data-[side=left]:w-3/4 data-[side=left]:border-r data-[side=right]:inset-y-0 data-[side=right]:right-0 data-[side=right]:h-full data-[side=right]:w-3/4 data-[side=right]:border-l data-[side=top]:inset-x-0 data-[side=top]:top-0 data-[side=top]:h-auto data-[side=top]:border-b data-[side=left]:sm:max-w-sm data-[side=right]:sm:max-w-sm data-open:animate-in data-open:fade-in-0 data-[side=bottom]:data-open:slide-in-from-bottom-10 data-[side=left]:data-open:slide-in-from-left-10 data-[side=right]:data-open:slide-in-from-right-10 data-[side=top]:data-open:slide-in-from-top-10 data-closed:animate-out data-closed:fade-out-0 data-[side=bottom]:data-closed:slide-out-to-bottom-10 data-[side=left]:data-closed:slide-out-to-left-10 data-[side=right]:data-closed:slide-out-to-right-10 data-[side=top]:data-closed:slide-out-to-top-10", o),
		...f,
		children: [l, d && /* @__PURE__ */ i(n.Close, {
			"data-slot": "sheet-close",
			asChild: !0,
			children: /* @__PURE__ */ a(e, {
				variant: "ghost",
				className: "absolute top-3 right-3",
				size: "icon-sm",
				children: [/* @__PURE__ */ i(r, {}), /* @__PURE__ */ i("span", {
					className: "sr-only",
					children: "Close"
				})]
			})
		})]
	})] });
}
function u({ className: e, ...n }) {
	return /* @__PURE__ */ i("div", {
		"data-slot": "sheet-header",
		className: t("flex flex-col gap-0.5 p-4", e),
		...n
	});
}
function d({ className: e, ...r }) {
	return /* @__PURE__ */ i(n.Title, {
		"data-slot": "sheet-title",
		className: t("font-heading text-base font-medium text-foreground", e),
		...r
	});
}
function f({ className: e, ...r }) {
	return /* @__PURE__ */ i(n.Description, {
		"data-slot": "sheet-description",
		className: t("text-sm text-muted-foreground", e),
		...r
	});
}
//#endregion
export { o as Sheet, l as SheetContent, f as SheetDescription, u as SheetHeader, d as SheetTitle };
