import "react";
import { cn as e } from "cn";
import { Accordion as t } from "radix-ui";
import { ChevronDownIcon as n, ChevronUpIcon as r } from "lucide-react";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
//#region src/components/ui/accordion.tsx
function o({ className: n, ...r }) {
	return /* @__PURE__ */ i(t.Root, {
		"data-slot": "accordion",
		className: e("flex w-full flex-col", n),
		...r
	});
}
function s({ className: n, ...r }) {
	return /* @__PURE__ */ i(t.Item, {
		"data-slot": "accordion-item",
		className: e("not-last:border-b", n),
		...r
	});
}
function c({ className: o, children: s, ...c }) {
	return /* @__PURE__ */ i(t.Header, {
		className: "flex",
		children: /* @__PURE__ */ a(t.Trigger, {
			"data-slot": "accordion-trigger",
			className: e("group/accordion-trigger relative flex flex-1 items-start justify-between rounded-lg border border-transparent py-2.5 text-left text-sm font-medium transition-all outline-none hover:underline focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 focus-visible:after:border-ring disabled:pointer-events-none disabled:opacity-50 **:data-[slot=accordion-trigger-icon]:ml-auto **:data-[slot=accordion-trigger-icon]:size-4 **:data-[slot=accordion-trigger-icon]:text-muted-foreground", o),
			...c,
			children: [
				s,
				/* @__PURE__ */ i(n, {
					"data-slot": "accordion-trigger-icon",
					className: "pointer-events-none shrink-0 group-aria-expanded/accordion-trigger:hidden"
				}),
				/* @__PURE__ */ i(r, {
					"data-slot": "accordion-trigger-icon",
					className: "pointer-events-none hidden shrink-0 group-aria-expanded/accordion-trigger:inline"
				})
			]
		})
	});
}
function l({ className: n, children: r, ...a }) {
	return /* @__PURE__ */ i(t.Content, {
		"data-slot": "accordion-content",
		className: "overflow-hidden text-sm data-open:animate-accordion-down data-closed:animate-accordion-up",
		...a,
		children: /* @__PURE__ */ i("div", {
			className: e("h-(--radix-accordion-content-height) pt-0 pb-2.5 [&_a]:underline [&_a]:underline-offset-3 [&_a]:hover:text-foreground [&_p:not(:last-child)]:mb-4", n),
			children: r
		})
	});
}
//#endregion
export { o as Accordion, l as AccordionContent, s as AccordionItem, c as AccordionTrigger };
