//#region src/components/button/button.runtime.ts
var e = {
	variant: "primary",
	type: "button",
	disabled: !1,
	loading: !1
};
//#endregion
export { e as buttonDefaults };
