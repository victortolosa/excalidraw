import { typographyProps as e } from "../../lib/typography.js";
import { buttonVariants as t } from "../ui/button.js";
import { actionIcons as n } from "../../lib/action-icons.js";
import { catalogVariants as r, systemClasses as i } from "./button-styles.js";
import { cn as a } from "../../lib/utils.js";
import { jsx as o, jsxs as s } from "react/jsx-runtime";
//#region src/components/button/navigation-cta.tsx
function c({ label: c, href: l, icon: u, variant: d = "primary" }) {
	let f = u ? n[u] : void 0;
	return /* @__PURE__ */ s("a", {
		...e("button", "label"),
		href: l,
		"data-navigation-cta": d,
		className: a(t({
			variant: r[d],
			size: "lg"
		}), i),
		children: [/* @__PURE__ */ o("span", {
			className: "min-w-0 break-words",
			children: c
		}), f && /* @__PURE__ */ o(f, {
			"aria-hidden": "true",
			className: "size-4 shrink-0"
		})]
	});
}
//#endregion
export { c as NavigationCta };
