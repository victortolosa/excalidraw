import { buttonDefaults as e } from "./button.runtime.js";
import { actionIconNames as t } from "../../lib/action-icon-names.js";
import { z as n } from "zod";
//#region src/components/button/button.contract.ts
var r = t, i = [
	"primary",
	"secondary",
	"ghost",
	"destructive"
], a = [
	"button",
	"submit",
	"reset"
], o = [{
	when: {
		disabled: !0,
		loading: !0
	},
	message: "Use loading for pending work and disabled for unavailable actions, not both."
}], s = (e, t) => Object.entries(t).every(([t, n]) => e[t] === n), c = n.strictObject({
	children: n.string().regex(/\S/).meta({ description: "Visible text label and accessible name. Describe the action, such as \"Save changes\"." }),
	icon: n.enum(r).optional().describe("Decorative action glyph; visible text remains the accessible name."),
	iconPosition: n.enum(["start", "end"]).optional().describe("Icon placement; defaults to start when an icon is supplied."),
	variant: n.enum(i).default(e.variant).meta({ description: "primary is the main action in a region; secondary is an alternative action; destructive marks an irreversible action with a tinted fill; ghost is a low-prominence action with no resting fill or visible border." }),
	type: n.enum(a).default(e.type).meta({ description: "Native button type. Use submit only for the action that submits its form." }),
	disabled: n.boolean().default(e.disabled).meta({ description: "Action is unavailable. Removes the button from the tab order." }),
	loading: n.boolean().default(e.loading).meta({ description: "Action is in progress. Keeps focus, ignores activation, and sets aria-disabled." })
}).superRefine((e, t) => {
	e.iconPosition && !e.icon && t.addIssue({
		code: "custom",
		path: ["iconPosition"],
		message: "Icon position requires an icon."
	});
	for (let n of o) s(e, n.when) && t.addIssue({
		code: "custom",
		message: n.message
	});
}).meta({
	title: "Button",
	description: "Triggers an action or submits a form. Not for navigation; use a link.",
	allOf: [...o.map((e) => ({ not: {
		required: Object.keys(e.when),
		properties: Object.fromEntries(Object.entries(e.when).map(([e, t]) => [e, { const: t }]))
	} })), {
		if: { required: ["iconPosition"] },
		then: { required: ["icon"] }
	}]
});
//#endregion
export { r as buttonIcons, o as buttonInvalidCombinations, c as buttonSchema, a as buttonTypes, i as buttonVariants };
