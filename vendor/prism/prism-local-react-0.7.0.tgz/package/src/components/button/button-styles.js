//#region src/components/button/button-styles.ts
var e = {
	primary: "default",
	secondary: "outline",
	ghost: "ghost",
	destructive: "outline"
}, t = [
	"transition-none h-auto max-w-full whitespace-normal text-center focus-visible:ring-ring",
	"px-[calc(var(--button-padding-x)-1px)] py-[calc(var(--button-padding-y)-1px)] gap-(--button-gap) rounded-(--button-radius)",
	"text-(length:--button-font-size) leading-(--button-line-height) font-(--button-font-weight)"
].join(" ");
//#endregion
export { e as catalogVariants, t as systemClasses };
