//#region src/components/button/button.meta.ts
var e = {
	id: "button",
	name: "Button",
	status: "experimental",
	sources: {
		styles: "src/components/button/button-styles.ts",
		"navigation-implementation": "src/components/button/navigation-cta.tsx",
		"navigation-contract": "src/components/button/navigation-cta.contract.ts",
		contract: "src/components/button/button.contract.ts",
		implementation: "src/components/button/button.tsx",
		catalog: "src/components/ui/button.tsx",
		guidance: "src/components/button/button.mdx",
		fixtures: "src/components/button/button.fixtures.ts",
		stories: "src/components/button/button.stories.tsx",
		"catalog-spinner": "src/components/ui/spinner.tsx"
	},
	tokens: [
		"primary",
		"primary-foreground",
		"background",
		"foreground",
		"border",
		"input",
		"muted",
		"ring",
		"destructive"
	],
	origin: {
		kind: "shadcn-wrapper",
		catalogSources: ["catalog", "catalog-spinner"]
	},
	dependencies: []
};
//#endregion
export { e as buttonMeta };
