import { typographyProps as e } from "../../lib/typography.js";
import { Button as t } from "../ui/button.js";
import { Spinner as n } from "../ui/spinner.js";
import { buttonDefaults as r } from "./button.runtime.js";
import { actionIcons as i } from "../../lib/action-icons.js";
import { buttonMeta as a } from "./button.meta.js";
import { catalogVariants as o, systemClasses as s } from "./button-styles.js";
import { jsx as c, jsxs as l } from "react/jsx-runtime";
//#region src/components/button/button.tsx
function u({ children: u, icon: d, iconPosition: f = "start", variant: p = r.variant, type: m = r.type, disabled: h = r.disabled, loading: g = r.loading, onClick: _, ...v }) {
	let y = d ? i[d] : void 0;
	return /* @__PURE__ */ l(t, {
		...v,
		variant: o[p],
		size: "lg",
		type: m,
		disabled: h,
		"aria-disabled": g || void 0,
		...e("button", "label"),
		"data-component": a.id,
		onClick: (e) => {
			if (g) return e.preventDefault();
			_?.(e);
		},
		className: `${s} ${p === "destructive" ? "bg-destructive/10 text-destructive border-destructive hover:bg-destructive/10 hover:text-destructive dark:bg-destructive/20 dark:hover:bg-destructive/20" : p === "secondary" ? "dark:bg-background dark:hover:bg-muted" : p === "ghost" ? "text-foreground dark:hover:bg-muted" : ""}`,
		children: [
			g && /* @__PURE__ */ c(n, {
				"aria-hidden": "true",
				"data-icon": "inline-start"
			}),
			y && f === "start" && /* @__PURE__ */ c(y, {
				"aria-hidden": "true",
				className: "size-4 shrink-0"
			}),
			/* @__PURE__ */ c("span", {
				className: "min-w-0 break-words",
				children: u
			}),
			y && f === "end" && /* @__PURE__ */ c(y, {
				"aria-hidden": "true",
				className: "size-4 shrink-0"
			})
		]
	});
}
//#endregion
export { u as Button };
