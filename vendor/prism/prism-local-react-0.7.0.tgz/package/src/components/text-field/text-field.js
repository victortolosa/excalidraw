import { typographyProps as e } from "../../lib/typography.js";
import { Field as t, FieldDescription as n, FieldError as r, FieldLabel as i } from "../ui/field.js";
import { Input as a } from "../ui/input.js";
import { textFieldDefaults as o } from "./text-field.runtime.js";
import { useId as s } from "react";
import { jsx as c, jsxs as l } from "react/jsx-runtime";
//#region src/components/text-field/text-field.tsx
function u({ label: u, labelVisibility: d = o.labelVisibility, description: f, error: p, id: m, type: h = o.type, required: g = o.required, disabled: _ = o.disabled, readOnly: v = o.readOnly, ...y }) {
	let b = s(), x = m ?? b, S = [f && `${x}-description`, p && `${x}-error`].filter(Boolean).join(" ") || void 0;
	return /* @__PURE__ */ l(t, {
		"data-component": "text-field",
		"data-invalid": !!p,
		"data-disabled": _,
		className: "min-w-0",
		children: [
			/* @__PURE__ */ l(i, {
				...e("text-field", "label"),
				htmlFor: x,
				className: d === "hidden" ? "sr-only" : "break-words",
				children: [u, g && /* @__PURE__ */ c("span", {
					"aria-hidden": "true",
					children: " (required)"
				})]
			}),
			/* @__PURE__ */ c(a, {
				...e("text-field", "control"),
				...y,
				id: x,
				type: h,
				required: g,
				disabled: _,
				readOnly: v,
				"aria-invalid": p ? !0 : void 0,
				"aria-describedby": S,
				className: "transition-none text-foreground focus-visible:ring-ring aria-invalid:focus-visible:ring-ring"
			}),
			f && /* @__PURE__ */ c(n, {
				...e("text-field", "description"),
				id: `${x}-description`,
				className: "break-words",
				children: f
			}),
			p && /* @__PURE__ */ c(r, {
				...e("text-field", "error"),
				id: `${x}-error`,
				className: "break-words",
				children: p
			})
		]
	});
}
//#endregion
export { u as TextField };
