import { typographyProps as e } from "../../lib/typography.js";
import { SectionSpacingContext as t } from "../../lib/section-spacing-context.js";
import { contentWidthClasses as n } from "../../lib/layout.js";
import { pageDefaults as r } from "./page.runtime.js";
import { useId as i } from "react";
import { jsx as a, jsxs as o } from "react/jsx-runtime";
//#region src/components/page/page.tsx
function s({ id: s = r.id, title: c, labelledBy: l, header: u, description: d, width: f = r.width, layout: p = r.layout, surface: m, scheme: h, sectionSpacing: g, actionsLayout: _ = r.actionsLayout, actions: v, children: y }) {
	let b = i(), x = p === "full-bleed", S = x ? `mx-auto w-full min-w-0 p-panel ${n[f]}` : "", C = _ === "inline" ? "grid grid-cols-[minmax(0,1fr)_auto] items-start" : _ === "stacked" ? "flex flex-col items-start" : "flex flex-wrap items-start";
	return /* @__PURE__ */ o("main", {
		"data-component": "page",
		"data-layout": p,
		"data-section-spacing": g,
		"data-scheme": h,
		"data-surface": h ? void 0 : m,
		id: s,
		"aria-labelledby": l ?? b,
		tabIndex: -1,
		className: `mx-auto w-full min-w-0 wrap-anywhere focus-visible:outline-2 focus-visible:outline-ring ${h ?? m ? "bg-background text-foreground " : ""}${x ? "" : `p-panel ${n[f]}`}`,
		children: [l ? /* @__PURE__ */ a("div", {
			className: `mb-section ${S}`,
			children: u
		}) : /* @__PURE__ */ o("div", {
			"data-page-header": !0,
			"data-actions-layout": _,
			className: `mb-section min-w-0 gap-x-stack gap-y-tight ${C} ${S}`,
			children: [
				/* @__PURE__ */ a("h1", {
					...e("page", "title"),
					id: b,
					className: `min-w-0 font-heading text-3xl font-semibold wrap-anywhere ${_ === "inline" ? "col-start-1 row-start-1" : "order-1 grow basis-auto"}`,
					children: c
				}),
				d && /* @__PURE__ */ a("div", {
					className: `min-w-0 w-full ${_ === "inline" ? "col-start-1 row-start-2" : `basis-full ${_ === "stacked" ? "order-2" : "order-3"}`}`,
					children: /* @__PURE__ */ a("p", {
						...e("page", "description"),
						className: "max-w-prose text-muted-foreground wrap-anywhere",
						children: d
					})
				}),
				v && /* @__PURE__ */ a("div", {
					"data-page-actions": !0,
					className: `flex min-w-0 max-w-full flex-wrap items-start gap-tight ${_ === "inline" ? "col-start-2 row-start-1" : _ === "stacked" ? "order-3 basis-full" : "order-2 flex-[0_1_auto]"}`,
					children: v
				})
			]
		}), /* @__PURE__ */ a("div", {
			...e("page", "body"),
			className: `grid min-w-0 wrap-anywhere ${x || g ? "gap-0" : "gap-section"}`,
			children: /* @__PURE__ */ a(t, {
				value: g,
				children: y
			})
		})]
	});
}
//#endregion
export { s as Page };
