//#region src/components/page/page.runtime.ts
var e = {
	id: "main-content",
	width: "standard",
	layout: "contained",
	actionsLayout: "auto"
};
//#endregion
export { e as pageDefaults };
