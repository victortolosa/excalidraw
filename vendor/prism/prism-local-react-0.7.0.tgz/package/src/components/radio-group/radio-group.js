import { typographyProps as e } from "../../lib/typography.js";
import { Field as t, FieldContent as n, FieldDescription as r, FieldError as i, FieldLabel as a, FieldLegend as o, FieldSet as s } from "../ui/field.js";
import { RadioGroup as c, RadioGroupItem as l } from "../ui/radio-group.js";
import { radioGroupDefaults as u } from "./radio-group.runtime.js";
import { useId as d } from "react";
import { jsx as f, jsxs as p } from "react/jsx-runtime";
//#region src/components/radio-group/radio-group.tsx
function m({ label: m, options: h, description: g, error: _, id: v, name: y, required: b = u.required, disabled: x = u.disabled, orientation: S = u.orientation, value: C, defaultValue: w, onValueChange: T }) {
	let E = d(), D = v ?? E, O = [g && `${D}-description`, _ && `${D}-error`].filter(Boolean).join(" ") || void 0;
	return /* @__PURE__ */ p(s, {
		"data-component": "radio-group",
		"data-invalid": !!_,
		"data-disabled": x,
		className: "min-w-0",
		children: [
			/* @__PURE__ */ p(o, {
				...e("radio-group", "legend"),
				className: "break-words",
				children: [m, b && /* @__PURE__ */ f("span", {
					"aria-hidden": "true",
					children: " (required)"
				})]
			}),
			/* @__PURE__ */ f(c, {
				id: D,
				name: y,
				value: C,
				defaultValue: w,
				onValueChange: T,
				disabled: x,
				required: b,
				"aria-invalid": _ ? !0 : void 0,
				"aria-describedby": O,
				className: S === "horizontal" ? "flex flex-wrap gap-4" : "grid gap-2",
				children: h.map((i) => {
					let o = `${D}-${i.value}`, s = x || i.disabled;
					return /* @__PURE__ */ p(t, {
						orientation: "horizontal",
						"data-disabled": s,
						className: "min-w-0",
						children: [/* @__PURE__ */ f(l, {
							id: o,
							value: i.value,
							disabled: s,
							className: "focus-visible:ring-ring aria-invalid:focus-visible:ring-ring"
						}), /* @__PURE__ */ p(n, { children: [/* @__PURE__ */ f(a, {
							...e("radio-group", "label"),
							htmlFor: o,
							className: "break-words",
							children: i.label
						}), i.description && /* @__PURE__ */ f(r, {
							...e("radio-group", "option-description"),
							className: "break-words",
							children: i.description
						})] })]
					}, i.value);
				})
			}),
			g && /* @__PURE__ */ f(r, {
				...e("radio-group", "description"),
				id: `${D}-description`,
				className: "break-words",
				children: g
			}),
			_ && /* @__PURE__ */ f(i, {
				...e("radio-group", "error"),
				id: `${D}-error`,
				className: "break-words",
				children: _
			})
		]
	});
}
//#endregion
export { m as RadioGroup };
