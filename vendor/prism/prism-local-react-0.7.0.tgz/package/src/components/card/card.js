import { typographyProps as e } from "../../lib/typography.js";
import { Card as t, CardContent as n, CardDescription as r, CardHeader as i } from "../ui/card.js";
import { cardDefaults as a } from "./card.runtime.js";
import { useId as o } from "react";
import { jsx as s, jsxs as c } from "react/jsx-runtime";
//#region src/components/card/card.tsx
function l({ title: l, label: u, description: d, surface: f, scheme: p, headingLevel: m = a.headingLevel, children: h }) {
	let g = o(), _ = `h${m}`;
	return /* @__PURE__ */ c(t, {
		"data-component": "card",
		"data-scheme": p,
		"data-surface": p ? void 0 : f,
		role: "group",
		"aria-labelledby": l ? g : void 0,
		"aria-label": l ? void 0 : u,
		className: "min-w-0 overflow-visible",
		children: [l && /* @__PURE__ */ c(i, { children: [/* @__PURE__ */ s(_, {
			...e("card", "title"),
			id: g,
			className: "min-w-0 break-words font-heading text-base font-medium leading-snug",
			children: l
		}), d && /* @__PURE__ */ s(r, {
			...e("card", "description"),
			className: "break-words",
			children: d
		})] }), /* @__PURE__ */ s(n, {
			...e("card", "body"),
			className: "min-w-0",
			children: h
		})]
	});
}
//#endregion
export { l as Card };
