//#region src/components/card/card.runtime.ts
var e = { headingLevel: "2" };
//#endregion
export { e as cardDefaults };
