import { typographyProps as e } from "../../lib/typography.js";
import { Field as t, FieldContent as n, FieldDescription as r, FieldError as i, FieldLabel as a } from "../ui/field.js";
import { Checkbox as o } from "../ui/checkbox.js";
import { checkboxDefaults as s } from "./checkbox.runtime.js";
import { useId as c } from "react";
import { jsx as l, jsxs as u } from "react/jsx-runtime";
//#region src/components/checkbox/checkbox.tsx
function d({ label: d, description: f, error: p, id: m, name: h, value: g, form: _, required: v = s.required, disabled: y = s.disabled, checked: b, defaultChecked: x = s.defaultChecked, onCheckedChange: S }) {
	let C = c(), w = m ?? C, T = [f && `${w}-description`, p && `${w}-error`].filter(Boolean).join(" ") || void 0;
	return /* @__PURE__ */ u(t, {
		"data-component": "checkbox",
		"data-invalid": !!p,
		"data-disabled": y,
		orientation: "horizontal",
		className: "min-w-0",
		children: [/* @__PURE__ */ l(o, {
			id: w,
			name: h,
			value: g,
			form: _,
			disabled: y,
			required: v,
			checked: b,
			defaultChecked: x,
			onCheckedChange: S,
			"aria-invalid": p ? !0 : void 0,
			"aria-describedby": T,
			className: "focus-visible:ring-ring aria-invalid:focus-visible:ring-ring"
		}), /* @__PURE__ */ u(n, { children: [
			/* @__PURE__ */ u(a, {
				...e("checkbox", "label"),
				htmlFor: w,
				className: "break-words",
				children: [d, v && /* @__PURE__ */ l("span", {
					"aria-hidden": "true",
					children: " (required)"
				})]
			}),
			f && /* @__PURE__ */ l(r, {
				...e("checkbox", "description"),
				id: `${w}-description`,
				className: "break-words",
				children: f
			}),
			p && /* @__PURE__ */ l(i, {
				...e("checkbox", "error"),
				id: `${w}-error`,
				className: "break-words",
				children: p
			})
		] })]
	});
}
//#endregion
export { d as Checkbox };
