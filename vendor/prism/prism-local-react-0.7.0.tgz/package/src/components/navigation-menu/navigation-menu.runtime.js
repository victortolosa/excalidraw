//#region src/components/navigation-menu/navigation-menu.runtime.ts
var e = { orientation: "horizontal" };
//#endregion
export { e as navigationMenuDefaults };
