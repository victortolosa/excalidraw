import { typographyProps as e } from "../../lib/typography.js";
import { NavigationMenu as t, NavigationMenuItem as n, NavigationMenuLink as r, NavigationMenuList as i } from "../ui/navigation-menu.js";
import { navigationMenuDefaults as a } from "./navigation-menu.runtime.js";
import { jsx as o } from "react/jsx-runtime";
//#region src/components/navigation-menu/navigation-menu.tsx
function s({ label: s, items: c, currentId: l, orientation: u = a.orientation }) {
	return /* @__PURE__ */ o(t, {
		"data-component": "navigation-menu",
		"aria-label": s,
		orientation: u,
		viewport: !1,
		className: "max-w-full min-w-0 justify-start",
		children: /* @__PURE__ */ o(i, {
			className: u === "vertical" ? "min-w-0 flex-col items-stretch" : "min-w-0 flex-wrap justify-start",
			children: c.map((t) => /* @__PURE__ */ o(n, {
				className: "min-w-0 max-w-full",
				children: /* @__PURE__ */ o(r, {
					...e("navigation-menu", "link"),
					href: t.href,
					active: t.id === l,
					className: "whitespace-normal wrap-anywhere focus-visible:ring-ring data-active:underline data-active:underline-offset-4",
					children: t.label
				})
			}, t.id))
		})
	});
}
//#endregion
export { s as NavigationMenu };
