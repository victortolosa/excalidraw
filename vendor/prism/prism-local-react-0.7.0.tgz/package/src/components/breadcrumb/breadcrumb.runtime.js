//#region src/components/breadcrumb/breadcrumb.runtime.ts
var e = { label: "Breadcrumb" };
//#endregion
export { e as breadcrumbDefaults };
