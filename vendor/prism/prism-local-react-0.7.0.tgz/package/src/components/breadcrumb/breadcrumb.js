import { typographyProps as e } from "../../lib/typography.js";
import { Breadcrumb as t, BreadcrumbItem as n, BreadcrumbLink as r, BreadcrumbList as i, BreadcrumbPage as a, BreadcrumbSeparator as o } from "../ui/breadcrumb.js";
import { breadcrumbDefaults as s } from "./breadcrumb.runtime.js";
import { Fragment as c } from "react";
import { jsx as l, jsxs as u } from "react/jsx-runtime";
//#region src/components/breadcrumb/breadcrumb.tsx
function d({ label: d = s.label, items: f }) {
	return /* @__PURE__ */ l(t, {
		"data-component": "breadcrumb",
		"aria-label": d,
		children: /* @__PURE__ */ l(i, { children: f.map((t, i) => /* @__PURE__ */ u(c, { children: [i > 0 && /* @__PURE__ */ l(o, {}), /* @__PURE__ */ l(n, {
			className: "min-w-0 max-w-full",
			children: t.current ? /* @__PURE__ */ l(a, {
				...e("breadcrumb", "current"),
				className: "break-words",
				children: t.label
			}) : /* @__PURE__ */ l(r, {
				...e("breadcrumb", "link"),
				href: t.href,
				className: "break-words focus-visible:outline-2 focus-visible:outline-ring",
				children: t.label
			})
		})] }, t.id)) })
	});
}
//#endregion
export { d as Breadcrumb };
