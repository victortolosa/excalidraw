//#region src/components/item/item.runtime.ts
var e = { variant: "plain" };
//#endregion
export { e as itemDefaults };
