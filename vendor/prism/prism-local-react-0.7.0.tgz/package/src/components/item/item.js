import { typographyProps as e } from "../../lib/typography.js";
import { Item as t, ItemActions as n, ItemContent as r, ItemDescription as i, ItemGroup as a, ItemTitle as o } from "../ui/item.js";
import { itemDefaults as s } from "./item.runtime.js";
import { jsx as c, jsxs as l } from "react/jsx-runtime";
//#region src/components/item/item.tsx
var u = {
	plain: "default",
	outlined: "outline"
};
function d({ title: a, description: d, status: f, variant: p = s.variant, children: m }) {
	return /* @__PURE__ */ l(t, {
		role: "listitem",
		variant: u[p],
		"data-component": "item",
		className: "rounded-panel",
		children: [/* @__PURE__ */ l(r, {
			className: "min-w-0",
			children: [/* @__PURE__ */ c(o, {
				...e("item", "title"),
				className: "line-clamp-none wrap-anywhere",
				children: a
			}), d && /* @__PURE__ */ c(i, {
				...e("item", "description"),
				className: "line-clamp-none wrap-anywhere",
				children: d
			})]
		}), (f || m) && /* @__PURE__ */ l(n, {
			className: "min-w-0 flex-wrap",
			children: [f && /* @__PURE__ */ c("span", {
				...e("item", "status"),
				className: "text-muted-foreground",
				children: f
			}), m]
		})]
	});
}
function f({ label: e, children: t }) {
	return /* @__PURE__ */ c(a, {
		"aria-label": e,
		"data-component": "item-group",
		children: t
	});
}
//#endregion
export { d as Item, f as ItemGroup };
