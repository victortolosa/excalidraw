import { typographyProps as e } from "../../lib/typography.js";
import { SectionSpacingContext as t } from "../../lib/section-spacing-context.js";
import { contentWidthClasses as n } from "../../lib/layout.js";
import { sectionDefaults as r } from "./section.runtime.js";
import { useContext as i, useId as a } from "react";
import { Fragment as o, jsx as s, jsxs as c } from "react/jsx-runtime";
//#region src/components/section/section.tsx
function l({ title: l, description: u, headingLevel: d = r.headingLevel, titleStyle: f = r.titleStyle, surface: p, scheme: m, contentWidth: h, contentScheme: g, sectionSpacing: _, actions: v, children: y }) {
	let b = i(t), x = _ ?? b, S = a(), C = l ? "section" : "div", w = `h${d}`, T = m ?? p, E = /* @__PURE__ */ c(o, { children: [(l || u || v) && /* @__PURE__ */ c("div", {
		className: "flex min-w-0 flex-col gap-3 sm:flex-row sm:items-start sm:justify-between",
		children: [/* @__PURE__ */ c("div", {
			className: "min-w-0 space-y-1",
			children: [l && (f === "label" ? /* @__PURE__ */ s(w, {
				...e("section", "label"),
				id: S,
				className: "text-muted-foreground wrap-anywhere",
				children: l
			}) : /* @__PURE__ */ s(w, {
				...e("section", "title"),
				id: S,
				className: "font-heading text-xl font-semibold wrap-anywhere",
				children: l
			})), u && /* @__PURE__ */ s("p", {
				...e("section", "description"),
				className: "max-w-prose text-muted-foreground wrap-anywhere",
				children: u
			})]
		}), v && /* @__PURE__ */ s("div", {
			className: "flex min-w-0 flex-wrap gap-tight",
			children: v
		})]
	}), /* @__PURE__ */ s("div", {
		...e("section", "body"),
		className: "grid min-w-0 gap-stack wrap-anywhere",
		children: y
	})] }), D = g ? /* @__PURE__ */ s("div", {
		"data-section-surface": "",
		"data-scheme": g,
		className: "grid min-w-0 gap-stack bg-background p-panel text-foreground wrap-anywhere",
		children: E
	}) : E;
	return /* @__PURE__ */ s(C, {
		"data-component": "section",
		"data-section-spacing": x,
		"data-scheme": m,
		"data-surface": m ? void 0 : p,
		"aria-labelledby": l ? S : void 0,
		className: `grid min-w-0 gap-stack wrap-anywhere ${T ? "bg-background text-foreground" : ""} ${h ? "py-panel" : T ? "p-panel" : ""}`,
		children: /* @__PURE__ */ s(t, {
			value: void 0,
			children: h ? /* @__PURE__ */ s("div", {
				"data-section-content": "",
				className: `mx-auto grid w-full min-w-0 gap-stack px-panel wrap-anywhere ${n[h]}`,
				children: D
			}) : D
		})
	});
}
//#endregion
export { l as Section };
