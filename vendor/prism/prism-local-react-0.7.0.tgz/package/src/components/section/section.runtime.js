//#region src/components/section/section.runtime.ts
var e = {
	headingLevel: "2",
	titleStyle: "default"
};
//#endregion
export { e as sectionDefaults };
