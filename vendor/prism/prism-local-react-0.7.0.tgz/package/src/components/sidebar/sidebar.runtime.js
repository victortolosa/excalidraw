//#region src/components/sidebar/sidebar.runtime.ts
var e = { collapsed: !1 };
//#endregion
export { e as sidebarDefaults };
