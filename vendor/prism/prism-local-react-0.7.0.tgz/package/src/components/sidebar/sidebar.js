import { typographyProps as e } from "../../lib/typography.js";
import { TooltipProvider as t } from "../ui/tooltip.js";
import { Sidebar as n, SidebarContent as r, SidebarGroup as i, SidebarGroupContent as a, SidebarGroupLabel as o, SidebarMenu as s, SidebarMenuButton as c, SidebarMenuItem as l, SidebarProvider as u, SidebarTrigger as d } from "../ui/sidebar.js";
import { sidebarDefaults as f } from "./sidebar.runtime.js";
import { ChartNoAxesColumn as p, Folder as m, House as h, Layers3 as g, Settings as _, Users as v } from "lucide-react";
import { jsx as y, jsxs as b } from "react/jsx-runtime";
//#region src/components/sidebar/sidebar.tsx
var x = {
	home: h,
	layers: g,
	folder: m,
	settings: _,
	users: v,
	chart: p
};
function S({ label: p, items: m, currentId: h, collapsed: g = f.collapsed }) {
	return /* @__PURE__ */ y(t, { children: /* @__PURE__ */ b(u, {
		defaultOpen: !g,
		"data-component": "sidebar",
		children: [/* @__PURE__ */ y(n, {
			collapsible: "icon",
			children: /* @__PURE__ */ y(r, { children: /* @__PURE__ */ y("nav", {
				"aria-label": p,
				children: /* @__PURE__ */ b(i, { children: [/* @__PURE__ */ y(o, {
					...e("sidebar", "group"),
					children: p
				}), /* @__PURE__ */ y(a, { children: /* @__PURE__ */ y(s, { children: m.map((t) => {
					let n = x[t.icon], r = t.id === h;
					return /* @__PURE__ */ y(l, { children: /* @__PURE__ */ y(c, {
						asChild: !0,
						isActive: r,
						tooltip: { children: /* @__PURE__ */ y("span", {
							...e("sidebar", "tooltip"),
							children: t.label
						}) },
						children: /* @__PURE__ */ b("a", {
							...e("sidebar", r ? "active-link" : "link"),
							href: t.href,
							"aria-current": r ? "page" : void 0,
							children: [/* @__PURE__ */ y(n, { "aria-hidden": "true" }), /* @__PURE__ */ y("span", { children: t.label })]
						})
					}) }, t.id);
				}) }) })] })
			}) })
		}), /* @__PURE__ */ y(d, { "aria-label": `Toggle ${p}` })]
	}) });
}
//#endregion
export { S as Sidebar };
