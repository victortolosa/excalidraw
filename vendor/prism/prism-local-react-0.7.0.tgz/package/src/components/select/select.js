import { typographyProps as e } from "../../lib/typography.js";
import { Field as t, FieldDescription as n, FieldError as r, FieldLabel as i } from "../ui/field.js";
import { Select as a, SelectContent as o, SelectItem as s, SelectTrigger as c, SelectValue as l } from "../ui/select.js";
import { selectDefaults as u } from "./select.runtime.js";
import { createElement as d, useId as f } from "react";
import { jsx as p, jsxs as m } from "react/jsx-runtime";
//#region src/components/select/select.tsx
function h({ label: h, labelVisibility: g = u.labelVisibility, options: _, placeholder: v, description: y, error: b, id: x, name: S, required: C = u.required, disabled: w = u.disabled, value: T, defaultValue: E, onValueChange: D, open: O, onOpenChange: k }) {
	let A = f(), j = x ?? A, M = `${j}-trigger`, N = [y && `${j}-description`, b && `${j}-error`].filter(Boolean).join(" ") || void 0;
	return /* @__PURE__ */ m(t, {
		"data-component": "select",
		"data-invalid": !!b,
		"data-disabled": w,
		className: "min-w-0",
		children: [
			/* @__PURE__ */ m(i, {
				...e("select", "label"),
				htmlFor: M,
				className: g === "hidden" ? "sr-only" : "break-words",
				children: [h, C && /* @__PURE__ */ p("span", {
					"aria-hidden": "true",
					children: " (required)"
				})]
			}),
			/* @__PURE__ */ m(a, {
				name: S,
				disabled: w,
				required: C,
				value: T,
				defaultValue: E,
				onValueChange: D,
				open: O,
				onOpenChange: k,
				children: [/* @__PURE__ */ p(c, {
					...e("select", "control"),
					id: M,
					"aria-invalid": b ? !0 : void 0,
					"aria-describedby": N,
					className: "transition-none w-full text-foreground focus-visible:ring-ring aria-invalid:focus-visible:ring-ring",
					children: /* @__PURE__ */ p(l, { placeholder: v })
				}), /* @__PURE__ */ p(o, { children: _.map((t) => /* @__PURE__ */ d(s, {
					...e("select", "option"),
					key: t.value,
					value: t.value,
					disabled: t.disabled
				}, t.label)) })]
			}),
			y && /* @__PURE__ */ p(n, {
				...e("select", "description"),
				id: `${j}-description`,
				className: "break-words",
				children: y
			}),
			b && /* @__PURE__ */ p(r, {
				...e("select", "error"),
				id: `${j}-error`,
				className: "break-words",
				children: b
			})
		]
	});
}
//#endregion
export { h as Select };
