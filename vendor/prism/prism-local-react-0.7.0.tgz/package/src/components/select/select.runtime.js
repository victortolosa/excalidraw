//#region src/components/select/select.runtime.ts
var e = {
	labelVisibility: "visible",
	required: !1,
	disabled: !1
};
//#endregion
export { e as selectDefaults };
