//#region src/components/alert/alert.meta.ts
var e = {
	id: "alert",
	name: "Alert",
	status: "experimental",
	sources: {
		contract: "src/components/alert/alert.contract.ts",
		implementation: "src/components/alert/alert.tsx",
		guidance: "src/components/alert/alert.mdx",
		fixtures: "src/components/alert/alert.fixtures.ts",
		stories: "src/components/alert/alert.stories.tsx",
		catalog: "src/components/ui/alert.tsx"
	},
	tokens: [
		"border",
		"card",
		"card-foreground",
		"destructive",
		"info",
		"muted-foreground",
		"success",
		"warning"
	],
	origin: {
		kind: "shadcn-wrapper",
		catalogSources: ["catalog"]
	},
	dependencies: []
};
//#endregion
export { e as alertMeta };
