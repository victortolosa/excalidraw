//#region src/components/alert/alert.runtime.ts
var e = {
	variant: "neutral",
	live: "off"
};
//#endregion
export { e as alertDefaults };
