import { typographyProps as e } from "../../lib/typography.js";
import { Alert as t, AlertDescription as n, AlertTitle as r } from "../ui/alert.js";
import { alertDefaults as i } from "./alert.runtime.js";
import { alertMeta as a } from "./alert.meta.js";
import { CircleAlertIcon as o, CircleCheckIcon as s, InfoIcon as c, TriangleAlertIcon as l } from "lucide-react";
import { jsx as u, jsxs as d } from "react/jsx-runtime";
//#region src/components/alert/alert.tsx
var f = {
	neutral: "default",
	info: "default",
	success: "default",
	warning: "default",
	destructive: "destructive"
}, p = {
	info: "text-info *:data-[slot=alert-description]:text-info/90",
	success: "text-success *:data-[slot=alert-description]:text-success/90",
	warning: "text-warning *:data-[slot=alert-description]:text-warning/90"
}, m = {
	info: c,
	success: s,
	warning: l,
	destructive: o
}, h = "wrap-anywhere", g = {
	off: void 0,
	polite: "status",
	assertive: "alert"
};
function _({ title: o, description: s, variant: c = i.variant, live: l = i.live, action: _ }) {
	let v = c === "neutral" ? void 0 : m[c];
	return /* @__PURE__ */ d(t, {
		variant: f[c],
		role: g[l],
		"data-component": a.id,
		"data-variant": c,
		className: p[c],
		children: [
			v && /* @__PURE__ */ u(v, { "aria-hidden": "true" }),
			/* @__PURE__ */ u(r, {
				...e("alert", "title"),
				className: h,
				children: o
			}),
			s && /* @__PURE__ */ u(n, {
				...e("alert", "description"),
				className: h,
				children: s
			}),
			_ && /* @__PURE__ */ u("div", {
				"data-alert-action": !0,
				className: `mt-2 justify-self-start ${v ? "col-start-2" : ""}`,
				children: _
			})
		]
	});
}
//#endregion
export { _ as Alert };
