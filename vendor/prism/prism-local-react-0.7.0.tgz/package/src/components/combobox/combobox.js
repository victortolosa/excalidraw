import { typographyProps as e } from "../../lib/typography.js";
import { Field as t, FieldDescription as n, FieldError as r, FieldLabel as i } from "../ui/field.js";
import { Combobox as a, ComboboxContent as o, ComboboxEmpty as s, ComboboxInput as c, ComboboxItem as l, ComboboxList as u } from "../ui/combobox.js";
import { comboboxDefaults as d } from "./combobox.runtime.js";
import { createElement as f, useId as p } from "react";
import { jsx as m, jsxs as h } from "react/jsx-runtime";
//#region src/components/combobox/combobox.tsx
function g({ label: g, labelVisibility: _ = d.labelVisibility, options: v, placeholder: y, description: b, error: x, id: S, name: C, form: w, required: T = d.required, disabled: E = d.disabled, openOnInputClick: D = d.openOnInputClick, value: O, defaultValue: k, onValueChange: A, open: j, onOpenChange: M, onInputValueChange: N }) {
	let P = p(), F = S ?? P, I = b ? `${F}-description` : void 0, L = x ? `${F}-error` : void 0, R = [I, L].filter(Boolean).join(" ") || void 0;
	return /* @__PURE__ */ h(t, {
		"data-component": "combobox",
		"data-invalid": !!x,
		"data-disabled": E,
		className: "min-w-0",
		children: [
			/* @__PURE__ */ h(i, {
				...e("combobox", "label"),
				htmlFor: F,
				className: _ === "hidden" ? "sr-only" : "break-words",
				children: [g, T && /* @__PURE__ */ m("span", {
					"aria-hidden": "true",
					children: " (required)"
				})]
			}),
			/* @__PURE__ */ h(a, {
				name: C,
				form: w,
				required: T,
				disabled: E,
				openOnInputClick: D,
				value: O,
				defaultValue: k,
				onValueChange: A,
				open: j,
				onOpenChange: M,
				onInputValueChange: N,
				items: v,
				itemToStringLabel: (e) => e.label ?? v.find((t) => t.value === e.value)?.label ?? e.value,
				itemToStringValue: (e) => e.value,
				children: [/* @__PURE__ */ m(c, {
					...e("combobox", "control"),
					id: F,
					"aria-label": g,
					placeholder: y,
					"aria-invalid": x ? !0 : void 0,
					"aria-describedby": R,
					showClear: !1,
					showTrigger: !1,
					disabled: E,
					className: "w-full text-foreground focus-visible:ring-ring aria-invalid:focus-visible:ring-ring"
				}), /* @__PURE__ */ h(o, {
					"aria-label": `${g} options`,
					children: [/* @__PURE__ */ m(u, {
						"aria-label": `${g} options`,
						children: (t) => /* @__PURE__ */ f(l, {
							...e("combobox", "option"),
							key: t.value,
							value: t,
							disabled: t.disabled
						}, t.label)
					}), /* @__PURE__ */ m(s, {
						...e("combobox", "empty"),
						children: "No matching options."
					})]
				})]
			}),
			b && /* @__PURE__ */ m(n, {
				...e("combobox", "description"),
				id: I,
				className: "break-words",
				children: b
			}),
			x && /* @__PURE__ */ m(r, {
				...e("combobox", "error"),
				id: L,
				className: "break-words",
				children: x
			})
		]
	});
}
//#endregion
export { g as Combobox };
