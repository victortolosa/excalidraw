//#region src/components/site-footer/site-footer.runtime.ts
var e = {
	navigationLabel: "Footer",
	legalLabel: "Legal",
	groups: [],
	legalLinks: []
};
//#endregion
export { e as siteFooterDefaults };
