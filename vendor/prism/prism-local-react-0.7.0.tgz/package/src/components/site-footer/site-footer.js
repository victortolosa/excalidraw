import { typographyProps as e } from "../../lib/typography.js";
import { Badge as t } from "../badge/badge.js";
import { contentWidthClasses as n } from "../../lib/layout.js";
import { siteFooterDefaults as r } from "./site-footer.runtime.js";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
//#region src/components/site-footer/site-footer.tsx
var o = "underline underline-offset-4 wrap-anywhere focus-visible:outline-2 focus-visible:outline-ring";
function s({ siteName: s, description: c, groups: l = r.groups, navigationLabel: u = r.navigationLabel, legalLabel: d = r.legalLabel, legalText: f, legalLinks: p = r.legalLinks, status: m }) {
	return /* @__PURE__ */ i("footer", {
		"data-component": "site-footer",
		className: "border-t border-border",
		children: /* @__PURE__ */ a("div", {
			className: `mx-auto grid w-full min-w-0 gap-section p-panel ${n.wide}`,
			children: [
				(s || c) && /* @__PURE__ */ a("div", {
					className: "min-w-0 space-y-tight",
					children: [s && /* @__PURE__ */ i("p", {
						...e("site-footer", "identity"),
						className: "font-heading text-xl font-semibold wrap-anywhere",
						children: s
					}), c && /* @__PURE__ */ i("p", {
						...e("site-footer", "description"),
						className: "max-w-prose text-muted-foreground wrap-anywhere",
						children: c
					})]
				}),
				l.length > 0 && /* @__PURE__ */ i("nav", {
					"aria-label": u,
					className: "grid min-w-0 gap-6 sm:grid-cols-2 lg:grid-cols-3",
					children: l.map((t) => /* @__PURE__ */ a("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ i("h2", {
							...e("site-footer", "group-title"),
							className: "mb-3 font-heading font-semibold wrap-anywhere",
							children: t.title
						}), /* @__PURE__ */ i("ul", {
							className: "space-y-tight",
							children: t.links.map((t) => /* @__PURE__ */ i("li", { children: /* @__PURE__ */ i("a", {
								...e("site-footer", "link"),
								href: t.href,
								className: o,
								children: t.label
							}) }, t.id))
						})]
					}, t.id))
				}),
				/* @__PURE__ */ a("div", {
					className: "flex min-w-0 flex-col gap-stack border-t border-border pt-stack sm:flex-row sm:items-start sm:justify-between",
					children: [/* @__PURE__ */ a("div", {
						className: "flex min-w-0 flex-wrap items-center gap-stack",
						children: [/* @__PURE__ */ i("p", {
							...e("site-footer", "legal"),
							className: "min-w-0 text-sm text-muted-foreground wrap-anywhere",
							children: f
						}), m && /* @__PURE__ */ i(t, { children: m })]
					}), p.length > 0 && /* @__PURE__ */ i("nav", {
						"aria-label": d,
						children: /* @__PURE__ */ i("ul", {
							className: "flex min-w-0 flex-wrap gap-stack text-sm",
							children: p.map((t) => /* @__PURE__ */ i("li", { children: /* @__PURE__ */ i("a", {
								...e("site-footer", "legal-link"),
								href: t.href,
								className: o,
								children: t.label
							}) }, t.id))
						})
					})]
				})
			]
		})
	});
}
//#endregion
export { s as SiteFooter };
