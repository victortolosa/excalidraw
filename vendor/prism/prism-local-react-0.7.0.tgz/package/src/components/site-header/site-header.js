import { typographyProps as e } from "../../lib/typography.js";
import { Button as t } from "../button/button.js";
import { NavigationMenu as n } from "../navigation-menu/navigation-menu.js";
import { contentWidthClasses as r } from "../../lib/layout.js";
import { Collapsible as i, CollapsibleContent as a, CollapsibleTrigger as o } from "../ui/collapsible.js";
import { NavigationCta as s } from "../button/navigation-cta.js";
import { siteHeaderDefaults as c } from "./site-header.runtime.js";
import { useRef as l, useState as u } from "react";
import { jsx as d, jsxs as f } from "react/jsx-runtime";
//#region src/components/site-header/site-header.tsx
function p({ siteName: p, homeHref: m, logoSrc: h, navigation: g, mainId: _ = c.mainId, menuLabel: v = c.menuLabel, skipLabel: y = c.skipLabel, layout: b = c.layout, primaryAction: x, navigationPlacement: S = c.navigationPlacement, identityContent: C, actions: w }) {
	let [T, E] = u(!1), D = l(null);
	return /* @__PURE__ */ f("header", {
		"data-component": "site-header",
		"data-layout": b,
		className: "border-b border-border",
		children: [/* @__PURE__ */ d("a", {
			...e("site-header", "skip-link"),
			href: `#${_}`,
			onClick: () => document.getElementById(_)?.focus(),
			className: "sr-only z-50 rounded-panel bg-background p-3 text-foreground focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus-visible:outline-2 focus-visible:outline-ring",
			children: y
		}), /* @__PURE__ */ f("div", {
			className: `mx-auto flex w-full min-w-0 flex-wrap items-center gap-stack p-panel ${r.wide} ${b === "distributed" ? "justify-between" : ""}`,
			children: [
				/* @__PURE__ */ f("div", {
					"data-header-region": "identity",
					className: "flex min-w-0 max-w-full flex-wrap items-center gap-tight",
					children: [/* @__PURE__ */ f("a", {
						...e("site-header", "identity"),
						href: m,
						className: "flex min-w-0 max-w-full items-center gap-tight font-heading text-xl font-semibold wrap-anywhere focus-visible:outline-2 focus-visible:outline-ring",
						children: [h && /* @__PURE__ */ d("img", {
							src: h,
							alt: "",
							width: 32,
							height: 32,
							className: "h-8 w-8 shrink-0 object-contain"
						}), p]
					}), C]
				}),
				/* @__PURE__ */ f("div", {
					"data-header-group": S,
					className: S === "with-actions" ? "ml-auto flex min-w-0 max-w-full flex-wrap items-center justify-end gap-stack" : "contents",
					children: [/* @__PURE__ */ d("div", {
						"data-header-region": "navigation",
						className: "hidden min-w-0 md:block",
						children: /* @__PURE__ */ d(n, { ...g })
					}), (x || w) && /* @__PURE__ */ f("div", {
						"data-header-region": "actions",
						className: "flex min-w-0 max-w-full flex-wrap items-center gap-tight",
						children: [w, x && /* @__PURE__ */ d(s, { ...x })]
					})]
				}),
				/* @__PURE__ */ f(i, {
					open: T,
					onOpenChange: E,
					onKeyDown: (e) => {
						e.key === "Escape" && T && (e.preventDefault(), E(!1), D.current?.focus());
					},
					className: "w-full min-w-0 md:hidden",
					children: [/* @__PURE__ */ d(o, {
						asChild: !0,
						children: /* @__PURE__ */ d(t, {
							ref: D,
							variant: "secondary",
							children: v
						})
					}), /* @__PURE__ */ d(a, {
						className: "pt-3",
						onClick: (e) => {
							e.target.closest("a") && E(!1);
						},
						children: /* @__PURE__ */ d(n, {
							...g,
							orientation: "vertical"
						})
					})]
				})
			]
		})]
	});
}
//#endregion
export { p as SiteHeader };
