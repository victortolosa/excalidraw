import { Button as e } from "../../components/button/button.js";
import { Card as t } from "../../components/card/card.js";
import { TextField as n } from "../../components/text-field/text-field.js";
import { signupFormDefaults as r } from "./signup-form.runtime.js";
import { signupCredentialsSchema as i } from "./signup-form.contract.js";
import { useRef as a, useState as o } from "react";
import { jsx as s, jsxs as c } from "react/jsx-runtime";
//#region src/blocks/signup-form/signup-form.tsx
var l = [
	"name",
	"email",
	"password",
	"confirmation"
];
function u({ onSubmit: u, onGoogleSignup: d, signInHref: f, ...p }) {
	let m = {
		...r,
		...p
	}, [h, g] = o({
		name: "",
		email: "",
		password: "",
		confirmation: ""
	}), [_, v] = o({}), [y, b] = o(null), [x, S] = o(""), [C, w] = o(""), T = a(!1), E = {
		name: a(null),
		email: a(null),
		password: a(null),
		confirmation: a(null)
	};
	function D(e, t) {
		g((n) => ({
			...n,
			[e]: t
		})), v((t) => ({
			...t,
			[e]: void 0
		})), S(""), w("");
	}
	async function O(e, t) {
		if (!T.current) {
			T.current = !0, b(e), w(""), S(e === "submit" ? "Submitting your information…" : "Starting Google signup…");
			try {
				let e = await t();
				S(e.message), g((e) => ({
					...e,
					password: "",
					confirmation: ""
				}));
			} catch {
				S(""), w(e === "submit" ? "Account creation failed. Your values are still here. Please try again." : "Google signup could not start. Please try again.");
			} finally {
				T.current = !1, b(null);
			}
		}
	}
	return /* @__PURE__ */ s("div", {
		"data-block": "signup-form",
		className: "min-w-0",
		children: /* @__PURE__ */ s(t, {
			title: m.title,
			description: m.description,
			children: /* @__PURE__ */ c("form", {
				noValidate: !0,
				"aria-label": m.title,
				"aria-busy": !!y,
				className: "grid min-w-0 gap-stack",
				onSubmit: (e) => {
					if (e.preventDefault(), T.current) return;
					let t = i.safeParse(h);
					if (!t.success) {
						let e = {};
						for (let n of t.error.issues) {
							let t = n.path[0];
							e[t] || (e[t] = n.message);
						}
						v(e), S("Check the highlighted fields."), w("");
						let n = l.find((t) => e[t]);
						n && E[n].current?.focus();
						return;
					}
					v({});
					let { confirmation: n, ...r } = t.data;
					O("submit", () => u(r));
				},
				children: [
					/* @__PURE__ */ s(n, {
						label: m.nameLabel,
						name: "name",
						autoComplete: "name",
						required: !0,
						ref: E.name,
						value: h.name,
						onChange: (e) => D("name", e.target.value),
						error: _.name,
						readOnly: !!y
					}),
					/* @__PURE__ */ s(n, {
						label: m.emailLabel,
						description: m.emailDescription,
						name: "email",
						type: "email",
						autoComplete: "email",
						required: !0,
						ref: E.email,
						value: h.email,
						onChange: (e) => D("email", e.target.value),
						error: _.email,
						readOnly: !!y
					}),
					/* @__PURE__ */ s(n, {
						label: m.passwordLabel,
						description: m.passwordDescription,
						name: "password",
						type: "password",
						autoComplete: "new-password",
						required: !0,
						ref: E.password,
						value: h.password,
						onChange: (e) => D("password", e.target.value),
						error: _.password,
						readOnly: !!y
					}),
					/* @__PURE__ */ s(n, {
						label: m.confirmationLabel,
						description: m.confirmationDescription,
						name: "confirmation",
						type: "password",
						autoComplete: "new-password",
						required: !0,
						ref: E.confirmation,
						value: h.confirmation,
						onChange: (e) => D("confirmation", e.target.value),
						error: _.confirmation,
						readOnly: !!y
					}),
					/* @__PURE__ */ c("div", {
						className: "flex min-w-0 flex-col items-stretch gap-tight",
						children: [/* @__PURE__ */ s(e, {
							type: "submit",
							...y === "google" ? { disabled: !0 } : { loading: y === "submit" },
							children: m.submitLabel
						}), /* @__PURE__ */ s(e, {
							variant: "secondary",
							...y === "submit" ? { disabled: !0 } : { loading: y === "google" },
							onClick: () => {
								O("google", d);
							},
							children: m.providerLabel
						})]
					}),
					/* @__PURE__ */ c("p", {
						className: "text-center text-sm text-muted-foreground wrap-anywhere",
						children: [
							m.signInPrompt,
							" ",
							/* @__PURE__ */ s("a", {
								href: f,
								className: "underline underline-offset-4 focus-visible:outline-2 focus-visible:outline-ring",
								children: m.signInLabel
							})
						]
					}),
					/* @__PURE__ */ s("p", {
						role: "status",
						className: "text-sm wrap-anywhere",
						children: x
					}),
					C && /* @__PURE__ */ s("p", {
						role: "alert",
						className: "text-sm text-destructive wrap-anywhere",
						children: C
					})
				]
			})
		})
	});
}
//#endregion
export { u as SignupForm };
