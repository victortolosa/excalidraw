//#region src/blocks/signup-form/signup-form.runtime.ts
var e = {
	title: "Create an account",
	description: "Enter your information below to create your account",
	nameLabel: "Full Name",
	emailLabel: "Email",
	emailDescription: "We'll use this to contact you.",
	passwordLabel: "Password",
	passwordDescription: "Must be at least 8 characters long.",
	confirmationLabel: "Confirm Password",
	confirmationDescription: "Please confirm your password.",
	submitLabel: "Create Account",
	providerLabel: "Sign up with Google",
	signInPrompt: "Already have an account?",
	signInLabel: "Sign in"
};
//#endregion
export { e as signupFormDefaults };
