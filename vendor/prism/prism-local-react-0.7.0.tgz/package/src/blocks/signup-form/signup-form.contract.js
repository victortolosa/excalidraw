import { signupFormDefaults as e } from "./signup-form.runtime.js";
import { z as t } from "zod";
//#region src/blocks/signup-form/signup-form.contract.ts
var n = t.string().regex(/\S/);
t.strictObject({
	title: n.default(e.title),
	description: n.default(e.description),
	nameLabel: n.default(e.nameLabel),
	emailLabel: n.default(e.emailLabel),
	emailDescription: n.default(e.emailDescription),
	passwordLabel: n.default(e.passwordLabel),
	passwordDescription: n.default(e.passwordDescription),
	confirmationLabel: n.default(e.confirmationLabel),
	confirmationDescription: n.default(e.confirmationDescription),
	submitLabel: n.default(e.submitLabel),
	providerLabel: n.default(e.providerLabel),
	signInPrompt: n.default(e.signInPrompt),
	signInLabel: n.default(e.signInLabel),
	signInHref: t.string().regex(/^(\/[^/]|https?:\/\/|#[A-Za-z])/).describe("Supplied navigation destination; never a fake action.")
}).meta({
	title: "SignupForm",
	description: "A signup form with name, email, password confirmation, Google signup and sign-in navigation. Caller owns authentication."
});
var r = t.strictObject({
	name: t.string().trim().min(1, "Enter your full name."),
	email: t.email("Enter a valid email address."),
	password: t.string().min(8, "Use at least 8 characters."),
	confirmation: t.string().min(1, "Confirm your password.")
}).refine((e) => e.password === e.confirmation, {
	path: ["confirmation"],
	message: "Passwords must match."
});
//#endregion
export { r as signupCredentialsSchema };
