import { Button as e } from "../../components/button/button.js";
import { NavigationCta as t } from "../../components/button/navigation-cta.js";
import { heroDefaults as n } from "./hero.runtime.js";
import { Fragment as r, jsx as i, jsxs as a } from "react/jsx-runtime";
//#region src/blocks/hero/hero.tsx
function o({ headingId: o, heading: s, eyebrow: c, description: l, composition: u = n.composition, primaryAction: d, secondaryAction: f, media: p, mediaContent: m, onAction: h, pendingAction: g }) {
	let _ = u !== "split", v = (n, r = !1) => n.kind === "link" ? /* @__PURE__ */ i(t, {
		label: n.label,
		href: n.href,
		icon: n.icon,
		variant: r ? "secondary" : "primary"
	}) : /* @__PURE__ */ i(e, {
		variant: r ? "secondary" : "primary",
		icon: n.icon,
		iconPosition: n.icon ? "end" : void 0,
		...g === n.id ? { loading: !0 } : { disabled: !!g || !h },
		onClick: () => h?.(n.id),
		children: n.label
	});
	return /* @__PURE__ */ a("section", {
		"data-block": "hero",
		"aria-labelledby": o,
		className: `grid min-w-0 gap-section py-section ${u === "split" ? "md:grid-cols-2 md:items-center" : ""}`,
		children: [/* @__PURE__ */ a("div", {
			className: `flex min-w-0 flex-col gap-stack ${_ ? "items-center text-center mx-auto max-w-3xl" : ""}`,
			children: [
				c && /* @__PURE__ */ i("p", {
					className: "font-mono text-xs uppercase tracking-wider text-muted-foreground",
					children: c
				}),
				/* @__PURE__ */ i("h1", {
					id: o,
					"aria-label": s.map((e) => (e.breakBefore ? " " : "") + e.text).join(""),
					className: "font-heading text-3xl sm:text-4xl font-semibold leading-tight wrap-anywhere",
					children: s.map((e, t) => /* @__PURE__ */ a("span", { children: [e.breakBefore && /* @__PURE__ */ a(r, { children: [" ", /* @__PURE__ */ i("br", {})] }), /* @__PURE__ */ i("span", {
						className: e.emphasis ? "text-primary italic font-normal" : void 0,
						children: e.text
					})] }, t))
				}),
				l && /* @__PURE__ */ i("p", {
					className: "max-w-prose text-muted-foreground wrap-anywhere",
					children: l
				}),
				(d || f) && /* @__PURE__ */ a("div", {
					className: `flex min-w-0 flex-wrap items-center gap-stack ${_ ? "justify-center" : ""}`,
					children: [d && v(d), f && v(f, !0)]
				})
			]
		}), p && /* @__PURE__ */ i("div", {
			className: "min-w-0",
			children: p.kind === "image" ? /* @__PURE__ */ i("img", {
				src: p.src,
				alt: p.alt,
				width: p.width,
				height: p.height,
				className: "h-auto w-full rounded-panel object-contain"
			}) : /* @__PURE__ */ i("div", {
				role: "group",
				"aria-label": p.label,
				children: m
			})
		})]
	});
}
//#endregion
export { o as Hero };
