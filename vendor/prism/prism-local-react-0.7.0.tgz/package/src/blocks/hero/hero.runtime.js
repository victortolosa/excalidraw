//#region src/blocks/hero/hero.runtime.ts
var e = { composition: "centered" };
//#endregion
export { e as heroDefaults };
