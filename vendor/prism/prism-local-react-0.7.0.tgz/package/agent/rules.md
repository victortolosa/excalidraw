# Design System Rules

Rules for agents implementing approved designs using this design system. They apply during the **translation phase** (Phase 3) of the workflow, not during exploration or design approval. See [workflow](workflow.md).

**When these rules apply:** You have an approved design (layout, hierarchy, content, interaction are settled). Your job is to map it to the system components, tokens, and contracts, and ensure the code is verifiable and maintainable.

**When these rules do NOT apply:**
- Exploration phases: no system constraints, any tool, design intent is the goal
- Design approval phases: design review, not code decisions
- Decisions already approved by design: "the approved design calls for X" overrides these rules

Production uses supported blocks and completed system-tier components with contracts, guidance, and maintained Storybook coverage. Catalog demonstrations, and candidate previews are not approved library entries. Match the shipped component code, contracts, and token definitions exactly. You may create new screen designs and local compositions from supported building blocks when the result is well understood and verifiable. Identify designs that go beyond documented system patterns to the user; do not present them as supported system patterns or components.

An explicitly authorized FPO-enabled implementation may contain labeled, local temporary elements under the [FPO prototype exception](audit.md#optional-fpo-prototype-mode). They are not supported library entries and must be resolved before application promotion. Strict system translation remains the default.


## Pre-generation audit gate

Follow the authoritative [production audit policy](audit.md) before screen generation. It owns readiness, mapping evidence, departures and review, including static demos.

## Choose experience, platform and viewport independently

Identify product or marketing experience, target platform, viewport and input needs separately. Mobile web is React web at a narrow viewport, not a separate component family. Native iOS/Android implementations are outside this release's scope. Do not conflate marketing with spacious density or product with compact density.

Select by purpose and required behavior first. Prefer a fitting supported block, then shared components and native content/layout. Block context describes intended usage, not an exclusive consumer restriction. Shared primitives remain shared; only documented anatomy, API or behavior differences warrant separate components. Check the selected release inventory before referencing any API: repository presence or Storybook grouping does not imply it ships.

For product experiences preserve task flow, validation, state feedback and information density. For marketing preserve the content narrative, navigation semantics and primary/secondary CTA hierarchy. Both require accessible names, keyboard focus, touch targets, readable contrast, responsive overflow checks and reduced-motion handling where relevant. Read selected contracts and guidance; context never grants unsupported variants or styling overrides.

## 1. Find a component in this order

1. Read release discovery (repository reference; not installed). Only its components and blocks are installed supported APIs; an empty block list means no blocks ship. Select by purpose and experience, not appearance alone.
2. Read selected guidance, serializable schemas and referenced React declarations. Retrieve only what the mapping needs. Use recipes (repository reference; not installed) for working examples.
3. Compose supported parts and native content/layout. Unsupported needs follow section 6; upstream discovery is evidence for a contribution, not permission for direct catalog use. Never rebuild Prism context or assume a source checkout is available.

## 2. Prefer the system tier

- Use a system component when one covers the need, even if a catalog component with the same name exists.
- Do not use unported catalog components (`src/components/ui/`) directly in production screens. Contributor catalog demos and system wrappers may use them within their ownership boundaries.
- For full pages, use Page for the main landmark and H1; put named regions in Section. When SiteHeader is exported, its skip link must target Page `id`. When exported, use SiteFooter for grouped site navigation and legal links when the layout calls for one. For full-width regional backgrounds, use Page `layout="full-bleed"` and Section `contentWidth`; Section `contentScheme` optionally paints and resets its inner content surface. Default contained layouts remain supported. Consult [composition recipes](recipes.md#page-and-site-recipes).
- Choose page rhythm with optional `Page sectionSpacing="compact"`, `"standard"`, or `"spacious"`. Sections inherit the preset and can explicitly override it; nested Sections keep legacy spacing unless configured. Explicit Page rhythm removes the content-stack gap and uses Section padding inside its background. Group content in Sections when it needs that rhythm. Keep control density independent; omit the setting to preserve legacy layouts. See [Page layout](../context/page.md).
- Candidate inventories and Storybook Candidates entries are discovery records, not supported component APIs. Check status and limitations before reuse, and disclose their candidate status as a deviation (section 5).
- Never edit either tier to finish a screen. Changes to components are system work, proposed through a gap note.

## 3. Style with roles, never values

- Color comes from semantic role utilities only: `bg-background`, `text-foreground`, `text-muted-foreground`, `border-border`, and so on. The roles are the keys of `required` in `../theme-policy.json`.
- No hex, rgb, or oklch colors, Tailwind palette colors (`bg-blue-500`), or inline color styles.
- No font stacks, radii, or spacing chosen per brand. Brand typography, shape, and density come from tokens (`font-heading`, `font-sans`, `rounded-panel`, `p-panel`).
- System components accept no `className` or `style`. Put layout (spacing, width, grid placement) on a parent element.
- Catalog components accept `className` for layout only, never for color or typography overrides.

## 4. Apply themes with attributes

- Mode is a page decision. Set `data-mode` on `<html>`. Overlays render at the end of `<body>` and only see the page theme.
- Scheme is a container decision. Set `data-scheme` on a section or container, and give that container `bg-background text-foreground`. Card inherits the regional scheme and paints card roles by default; its optional `scheme` prop resets the full context when needed.
- Leaf components (Button, inputs, badges) never take a scheme. They adapt to the scheme they sit on.
- A container nested in another scheme keeps that scheme unless it sets its own. Set `data-scheme="default"` to reset. `data-surface` and the `surface` prop are temporary compatibility aliases.
- Valid mode and scheme names are listed in `../theme-policy.json`. Schemes are named by purpose; see [theming](theming.md#configured-schemes) for what each is for.

## 5. Build new parts from existing ones

A pattern is reusable guidance for a user goal, including component selection, content, states, and interaction rules. Apply a documented pattern when it fits; a pattern never grants unsupported props or variants. A composite is a local implementation, while a screen is a complete product view. Promote shared implementation only when repeated use or a stable contract justifies system work.

A need no single component covers is usually a composite. Resolve its supported composition in the audit before treating the need as a gap or building screen code. New layouts, content arrangements, and combinations are welcome when they serve the user goal and use supported APIs and tokens exactly. They do not need to match an existing story or recipe.

- Supported blocks in the release inventory are maintained compositions with contracts and source provenance. Prefer a fitting block before recreating its assembly. Block callbacks and product services remain caller-owned.
- A production composite is built only from approved system components, native layout elements, and role and layout utilities. Examples: a stat tile, an empty state, a settings row.
- Put it in its own file next to the code that uses it, under `src/screens/<screen>/` or `src/features/<feature>/`. It needs no contract or gap note.
- A composite adds structure, not options to the parts inside it. A wrapper that restyles a component or mimics a variant it lacks, such as a `DangerButton`, is a faked variant. That is a gap.

Before using a composition not covered by documented patterns, confirm that each part's contract and guidance permit its use, the interaction can use native semantics or installed accessible primitives, and the relevant states, themes, and viewport sizes can be checked. If evidence is missing or the behavior is uncertain, use a documented pattern or report a gap. Do not claim confidence from a build alone.

In the final response, label a new composition or reused candidate as a deviation from documented system guidance. Name the local file, the supported components and token roles used, what is new, and the verification performed. This is a design deviation, not a new system API. Ordinary content and layout choices inside a documented pattern need no deviation note.

If the consumer uses Prism’s source Storybook review shell for a new local composition, set `parameters.designReviewKind` to `Local composition`. Existing bespoke previews may retain their historical `Bespoke part` marker. The preview adds a dashed outline and a text label. Keep this marker out of product components and shipped screens; the written deviation note remains required.

```md
Design deviation: <new composition or candidate and why it was used>
Built from: <supported components and token roles>
Location: <local file>
Verified: <states, themes, viewport sizes, and interaction checks actually completed>
```

## 6. Resolve gaps through shadcn discovery

A gap is a need that approved components, tokens, and local composition cannot serve. Never invent a variant, prop, state, or role, or build a bespoke production replacement.

Perform this assessment automatically during ingestion and mapping, before asking the user to resolve a gap; follow the [audit assessment procedure](audit.md#automatic-composition-and-gap-assessment).

1. Decompose the need and try smaller supported parts or a composition that still serves it. Record exact API constraints and distinguish faithful mappings from adaptations; do not bypass documented limitations.
2. Search shadcn using its MCP for a suitable component or block; compare semantics and behavior, not only appearance. If unavailable, disclose the limitation and use official documentation or installed CLI discovery.
3. Record the candidate and required adaptation. A match must enter the normal human-led system process: contract, implementation, guidance, fixtures, metadata, maintained Storybook states, and validation. Existing authorization for the specific system change remains sufficient. Never edit vendored catalog files to finish a screen.
4. If no match fits, propose a new system component or revised design. Keep unresolved work explicit and continue independent supported work.

Production generation begins for a part only after its required system capability is supported. The explicitly authorized FPO prototype exception permits temporary demo work while keeping the system gap open. Routine brand/component translation proceeds without separate approval; consequential departures affecting content, hierarchy, control identity or interaction intent return for review under the audit policy’s translation boundary. Discovery does not approve direct catalog usage. See [workflow](workflow.md) for the stage boundary.

```md
Gap: <required capability>
Component or token: <id, role, or none>
Discovery: <shadcn candidate and source, no match, or tool unavailable>
Used instead: <supported option or left unimplemented>
Proposed extension: <specific promotion, contract, token, or new component work>
```

Existing bespoke files and candidate records remain historical/discovery evidence, not permission to reuse them in production. New local compositions from approved parts remain allowed under section 5.

## 7. Keep native semantics

- Use a link for navigation and a button for actions. On narrow screens, replace dense data tables with readable lists or cards when wrapping would make cells illegible; preserve the same information and actions in both presentations.
- The visible label is the accessible name. Do not replace it with `aria-label`.
- Every input has a visible label. Errors are text, not color alone.
- Do not add click handlers to non-interactive elements or remove focus outlines.

## Group by level

Use the lightest grouping that shows the group: region (Section), panel (Card), row, then status (Alert). Group with spacing first, border second, fill third. Status color belongs to Alert only. Nest at most one level. Product screens do not paint regions. See grouping (repository reference; not installed). Marketing versus product experience and accessibility profiles are proposed in the experience context plan (repository reference; not installed) and are not shipped; do not reference them as available.

## 8. Verify before you finish

Follow consumer validation (repository reference; not installed): run prism-check, strict TypeScript, the app build and relevant browser/interaction checks. Report failures and unverified criteria; do not weaken checks.

## 9. Build in React

Compose React web screens in the consumer project. Review the running app or its own Storybook; installing Prism does not install the source repository theme editor.

## How these rules are checked

Run `prism-check` from the app root (or `prism-check --source <directory>` for custom source locations), followed by the app's TypeScript, build and interaction checks. The packaged check rejects catalog dependencies/imports, private Prism paths, local components/ui sources and recognized catalog copies. It follows local module resolution and rejects computed module loading. It also checks literal visual values, unknown semantic roles, direct component styling and CSS anatomy overrides. Computed styling/prop spreads require review. Runtime mutation and indirect selector/re-export tricks are outside complete static enforcement. Keyboard behavior, accessibility, visual fidelity and theme placement require review beyond a passing build.

## Upstream context

Use current official shadcn documentation for gap discovery. Generic customization instructions do not override Prism contracts or token ownership. Do not replace installed Prism CSS with upstream presets.

## Preserve CTA hierarchy

Navigation semantics do not imply plain-link styling. Preserve primary/secondary visual emphasis during import, using navigation CTA APIs only when they appear in the installed inventory; otherwise record the required supported capability as a gap. Assess semantics and prominence separately; losing primary emphasis is a hierarchy regression, not routine brand translation. Verify rendered fill/outline, contrast, focus and label as well as href or callback behavior.

## Shared system and consumer ownership

The installed release owns shared definitions. Consumer projects own services, routing, state and local supported compositions. Propose reusable gaps upstream; do not edit installed shared code or create a second definition authority. Upgrade code, context and checks together through a reviewed dependency update.
