# Consumer validation

## Validation scope

Run the installed `prism-check`, strict TypeScript and the app build. Add these to the existing validation/CI workflow without replacing project checks. The starter supplies `npm run validate`. Run scoped browser/interaction and axe checks, inspect hierarchy, focus, overflow and responsive states, and report outcomes in the audit. A static check does not establish accessibility, design acceptance, every computed style or native-platform support.
