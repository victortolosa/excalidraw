# Consumer workflow

Read [rules](rules.md), classify experience/platform/viewport, and retrieve selected APIs from [discovery](manifest.json). Record the [audit](audit.md) before screen implementation. Preserve reference controls, CTA hierarchy and intended behavior. Explore freely when exploration is requested; translate approved intent through supported APIs for production. Keep gaps visible and propose shared changes upstream. Review the running app and record actual [verification](validation.md).
