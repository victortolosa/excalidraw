# Pre-generation audit

## Required gate

Before writing or modifying production screens, page fixtures, or page stories, create a task-specific `audit.md` from the template below. Place it at `docs/audits/<task>.md`, or update the existing audit for the screen. Read the selected components’ contracts, installed guidance and recipe evidence before classifying mappings as supported. Use installed runtime evidence to resolve uncertainty; do not require Prism source.

The audit is required for static demos as well as interactive pages. Scope changes alter what is audited, not whether the audit happens. Direct production requests need no redundant exploration approval, but still require the audit.

## Translation boundary

Exploration may happen in any tool or process without Prism brand or component conformance. An approved exploration is a brief for content, hierarchy, user tasks and interaction intent, not an exact visual specification. Production prototyping translates that intent into the requested Prism brand and supported component anatomy.

Routine translation is authorized by a request to build: replace exploratory colors, typography, radii, spacing and incidental geometry with system tokens; use supported component anatomy and responsive layout; correct native semantics and accessibility. Record these adaptations concisely and proceed without separate approval for each one. Do not classify an appearance mismatch alone as a missing system capability. An explicit requirement for exact appearance or a particular identifying cue takes precedence and must be assessed as such.

Consequential departures change substantive content/data, information hierarchy, user tasks, control identity or meaning, interaction outcomes, or explicitly required design features. Resolve these with existing authorization or a focused user decision. Brand translation does not authorize dropping controls, replacing selectors with text, changing navigation into an action, or suppressing required behavior.

Assess each region as direct reuse, routine brand/component adaptation, or consequential decision/required capability gap. Keep faithful page-specific compositions local. Expand the shared system only when existing supported composition cannot serve the intended experience, not merely to copy exploratory styling.

## Optional FPO prototype mode

At import, the user may select strict system translation (default) or an FPO-enabled prototype. Explicit authorization for FPO mode applies to unsupported elements in that import; do not ask again for each routine temporary solution. FPO means “for placement only”: a temporary prototype implementation, not a supported system component. Do not silently enable this mode.

After the automatic composition assessment, FPO mode may use a small local implementation local to the screen to unblock an unsupported element. Prefer supported parts and native semantics, use existing semantic tokens, and retain the intended content/control identity. Do not edit catalog files, invent supported contract props, or register the temporary element in system discovery. Avoid turning a quick substitute into a general component framework.

Label each temporary region visibly “FPO — <element>” in the app and Storybook prototype, with an explanation of incomplete behavior where relevant. A page-level notice alone is insufficient to identify affected elements. Keep review labeling outside reusable product components. Temporary controls must have accessible names and appropriate keyboard behavior; otherwise render an explicitly noninteractive placeholder that preserves the design cue and documents the unavailable interaction. Never imply real persistence or service effects.

Record each FPO element in the audit: local path, missing capability, temporary approach, behavior implemented/unavailable, verification, and replacement plan. Readiness may be `ready` for the explicitly scoped FPO prototype while those system gaps remain open; readiness does not establish production eligibility. Consequential changes to design intent still require authorization. If a temporary solution cannot preserve intent, record the unresolved decision rather than using FPO to conceal it.

Before application promotion, replace every FPO element with supported composition or complete its normal system promotion and verification. User acceptance of the prototype does not waive this requirement.

## Readiness

Use `draft`, `blocked`, or `ready`:

- Draft: evidence or mapping decisions are incomplete.
- Blocked: required capabilities or material design decisions are unresolved.
- Ready: every in-scope element maps to supported APIs or a verified local composition, or an explicitly authorized and labeled FPO element under the prototype exception; required gaps have been resolved; consequential departures are authorized; source evidence and verification criteria are recorded.

Only `ready` authorizes screen generation for the stated scope. A request to build authorizes translation of the approved intent into the requested brand and existing components, including routine adaptations above; it does not silently authorize consequential departures. Existing explicit decisions are sufficient—do not ask again. Produce the concrete audit before asking about unresolved material choices.

While blocked, continue source inspection, discovery, and already-authorized system work. Do not start screen generation. An authorized FPO prototype follows the exception above. Otherwise, a partial build requires an explicitly agreed reduced scope and its own ready decision; omitted requirements remain visible.

Record reference hashes and the manifest source digest. List the selected component IDs, supported APIs and relevant guidance/recipe evidence; do not enumerate every source-file hash. Use individual source hashes only when generated context is unavailable or a specific source change needs tracking. Changed references, contracts, guidance, token vocabulary, or implementation scope reopen affected mappings before further generation. Cosmetic code repairs within the resolved mapping do not require a new approval cycle.

## Automatic composition and gap assessment

Perform this assessment during every reference ingestion and production audit without waiting for an explicit user request. Complete it before presenting an unresolved gap or asking the user to choose between adaptation and system work.

1. Break each reference region and control into content, layout, component anatomy, and behavior. Try smaller supported system components, native content/layout elements, and permitted semantic utilities before classifying the whole region as unsupported.
2. Read the selected contracts, guidance, and installed guidance and recipes; inspect implementations when slots or behavior remain uncertain. Record a concrete composition and its evidence, or the exact API constraint that prevents it. Composition must not bypass documented limitations, restyle internal component anatomy, fake a missing variant, or remove control identity.
3. Classify direct reuse, routine brand/component adaptation, and consequential departures separately. Record intent preserved and concrete differences. Exploratory appearance is not a production fidelity requirement unless explicitly requested; routine translation does not require user approval. Similar appearance or function alone does not establish preservation of content, control identity and interaction intent.
4. For needs still unsupported, follow [consumer gap discovery](rules.md#6-resolve-gaps-through-shadcn-discovery): search callable shadcn MCP tools for a close semantic and behavioral match. If unavailable or failing, record that limitation and use installed CLI discovery and current official documentation. Do not imply that MCP search occurred when using a fallback. Check candidate APIs and source rather than relying on names or screenshots.
5. Assess whether the smallest resolution is local composition, an existing component API extension, promotion of an upstream primitive, or an authorized design adaptation. Keep page-specific compositions local unless demonstrated reuse or a stable contract warrants system work. Discovery alone does not authorize installation, promotion, direct catalog use, or a material redesign.
6. Record a concise assessment in the task audit: supported mappings and evidence, routine adaptations, actual gaps and consequential decisions, discovery only where needed, recommended resolution, confidence and verification remaining. Avoid repeating component documentation or workflow policy. Ask only about consequential decisions that remain unresolved and lack existing authorization. Continue independent authorized work.

This assessment is required in static and interactive scope. It is source-backed feasibility review until the composition is rendered and verified; do not describe proposed compositions as tested. The readiness gate remains unchanged.

## Experience and accessibility profile

Proposed in the experience context plan (repository reference; not installed); not yet enforced by checks.

Every audit records the experience (`marketing` or `product`), platform and viewport, and the accessibility profile it ran under. Choose experience by purpose, not by density or spacing.

Every profile meets WCAG 2.2 AA; the floor cannot be configured off. Two house rules vary:

| Option | Values | Default |
| --- | --- | --- |
| labels | `visible-required`, `contextual-allowed` | `visible-required` |
| targets | `24`, `44` | `24`; `44` recommended for touch-first apps |

Components behave identically under every profile. A profile changes only which of these rules the audit enforces.

## Audit artifact

Create the audit from the [audit template](audit-template.md). Fill it with evidence before marking ready; an audit draft does not establish implementation readiness.

## Generation brief

The ready audit is the generation brief. Retrieve only the selected component entries, contract fields, guidance sections and stories needed to resolve decisions. Load that context once, implement the recorded mappings and departures, and reopen discovery only for affected changes. For repeated compositions, reuse verified local examples; extract shared code only when another use demonstrates reuse. New primitive promotion is not the default solution to a layout need.

## Preserve reference controls

Inventory every visible control, including controls implied by a screenshot even when the source HTML uses a non-semantic element. Record location, visible label/current value, identifying cues, intended role, supported mapping, and scoped behavior. Repeated controls may share a row if their instances and locations are explicit. Do not invent unseen options or behavior; record uncertainty that affects the mapping.

Static scope preserves control identity and resting appearance. It does not authorize replacing a selector with text, removing its selection indicator, or turning an action into metadata. Use supported component anatomy and semantics; do not paint a fake control to bypass a missing API. Normal local component interaction may remain available without application integration. State separately whether opening, fixture selection, navigation, persistence, and backend effects are in scope; neither require new behavior nor suppress existing primitive behavior merely because the page is called static.

Choose by purpose: value selection, action menus, and navigation are different mappings. Check Prism contracts rather than assuming upstream capabilities are exposed. The [WAI-ARIA patterns](https://www.w3.org/WAI/ARIA/apg/patterns/) clarify semantic distinctions; they do not grant unsupported Prism APIs.

If supported components cannot preserve a required control, record an unresolved gap and apply the readiness gate. Replacing a control with content or removing its identifying cues is a material departure requiring explicit authorization, unless that exact departure is already authorized. Static-only scope is not that authorization. An organization/workspace label with a selection indicator must be audited as a possible switcher, not silently mapped to a paragraph.

After generation, reconcile every inventory row with the rendered page: confirm its location, label/value, supported semantics, and identifying cues, or its authorized departure. Record pass, failure, or not verified per row. DOM/story checks can establish presence and role; inspect rendered resting states for visual cues. This targeted check applies to static demos without requiring a screenshot comparison pipeline. Unchecked or mismatched controls remain delivery limitations; a passing build or text-completeness check does not establish control coverage.

## Generation and review

Before the first implementation edit, present the audit summary and readiness decision with a link. Proceed when ready and already authorized. Generate from the recorded mappings; proposed deviations reopen affected decisions. The mechanical scaffold may exist before readiness, but reference UI must not.

Check implementation against the audit's observable criteria. Report concrete deviations, gaps, and checks after generation. Inspect the branded prototype for hierarchy, usability, responsive behavior and intended interactions; passing component checks alone does not establish design quality. Present it for user design review: approval of exploration is not acceptance of the branded prototype. Exact screenshot matching is not the default acceptance criterion; no screenshot-pair pipeline is required. Never backdate an audit.

Follow [validation scope](validation.md#validation-scope): consumer changes use prism-check, TypeScript, the app build and scoped browser checks plus the observable audit criteria. Record failures without weakening checks.

This is an agent-enforced process gate; no deterministic readiness or authorization checker is delivered.

## Keep the audit useful

Use the audit as the demo's generation brief and final record. Capture actual decisions rather than repeating workflow policy or component documentation. Check available slots, heading levels and content order before generation; disclose a late-discovered departure honestly and reopen its mapping if material. Never rewrite history to imply a decision was made earlier.

Record substantive source content as fixtures or a short content inventory. Acceptance checks should detect omitted text/data, incorrect hierarchy and overflow in the scoped themes/viewports. A total regression-test count does not establish reference completeness. Interactive behavior is checked only when in scope; static scope does not imply disabled controls.

Append verification results, concrete callouts and retained evidence paths in the same audit. The project plan links to that artifact. A demo needs no separate README or review report unless it has unique operating instructions. Separate project reviews are for system changes or meaningful experiments; preserve existing historical records.

## Evidence retention and disposal

Keep only evidence that answers an acceptance criterion or documents a concrete concern. Screenshots are optional inspection records, not a comparison pipeline. Task evidence lives in `docs/audits/<task>/`; list every retained path in the audit. Full transient logs may stay outside the repository; record commands and outcomes in the audit.

To discard a prototype, remove its local implementation and story only after checking dependent imports. Remove evidence that is exclusive to discarded work when authorized; repair retained links. Do not introduce automated deletion.

## Supported block assessment

During the automatic composition assessment, check `agent/manifest.json` (the installed block inventory) before rebuilding a supported assembly. Read selected installed block schema, guidance, dependencies and recipes; an empty block inventory means none ship. Only supported entries in generated block discovery may be mapped into production; upstream registry packaging, planned queues and candidates do not establish eligibility. Record adaptations and caller-owned services in the audit.

## Preserve CTA hierarchy

Navigation semantics do not imply plain-link styling. Preserve primary/secondary visual emphasis during import, using navigation CTA APIs only when exported by the installed release; otherwise record a gap. Assess semantics and prominence separately; losing primary emphasis is a hierarchy regression, not routine brand translation. Verify rendered fill/outline, contrast, focus and label as well as href or callback behavior.
