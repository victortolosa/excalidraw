# Screen audit

## Brief and release

Record the user intent, reference evidence, installed version/source digest, experience (product/marketing), accessibility profile (default AA, labels visible-required, targets 24), platform, viewport/input needs and static/interactive scope.

## Readiness

Draft, blocked or ready, with evidence. Resolve material departures and required gaps before production generation. An explicitly authorized FPO prototype must record each temporary element and replacement plan.

## Mapping and control inventory

| Region/control and visible label/value | Purpose and behavior | Supported API and installed guidance | Adaptation or gap | Verification criterion |
| --- | --- | --- | --- | --- |

## Gaps and decisions

Record attempted supported compositions, exact API constraints, discovery sources/limitations, recommended smallest resolution and existing authorization or pending material decisions. Keep unknown behavior explicit.

## Verification

Record actual commands/outcomes, rendered control reconciliation, hierarchy, content, CTA prominence, responsive overflow, keyboard/focus, accessibility, relevant states, reduced motion and remaining limitations. List retained evidence paths. User design acceptance remains separate from automated checks.
