# Consumer theming

Registered modes: light, dark. Densities: compact, comfortable, spacious. Schemes: default, subtle, emphasis. Import the package styles once. Values and ownership remain in the installed [token reference](../context/tokens.json), [resolved themes](../context/resolved-themes.json) and [theme policy](../theme-policy.json). Consumer overrides are not supported.

## Configured schemes

Mode is chosen for the page; scheme is chosen per container. Prism has one visual theme. `themes.schemes` is the authoritative configured scheme list. Schemes are named by purpose:

| Scheme | Base on a light page | Base on a dark page | Overrides | Use |
| --- | --- | --- | --- | --- |
| default | light | dark | none | Page and standard content |
| subtle | light | dark | `background`, `secondary`, `accent` | Recessed or secondary sections |
| emphasis | dark | dark | `background`, `foreground`, `card`, `card-foreground`, `muted`, `border`, `ring`, `primary`, `primary-foreground`, `destructive`, `success`, `warning`, `info` | Accent-colored feature sections |

`themes.json` is authoritative for this table. Each scheme uses a light or dark base, then overrides roles:

- `tokens/schemes/<scheme>.json` holds overrides shared across modes. Subtle aliases `background` to the base's `muted`, and `secondary` and `accent` to `card` so they stay visible on the gray background. It works in both modes for the theme.
- `tokens/theme/schemes/<scheme>.json` holds theme overrides. Emphasis uses these.

Schemes redefine the roles components already use. A primary Button on emphasis becomes a white fill with accent-colored text, with no component variant. Rules enforced by the build:

- Shared and theme scheme files together must override exactly the declared `overrides` roles. An optional mode/scheme file may additionally override only roles listed for that scheme in `scopedSchemeOverrides`. Only color roles are allowed. To change either list, extend `themes.json` explicitly.
- A scheme's base must be a configured mode. Schemes never extend another scheme.
- Every mode × scheme combination must be complete and pass the contrast checks.

The page mode selects the base. Without a scoped override, a scheme looks the same on any page that uses the same base. For example, emphasis on a light page matches emphasis on a dark page.


Set mode on html so portals share it. Density and page section rhythm are independent. Preserve reduced-motion behavior.
