---
name: prism-page
description: Implement approved designs or explicit production page requests with Prism’s Storybook-backed system library, using React.
---

# Build a Prism page

Use this skill for a full page or screen built with Prism. Follow the user's requested surface and page requirements. Treat the page as a composition of supported components; do not turn local page structure into a new system API without evidence and a separate request.

## Use the installed release

If this project consumes a Prism package, read [the installed entry point](../../../AGENTS.md) and [discovery](../../manifest.json) first. Follow [consumer rules](../../rules.md) through the release's generated portable adapter, and the packaged audit policy/template. Retrieve only selected guidance, schemas and React declarations from the installed inventory. Use packaged recipes as examples, not shared APIs. Match release identity; do not rebuild context or read a separate Prism checkout. Identify experience, platform, viewport and input needs independently. Review the running consumer app and use its validation commands. 


Read the [audit policy](../../audit.md), [template](../../audit-template.md), [recipes](../../recipes.md) and [validation](../../validation.md) as needed.
