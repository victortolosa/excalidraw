import { useRef, useState } from 'react'
import { Button, Card, TextField, Page, Section, Switch, type CardProps } from '@prism-local/react'
import { accountSettingsFixtures, saveProfileLocally, type Profile, type SaveState } from './profile-service'

export type AccountSettingsProps = {
  initialProfile?: Profile
  initialState?: SaveState
  scheme?: CardProps['scheme']
  /** @deprecated Use scheme. */
  surface?: CardProps['surface']
  initialNotifications?: boolean
  onSave?: (profile: Profile) => Promise<void>
}
export function AccountSettings({ initialProfile = accountSettingsFixtures.idle.profile, initialState = 'idle', scheme, surface, initialNotifications = true, onSave = saveProfileLocally }: AccountSettingsProps) {
  const [profile, setProfile] = useState<Profile>(initialProfile)
  const [notifications, setNotifications] = useState(initialNotifications)
  const [state, setState] = useState<SaveState>(initialState)
  const [errors, setErrors] = useState<{ displayName?: string; email?: string }>(initialState === 'invalid' ? { displayName: 'Enter your display name.', email: 'Enter an email address such as ada@example.com.' } : {})
  const nameRef = useRef<HTMLInputElement>(null)
  const emailRef = useRef<HTMLInputElement>(null)
  const pending = useRef(initialState === 'saving')
  const update = (key: keyof Profile, value: string) => {
    setProfile(current => ({ ...current, [key]: value }))
    setErrors(current => ({ ...current, [key]: undefined }))
    setState('idle')
  }
  return (
    <Page title="Account settings" description="Manage your public profile and contact details." width="narrow">
      <Section title="Profile">
      <Card title="Public details" description="Keep your name and email address up to date." headingLevel="3" scheme={scheme} surface={scheme ? undefined : surface}>
        <form noValidate className="space-y-5" onSubmit={async event => {
          event.preventDefault()
          if (pending.current) return
          const nextErrors = {
            displayName: profile.displayName.trim() ? undefined : 'Enter your display name.',
            email: emailRef.current?.validity.valid ? undefined : 'Enter an email address such as ada@example.com.',
          }
          setErrors(nextErrors)
          if (nextErrors.displayName || nextErrors.email) {
            setState('invalid')
            ;(nextErrors.displayName ? nameRef : emailRef).current?.focus()
            return
          }
          pending.current = true
          setState('saving')
          try {
            await onSave({ displayName: profile.displayName.trim(), email: profile.email })
            setState('success')
          } catch {
            setState('error')
          } finally {
            pending.current = false
          }
        }}>
          <TextField {...{ label: 'Display name', description: 'Shown on your public profile.' }} name="displayName" autoComplete="name" required ref={nameRef} value={profile.displayName} onChange={event => update('displayName', event.target.value)} readOnly={state === 'saving'} error={errors.displayName} />
          <TextField label="Email address" description="Used for account notifications." type="email" name="email" autoComplete="email" required ref={emailRef} value={profile.email} onChange={event => update('email', event.target.value)} readOnly={state === 'saving'} error={errors.email} />
          <div><Button type="submit" loading={state === 'saving'}>{state === 'saving' ? 'Saving…' : 'Save changes'}</Button></div>
          <p role="status" className="break-words text-sm">{state === 'success' ? 'Your profile has been saved.' : state === 'saving' ? 'Saving your profile…' : ''}</p>
          {state === 'error' && <p role="alert" className="break-words text-sm text-destructive">Your profile could not be saved. Your changes are still here. Try saving again.</p>}
        </form>
      </Card>
      </Section>
      <Section title="Preferences">
        <Card title="Notifications" description="Choose which updates you receive." headingLevel="3" scheme={scheme} surface={scheme ? undefined : surface}>
          <Switch label="Product updates" description="Receive occasional email about new features." checked={notifications} onCheckedChange={setNotifications} />
        </Card>
      </Section>
    </Page>
  )
}
