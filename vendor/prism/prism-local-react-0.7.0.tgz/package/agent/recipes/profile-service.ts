export type Profile = { displayName: string; email: string }
export type SaveState = 'idle' | 'invalid' | 'saving' | 'success' | 'error'
export const accountSettingsFixtures = { idle: { profile: { displayName: 'Ada Lovelace', email: 'ada@example.com' } } }
let attempts = 0
// Local-only fixture. Replace with an app-owned service; this never persists data.
export async function saveProfileLocally(_profile: Profile) {
  attempts++
  await new Promise(resolve => setTimeout(resolve, 250))
  if (new URLSearchParams(location.search).has('failOnce') && attempts === 1) throw new Error('Local failure fixture')
}
