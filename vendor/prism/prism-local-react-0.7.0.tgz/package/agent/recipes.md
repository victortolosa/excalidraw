# Composition recipes

## Page and site recipes

Use supported APIs from the installed inventory for page composition.

## Account settings

[AccountSettings.tsx](recipes/AccountSettings.tsx) composes installed Page, Section, Card, TextField, Button and Switch. Copy it with [profile-service.ts](recipes/profile-service.ts) into consumer-owned code when appropriate. The service is a deterministic local fixture with no persistence; replace it with caller-owned services. Run consumer checks and browser verification after adaptation.

## Marketing

Use installed Page/Section/Card for content structure and native links for navigation. Preserve CTA prominence; if the required navigation treatment cannot be composed through supported APIs, record a gap rather than restyling Button or changing link semantics. Use the installed Hero block for page introductions; read its guidance and schema before composing actions and media.
