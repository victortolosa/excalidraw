import { type ComponentPropsWithRef } from 'react';
import type { SearchFieldInput } from './search-field.contract';
type NativeProps = Pick<ComponentPropsWithRef<'input'>, 'id' | 'ref' | 'name' | 'form' | 'autoComplete' | 'onChange' | 'onBlur' | 'onFocus' | 'onKeyDown'>;
type ValueProps = {
    value: string;
    onChange: NonNullable<NativeProps['onChange']>;
    defaultValue?: never;
} | {
    value?: never;
    defaultValue?: string;
};
export type SearchFieldProps = SearchFieldInput & NativeProps & ValueProps & ({
    onClear: () => void;
    value: string;
} | {
    onClear?: never;
});
export declare function SearchField({ label, labelVisibility, placeholder, description, error, id, disabled, readOnly, onClear, ref, ...props }: SearchFieldProps): import("react").JSX.Element;
export {};
