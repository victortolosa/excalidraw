export declare const searchFieldDefaults: {
    readonly labelVisibility: "visible";
    readonly disabled: false;
    readonly readOnly: false;
};
