import * as React from "react";
import { Label as LabelPrimitive } from "radix-ui";
declare function Label({ className, ...props }: React.ComponentProps<typeof LabelPrimitive.Root>): React.JSX.Element;
export { Label };
