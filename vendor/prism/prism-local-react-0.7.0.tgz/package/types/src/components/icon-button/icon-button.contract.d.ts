export { iconButtonDefaults } from './icon-button.runtime.ts';
import { z } from 'zod';
export declare const iconButtonIcons: readonly ["add", "close", "edit", "more", "search", "settings", "attachment", "mention"];
export declare const iconButtonVariants: readonly ["primary", "secondary"];
export declare const iconButtonTypes: readonly ["button", "submit", "reset"];
export declare const iconButtonSchema: z.ZodObject<{
    icon: z.ZodEnum<{
        search: "search";
        close: "close";
        add: "add";
        edit: "edit";
        more: "more";
        settings: "settings";
        attachment: "attachment";
        mention: "mention";
    }>;
    label: z.ZodString;
    variant: z.ZodDefault<z.ZodEnum<{
        secondary: "secondary";
        primary: "primary";
    }>>;
    type: z.ZodDefault<z.ZodEnum<{
        button: "button";
        submit: "submit";
        reset: "reset";
    }>>;
    disabled: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>;
export type IconButtonIcon = (typeof iconButtonIcons)[number];
export type IconButtonVariant = (typeof iconButtonVariants)[number];
export type IconButtonType = (typeof iconButtonTypes)[number];
export type IconButtonInput = z.input<typeof iconButtonSchema>;
export declare const iconButtonJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    icon: z.ZodEnum<{
        search: "search";
        close: "close";
        add: "add";
        edit: "edit";
        more: "more";
        settings: "settings";
        attachment: "attachment";
        mention: "mention";
    }>;
    label: z.ZodString;
    variant: z.ZodDefault<z.ZodEnum<{
        secondary: "secondary";
        primary: "primary";
    }>>;
    type: z.ZodDefault<z.ZodEnum<{
        button: "button";
        submit: "submit";
        reset: "reset";
    }>>;
    disabled: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>>;
