import type { ComponentPropsWithRef } from 'react';
import type { IconButtonInput } from './icon-button.contract';
type ReactOnlyProps = Pick<ComponentPropsWithRef<'button'>, 'ref' | 'id' | 'name' | 'value' | 'form' | 'onClick' | 'onFocus' | 'onBlur' | 'aria-describedby'>;
export type IconButtonProps = IconButtonInput & ReactOnlyProps;
export declare function IconButton({ icon, label, variant, type, disabled, ...rest }: IconButtonProps): import("react").JSX.Element;
export {};
