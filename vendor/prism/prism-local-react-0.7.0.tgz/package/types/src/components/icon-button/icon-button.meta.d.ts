export declare const iconButtonMeta: {
    readonly id: "icon-button";
    readonly name: "IconButton";
    readonly status: "experimental";
    readonly sources: {
        readonly contract: "src/components/icon-button/icon-button.contract.ts";
        readonly implementation: "src/components/icon-button/icon-button.tsx";
        readonly guidance: "src/components/icon-button/icon-button.mdx";
        readonly fixtures: "src/components/icon-button/icon-button.fixtures.ts";
        readonly stories: "src/components/icon-button/icon-button.stories.tsx";
        readonly catalog: "src/components/ui/button.tsx";
    };
    readonly tokens: readonly ["primary", "primary-foreground", "background", "foreground", "border", "input", "muted", "ring"];
    readonly origin: {
        readonly kind: "shadcn-wrapper";
        readonly catalogSources: readonly ["catalog"];
    };
    readonly dependencies: readonly [];
};
