export declare const iconButtonDefaults: {
    readonly variant: "secondary";
    readonly type: "button";
    readonly disabled: false;
};
