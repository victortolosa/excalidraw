export declare const dialogDefaults: {
    readonly confirmVariant: "primary";
    readonly cancelLabel: "Cancel";
    readonly defaultOpen: false;
};
