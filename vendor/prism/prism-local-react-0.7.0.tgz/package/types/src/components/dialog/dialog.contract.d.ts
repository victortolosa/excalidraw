export { dialogDefaults } from './dialog.runtime.ts';
import { z } from 'zod';
export declare const dialogSchema: z.ZodObject<{
    title: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    confirmLabel: z.ZodOptional<z.ZodString>;
    confirmVariant: z.ZodDefault<z.ZodEnum<{
        primary: "primary";
        destructive: "destructive";
    }>>;
    cancelLabel: z.ZodDefault<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    defaultOpen: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>;
export type DialogInput = z.input<typeof dialogSchema>;
export declare const dialogJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    title: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    confirmLabel: z.ZodOptional<z.ZodString>;
    confirmVariant: z.ZodDefault<z.ZodEnum<{
        primary: "primary";
        destructive: "destructive";
    }>>;
    cancelLabel: z.ZodDefault<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    defaultOpen: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>>;
