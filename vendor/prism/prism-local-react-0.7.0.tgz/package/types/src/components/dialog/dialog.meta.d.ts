export declare const dialogMeta: {
    readonly id: "dialog";
    readonly name: "Dialog";
    readonly status: "experimental";
    readonly sources: {
        readonly contract: "src/components/dialog/dialog.contract.ts";
        readonly implementation: "src/components/dialog/dialog.tsx";
        readonly guidance: "src/components/dialog/dialog.mdx";
        readonly fixtures: "src/components/dialog/dialog.fixtures.ts";
        readonly stories: "src/components/dialog/dialog.stories.tsx";
        readonly catalog: "src/components/ui/dialog.tsx";
    };
    readonly tokens: readonly ["border", "font-heading", "foreground", "muted", "muted-foreground", "popover", "popover-foreground"];
    readonly origin: {
        readonly kind: "shadcn-wrapper";
        readonly catalogSources: readonly ["catalog"];
    };
    readonly dependencies: readonly ["alert", "button"];
};
