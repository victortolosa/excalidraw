import { type ReactElement, type ReactNode, type RefObject } from 'react';
import type { DialogInput } from './dialog.contract';
type OpenProps = {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    defaultOpen?: never;
} | {
    open?: never;
    defaultOpen?: boolean;
    onOpenChange?: (open: boolean) => void;
};
export type DialogProps = Omit<DialogInput, 'defaultOpen'> & OpenProps & {
    /** A system Button that opens the dialog. Omit when the dialog is opened by open state, such as from a menu item. */
    trigger?: ReactElement;
    /** Runs the confirm action. If it returns a promise, the dialog stays open and shows loading until it settles, and closes only if it resolves. */
    onConfirm?: () => void | Promise<unknown>;
    /** Body content between the description and the footer, such as form fields. */
    children?: ReactNode;
    /** Focus target after a controlled dialog opened from a menu or row action closes. */
    returnFocusRef?: RefObject<HTMLElement | null>;
};
export declare function Dialog({ title, description, confirmLabel, confirmVariant, cancelLabel, error, open, defaultOpen, onOpenChange, trigger, onConfirm, children, returnFocusRef, }: DialogProps): import("react").JSX.Element;
export {};
