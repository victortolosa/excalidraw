export declare const selectDefaults: {
    readonly labelVisibility: "visible";
    readonly required: false;
    readonly disabled: false;
};
