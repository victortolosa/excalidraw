import type { SelectInput } from './select.contract';
type ReactProps = {
    id?: string;
    name?: string;
    form?: string;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
};
type ValueProps = {
    value: string;
    onValueChange: (value: string) => void;
    defaultValue?: never;
} | {
    value?: never;
    defaultValue?: string;
    onValueChange?: (value: string) => void;
};
export type SelectProps = SelectInput & ReactProps & ValueProps;
export declare function Select({ label, labelVisibility, options, placeholder, description, error, id, name, required, disabled, value, defaultValue, onValueChange, open, onOpenChange, }: SelectProps): import("react").JSX.Element;
export {};
