export { selectDefaults } from './select.runtime.ts';
import { z } from 'zod';
export declare const selectOptionSchema: z.ZodObject<{
    value: z.ZodString;
    label: z.ZodString;
    disabled: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>;
export type SelectOption = z.infer<typeof selectOptionSchema>;
export declare const selectSchema: z.ZodObject<{
    label: z.ZodString;
    labelVisibility: z.ZodDefault<z.ZodEnum<{
        hidden: "hidden";
        visible: "visible";
    }>>;
    options: z.ZodArray<z.ZodObject<{
        value: z.ZodString;
        label: z.ZodString;
        disabled: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    placeholder: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    required: z.ZodDefault<z.ZodBoolean>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    defaultValue: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type SelectInput = z.input<typeof selectSchema>;
export declare const selectJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    label: z.ZodString;
    labelVisibility: z.ZodDefault<z.ZodEnum<{
        hidden: "hidden";
        visible: "visible";
    }>>;
    options: z.ZodArray<z.ZodObject<{
        value: z.ZodString;
        label: z.ZodString;
        disabled: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    placeholder: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    required: z.ZodDefault<z.ZodBoolean>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    defaultValue: z.ZodOptional<z.ZodString>;
}, z.core.$strict>>;
