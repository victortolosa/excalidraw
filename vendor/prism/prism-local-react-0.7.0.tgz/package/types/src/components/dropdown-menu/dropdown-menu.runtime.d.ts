export declare const dropdownMenuDefaults: {
    readonly disabled: false;
    readonly align: "end";
    readonly trigger: "text";
};
export declare const dropdownMenuItemDefaults: {
    readonly disabled: false;
    readonly variant: "default";
};
