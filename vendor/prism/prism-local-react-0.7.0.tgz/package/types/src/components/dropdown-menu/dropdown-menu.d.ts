import type { DropdownMenuInput } from './dropdown-menu.contract';
export type DropdownMenuProps = DropdownMenuInput & {
    onAction: (id: string, trigger: HTMLButtonElement | null) => void;
};
export declare function DropdownMenu({ label, items, trigger, disabled, align, onAction }: DropdownMenuProps): import("react").JSX.Element;
