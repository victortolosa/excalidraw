export { dropdownMenuDefaults, dropdownMenuItemDefaults } from './dropdown-menu.runtime.ts';
import { z } from 'zod';
export declare const dropdownMenuItemSchema: z.ZodObject<{
    id: z.ZodString;
    label: z.ZodString;
    disabled: z.ZodDefault<z.ZodBoolean>;
    variant: z.ZodDefault<z.ZodEnum<{
        destructive: "destructive";
        default: "default";
    }>>;
}, z.core.$strict>;
export declare const dropdownMenuSchema: z.ZodObject<{
    label: z.ZodString;
    trigger: z.ZodDefault<z.ZodEnum<{
        text: "text";
        icon: "icon";
    }>>;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        disabled: z.ZodDefault<z.ZodBoolean>;
        variant: z.ZodDefault<z.ZodEnum<{
            destructive: "destructive";
            default: "default";
        }>>;
    }, z.core.$strict>>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    align: z.ZodDefault<z.ZodEnum<{
        end: "end";
        start: "start";
    }>>;
}, z.core.$strict>;
export type DropdownMenuInput = z.input<typeof dropdownMenuSchema>;
export declare const dropdownMenuJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    label: z.ZodString;
    trigger: z.ZodDefault<z.ZodEnum<{
        text: "text";
        icon: "icon";
    }>>;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        disabled: z.ZodDefault<z.ZodBoolean>;
        variant: z.ZodDefault<z.ZodEnum<{
            destructive: "destructive";
            default: "default";
        }>>;
    }, z.core.$strict>>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    align: z.ZodDefault<z.ZodEnum<{
        end: "end";
        start: "start";
    }>>;
}, z.core.$strict>>;
