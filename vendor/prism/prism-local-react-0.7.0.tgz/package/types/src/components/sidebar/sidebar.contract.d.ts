export { sidebarDefaults } from './sidebar.runtime.ts';
import { z } from 'zod';
export declare const sidebarItemSchema: z.ZodObject<{
    id: z.ZodString;
    label: z.ZodString;
    href: z.ZodString;
    icon: z.ZodEnum<{
        settings: "settings";
        home: "home";
        layers: "layers";
        folder: "folder";
        users: "users";
        chart: "chart";
    }>;
}, z.core.$strict>;
export declare const sidebarSchema: z.ZodObject<{
    label: z.ZodString;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        href: z.ZodString;
        icon: z.ZodEnum<{
            settings: "settings";
            home: "home";
            layers: "layers";
            folder: "folder";
            users: "users";
            chart: "chart";
        }>;
    }, z.core.$strict>>;
    currentId: z.ZodOptional<z.ZodString>;
    collapsed: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>;
export type SidebarInput = z.input<typeof sidebarSchema>;
export declare const sidebarJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    label: z.ZodString;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        href: z.ZodString;
        icon: z.ZodEnum<{
            settings: "settings";
            home: "home";
            layers: "layers";
            folder: "folder";
            users: "users";
            chart: "chart";
        }>;
    }, z.core.$strict>>;
    currentId: z.ZodOptional<z.ZodString>;
    collapsed: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>>;
