import type { SidebarInput } from './sidebar.contract';
export type SidebarProps = SidebarInput;
export declare function Sidebar({ label, items, currentId, collapsed }: SidebarProps): import("react").JSX.Element;
