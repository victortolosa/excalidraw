export declare const sidebarDefaults: {
    readonly collapsed: false;
};
