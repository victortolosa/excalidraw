export declare const popoverDefaults: {
    readonly defaultOpen: false;
    readonly side: "bottom";
    readonly align: "center";
};
