export { popoverDefaults } from './popover.runtime.ts';
import { z } from 'zod';
export declare const popoverSchema: z.ZodObject<{
    title: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    defaultOpen: z.ZodDefault<z.ZodBoolean>;
    side: z.ZodDefault<z.ZodEnum<{
        top: "top";
        bottom: "bottom";
        left: "left";
        right: "right";
    }>>;
    align: z.ZodDefault<z.ZodEnum<{
        center: "center";
        end: "end";
        start: "start";
    }>>;
}, z.core.$strict>;
export type PopoverInput = z.input<typeof popoverSchema>;
export declare const popoverJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    title: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    defaultOpen: z.ZodDefault<z.ZodBoolean>;
    side: z.ZodDefault<z.ZodEnum<{
        top: "top";
        bottom: "bottom";
        left: "left";
        right: "right";
    }>>;
    align: z.ZodDefault<z.ZodEnum<{
        center: "center";
        end: "end";
        start: "start";
    }>>;
}, z.core.$strict>>;
