import { type ReactElement, type ReactNode } from 'react';
import type { PopoverInput } from './popover.contract';
type OpenProps = {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    defaultOpen?: never;
} | {
    open?: never;
    onOpenChange?: (open: boolean) => void;
    defaultOpen?: boolean;
};
export type PopoverProps = Omit<PopoverInput, 'defaultOpen'> & OpenProps & {
    trigger: ReactElement;
    children: ReactNode;
};
export declare function Popover({ title, description, trigger, children, side, align, defaultOpen, ...state }: PopoverProps): import("react").JSX.Element;
export {};
