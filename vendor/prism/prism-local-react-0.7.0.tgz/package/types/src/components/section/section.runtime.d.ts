export declare const sectionDefaults: {
    readonly headingLevel: "2";
    readonly titleStyle: "default";
};
