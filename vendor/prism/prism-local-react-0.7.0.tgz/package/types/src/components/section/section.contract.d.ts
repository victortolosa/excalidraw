export { sectionDefaults } from './section.runtime.ts';
import { z } from 'zod';
export declare const sectionTitleStyles: readonly ["default", "label"];
export declare const sectionSchema: z.ZodObject<{
    sectionSpacing: z.ZodOptional<z.ZodEnum<{
        compact: "compact";
        spacious: "spacious";
        standard: "standard";
    }>>;
    title: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    titleStyle: z.ZodDefault<z.ZodEnum<{
        default: "default";
        label: "label";
    }>>;
    headingLevel: z.ZodDefault<z.ZodEnum<{
        2: "2";
        3: "3";
        4: "4";
    }>>;
    contentWidth: z.ZodOptional<z.ZodEnum<{
        standard: "standard";
        narrow: "narrow";
        wide: "wide";
    }>>;
    contentScheme: z.ZodOptional<z.ZodEnum<{
        default: "default";
        subtle: "subtle";
        emphasis: "emphasis";
    }>>;
    surface: z.ZodOptional<z.ZodEnum<{
        default: "default";
        subtle: "subtle";
        emphasis: "emphasis";
    }>>;
    scheme: z.ZodOptional<z.ZodEnum<{
        default: "default";
        subtle: "subtle";
        emphasis: "emphasis";
    }>>;
}, z.core.$strict>;
export type SectionInput = z.input<typeof sectionSchema>;
export declare const sectionJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    sectionSpacing: z.ZodOptional<z.ZodEnum<{
        compact: "compact";
        spacious: "spacious";
        standard: "standard";
    }>>;
    title: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    titleStyle: z.ZodDefault<z.ZodEnum<{
        default: "default";
        label: "label";
    }>>;
    headingLevel: z.ZodDefault<z.ZodEnum<{
        2: "2";
        3: "3";
        4: "4";
    }>>;
    contentWidth: z.ZodOptional<z.ZodEnum<{
        standard: "standard";
        narrow: "narrow";
        wide: "wide";
    }>>;
    contentScheme: z.ZodOptional<z.ZodEnum<{
        default: "default";
        subtle: "subtle";
        emphasis: "emphasis";
    }>>;
    surface: z.ZodOptional<z.ZodEnum<{
        default: "default";
        subtle: "subtle";
        emphasis: "emphasis";
    }>>;
    scheme: z.ZodOptional<z.ZodEnum<{
        default: "default";
        subtle: "subtle";
        emphasis: "emphasis";
    }>>;
}, z.core.$strict>>;
