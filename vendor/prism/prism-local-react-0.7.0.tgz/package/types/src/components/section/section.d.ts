import { type ReactNode } from 'react';
import type { SectionInput } from './section.contract';
export type SectionProps = SectionInput & {
    children: ReactNode;
    actions?: ReactNode;
};
export declare function Section({ title, description, headingLevel, titleStyle, surface, scheme, contentWidth, contentScheme, sectionSpacing, actions, children }: SectionProps): import("react").JSX.Element;
