export { itemDefaults } from './item.runtime.ts';
import { z } from 'zod';
export declare const itemVariants: readonly ["plain", "outlined"];
export declare const itemSchema: z.ZodObject<{
    title: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    status: z.ZodOptional<z.ZodString>;
    variant: z.ZodDefault<z.ZodEnum<{
        plain: "plain";
        outlined: "outlined";
    }>>;
}, z.core.$strict>;
export declare const itemGroupSchema: z.ZodObject<{
    label: z.ZodString;
}, z.core.$strict>;
export type ItemVariant = (typeof itemVariants)[number];
export type ItemInput = z.input<typeof itemSchema>;
export type ItemGroupInput = z.input<typeof itemGroupSchema>;
export declare const itemJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    title: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    status: z.ZodOptional<z.ZodString>;
    variant: z.ZodDefault<z.ZodEnum<{
        plain: "plain";
        outlined: "outlined";
    }>>;
}, z.core.$strict>>;
export declare const itemGroupJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    label: z.ZodString;
}, z.core.$strict>>;
