export declare const itemDefaults: {
    readonly variant: "plain";
};
