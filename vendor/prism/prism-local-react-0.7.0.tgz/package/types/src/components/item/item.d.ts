import type { ReactNode } from 'react';
import type { ItemGroupInput, ItemInput } from './item.contract';
export type ItemProps = ItemInput & {
    children?: ReactNode;
};
export type ItemGroupProps = ItemGroupInput & {
    children: ReactNode;
};
export declare function Item({ title, description, status, variant, children }: ItemProps): import("react").JSX.Element;
export declare function ItemGroup({ label, children }: ItemGroupProps): import("react").JSX.Element;
