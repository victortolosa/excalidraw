export { siteFooterDefaults } from './site-footer.runtime.ts';
import { z } from 'zod';
export declare const siteFooterGroupSchema: z.ZodObject<{
    id: z.ZodString;
    title: z.ZodString;
    links: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        href: z.ZodUnion<readonly [z.ZodString, z.ZodURL]>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const siteFooterSchema: z.ZodObject<{
    siteName: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    navigationLabel: z.ZodDefault<z.ZodString>;
    legalLabel: z.ZodDefault<z.ZodString>;
    groups: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        links: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            href: z.ZodUnion<readonly [z.ZodString, z.ZodURL]>;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
    legalText: z.ZodString;
    status: z.ZodOptional<z.ZodString>;
    legalLinks: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        href: z.ZodUnion<readonly [z.ZodString, z.ZodURL]>;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export type SiteFooterInput = z.input<typeof siteFooterSchema>;
export declare const siteFooterJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    siteName: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    navigationLabel: z.ZodDefault<z.ZodString>;
    legalLabel: z.ZodDefault<z.ZodString>;
    groups: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        links: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            href: z.ZodUnion<readonly [z.ZodString, z.ZodURL]>;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
    legalText: z.ZodString;
    status: z.ZodOptional<z.ZodString>;
    legalLinks: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        href: z.ZodUnion<readonly [z.ZodString, z.ZodURL]>;
    }, z.core.$strict>>>;
}, z.core.$strict>>;
