import type { SiteFooterInput } from './site-footer.contract';
export type SiteFooterProps = SiteFooterInput;
export declare function SiteFooter({ siteName, description, groups, navigationLabel, legalLabel, legalText, legalLinks, status }: SiteFooterProps): import("react").JSX.Element;
