import type { z } from 'zod';
import type { siteFooterGroupSchema } from './site-footer.contract.ts';
import type { navigationMenuItemSchema } from '../navigation-menu/navigation-menu.contract.ts';
export declare const siteFooterDefaults: {
    readonly navigationLabel: "Footer";
    readonly legalLabel: "Legal";
    readonly groups: z.input<typeof siteFooterGroupSchema>[];
    readonly legalLinks: z.input<typeof navigationMenuItemSchema>[];
};
