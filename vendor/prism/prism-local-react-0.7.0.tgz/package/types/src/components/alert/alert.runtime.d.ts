export declare const alertDefaults: {
    readonly variant: "neutral";
    readonly live: "off";
};
