export { alertDefaults } from './alert.runtime.ts';
import { z } from 'zod';
export declare const alertVariants: readonly ["neutral", "info", "success", "warning", "destructive"];
export declare const alertLiveModes: readonly ["off", "polite", "assertive"];
export declare const alertSchema: z.ZodObject<{
    title: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    variant: z.ZodDefault<z.ZodEnum<{
        destructive: "destructive";
        success: "success";
        warning: "warning";
        info: "info";
        neutral: "neutral";
    }>>;
    live: z.ZodDefault<z.ZodEnum<{
        off: "off";
        polite: "polite";
        assertive: "assertive";
    }>>;
}, z.core.$strict>;
export type AlertVariant = (typeof alertVariants)[number];
export type AlertLive = (typeof alertLiveModes)[number];
export type AlertInput = z.input<typeof alertSchema>;
export declare const alertJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    title: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    variant: z.ZodDefault<z.ZodEnum<{
        destructive: "destructive";
        success: "success";
        warning: "warning";
        info: "info";
        neutral: "neutral";
    }>>;
    live: z.ZodDefault<z.ZodEnum<{
        off: "off";
        polite: "polite";
        assertive: "assertive";
    }>>;
}, z.core.$strict>>;
