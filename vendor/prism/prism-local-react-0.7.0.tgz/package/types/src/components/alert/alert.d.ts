import type { ReactNode } from 'react';
import type { AlertInput } from './alert.contract';
export type AlertProps = AlertInput & {
    action?: ReactNode;
};
export declare function Alert({ title, description, variant, live, action }: AlertProps): import("react").JSX.Element;
