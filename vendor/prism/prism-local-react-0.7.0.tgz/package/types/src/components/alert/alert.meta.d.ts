export declare const alertMeta: {
    readonly id: "alert";
    readonly name: "Alert";
    readonly status: "experimental";
    readonly sources: {
        readonly contract: "src/components/alert/alert.contract.ts";
        readonly implementation: "src/components/alert/alert.tsx";
        readonly guidance: "src/components/alert/alert.mdx";
        readonly fixtures: "src/components/alert/alert.fixtures.ts";
        readonly stories: "src/components/alert/alert.stories.tsx";
        readonly catalog: "src/components/ui/alert.tsx";
    };
    readonly tokens: readonly ["border", "card", "card-foreground", "destructive", "info", "muted-foreground", "success", "warning"];
    readonly origin: {
        readonly kind: "shadcn-wrapper";
        readonly catalogSources: readonly ["catalog"];
    };
    readonly dependencies: readonly [];
};
