import type { NavigationMenuInput } from './navigation-menu.contract';
export type NavigationMenuProps = NavigationMenuInput;
export declare function NavigationMenu({ label, items, currentId, orientation }: NavigationMenuProps): import("react").JSX.Element;
