export { navigationMenuDefaults } from './navigation-menu.runtime.ts';
import { z } from 'zod';
export declare const navigationMenuItemSchema: z.ZodObject<{
    id: z.ZodString;
    label: z.ZodString;
    href: z.ZodUnion<readonly [z.ZodString, z.ZodURL]>;
}, z.core.$strict>;
export declare const navigationMenuSchema: z.ZodObject<{
    label: z.ZodString;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        href: z.ZodUnion<readonly [z.ZodString, z.ZodURL]>;
    }, z.core.$strict>>;
    currentId: z.ZodOptional<z.ZodString>;
    orientation: z.ZodDefault<z.ZodEnum<{
        horizontal: "horizontal";
        vertical: "vertical";
    }>>;
}, z.core.$strict>;
export type NavigationMenuInput = z.input<typeof navigationMenuSchema>;
export declare const navigationMenuJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    label: z.ZodString;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        href: z.ZodUnion<readonly [z.ZodString, z.ZodURL]>;
    }, z.core.$strict>>;
    currentId: z.ZodOptional<z.ZodString>;
    orientation: z.ZodDefault<z.ZodEnum<{
        horizontal: "horizontal";
        vertical: "vertical";
    }>>;
}, z.core.$strict>>;
