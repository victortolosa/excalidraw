export declare const navigationMenuDefaults: {
    readonly orientation: "horizontal";
};
