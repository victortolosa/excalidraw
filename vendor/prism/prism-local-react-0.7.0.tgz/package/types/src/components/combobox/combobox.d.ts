import type { ComboboxInput as ComboboxInputContract, ComboboxOptionValue } from './combobox.contract';
type ReactProps = {
    id?: string;
    name?: string;
    form?: string;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    onInputValueChange?: (value: string) => void;
};
type ValueProps = {
    value: ComboboxOptionValue;
    onValueChange: (value: ComboboxOptionValue | null) => void;
    defaultValue?: never;
} | {
    value?: never;
    defaultValue?: ComboboxOptionValue;
    onValueChange?: (value: ComboboxOptionValue | null) => void;
};
export type ComboboxProps = ComboboxInputContract & ReactProps & ValueProps;
export declare function Combobox({ label, labelVisibility, options, placeholder, description, error, id, name, form, required, disabled, openOnInputClick, value, defaultValue, onValueChange, open, onOpenChange, onInputValueChange, }: ComboboxProps): import("react").JSX.Element;
export {};
