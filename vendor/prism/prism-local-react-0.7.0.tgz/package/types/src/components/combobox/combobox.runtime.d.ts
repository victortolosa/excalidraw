export declare const comboboxDefaults: {
    readonly labelVisibility: "visible";
    readonly required: false;
    readonly disabled: false;
    readonly openOnInputClick: false;
};
