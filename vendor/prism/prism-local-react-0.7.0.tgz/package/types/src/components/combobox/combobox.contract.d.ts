export { comboboxDefaults } from './combobox.runtime.ts';
import { z } from 'zod';
export declare const comboboxOptionSchema: z.ZodObject<{
    value: z.ZodString;
    label: z.ZodString;
    disabled: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>;
export type ComboboxOption = z.infer<typeof comboboxOptionSchema>;
export declare const comboboxOptionValueSchema: z.ZodObject<{
    value: z.ZodString;
    label: z.ZodOptional<z.ZodString>;
    disabled: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>;
export type ComboboxOptionValue = z.infer<typeof comboboxOptionValueSchema>;
export declare const comboboxSchema: z.ZodObject<{
    label: z.ZodString;
    labelVisibility: z.ZodDefault<z.ZodEnum<{
        hidden: "hidden";
        visible: "visible";
    }>>;
    options: z.ZodArray<z.ZodObject<{
        value: z.ZodString;
        label: z.ZodString;
        disabled: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    placeholder: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    required: z.ZodDefault<z.ZodBoolean>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    openOnInputClick: z.ZodDefault<z.ZodBoolean>;
    defaultValue: z.ZodOptional<z.ZodObject<{
        value: z.ZodString;
        label: z.ZodOptional<z.ZodString>;
        disabled: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ComboboxInput = z.input<typeof comboboxSchema>;
export declare const comboboxJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    label: z.ZodString;
    labelVisibility: z.ZodDefault<z.ZodEnum<{
        hidden: "hidden";
        visible: "visible";
    }>>;
    options: z.ZodArray<z.ZodObject<{
        value: z.ZodString;
        label: z.ZodString;
        disabled: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    placeholder: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    required: z.ZodDefault<z.ZodBoolean>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    openOnInputClick: z.ZodDefault<z.ZodBoolean>;
    defaultValue: z.ZodOptional<z.ZodObject<{
        value: z.ZodString;
        label: z.ZodOptional<z.ZodString>;
        disabled: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
}, z.core.$strict>>;
