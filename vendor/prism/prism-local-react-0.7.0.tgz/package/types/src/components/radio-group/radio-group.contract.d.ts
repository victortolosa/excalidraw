export { radioGroupDefaults } from './radio-group.runtime.ts';
import { z } from 'zod';
export declare const radioOptionSchema: z.ZodObject<{
    value: z.ZodString;
    label: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    disabled: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>;
export type RadioOption = z.infer<typeof radioOptionSchema>;
export declare const radioGroupSchema: z.ZodObject<{
    label: z.ZodString;
    options: z.ZodArray<z.ZodObject<{
        value: z.ZodString;
        label: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        disabled: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    description: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    required: z.ZodDefault<z.ZodBoolean>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    orientation: z.ZodDefault<z.ZodEnum<{
        horizontal: "horizontal";
        vertical: "vertical";
    }>>;
    defaultValue: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type RadioGroupInput = z.input<typeof radioGroupSchema>;
export declare const radioGroupJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    label: z.ZodString;
    options: z.ZodArray<z.ZodObject<{
        value: z.ZodString;
        label: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        disabled: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    description: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    required: z.ZodDefault<z.ZodBoolean>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    orientation: z.ZodDefault<z.ZodEnum<{
        horizontal: "horizontal";
        vertical: "vertical";
    }>>;
    defaultValue: z.ZodOptional<z.ZodString>;
}, z.core.$strict>>;
