import type { RadioGroupInput } from './radio-group.contract';
type ReactProps = {
    id?: string;
    name?: string;
    form?: string;
};
type ValueProps = {
    value: string;
    onValueChange: (value: string) => void;
    defaultValue?: never;
} | {
    value?: never;
    defaultValue?: string;
    onValueChange?: (value: string) => void;
};
export type RadioGroupProps = RadioGroupInput & ReactProps & ValueProps;
export declare function RadioGroup({ label, options, description, error, id, name, required, disabled, orientation, value, defaultValue, onValueChange, }: RadioGroupProps): import("react").JSX.Element;
export {};
