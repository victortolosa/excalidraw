export declare const radioGroupDefaults: {
    readonly required: false;
    readonly disabled: false;
    readonly orientation: "vertical";
};
