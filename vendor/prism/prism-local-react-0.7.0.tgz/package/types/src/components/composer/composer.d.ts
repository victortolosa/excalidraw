import { type ComponentPropsWithRef, type ReactNode } from 'react';
import type { ComposerInput } from './composer.contract';
type NativeProps = Pick<ComponentPropsWithRef<'textarea'>, 'id' | 'ref' | 'name' | 'form' | 'placeholder' | 'autoComplete' | 'onChange' | 'onBlur' | 'onFocus' | 'onKeyDown'>;
type ValueProps = {
    value: string;
    onValueChange: (value: string) => void;
    onChange?: NativeProps['onChange'];
    defaultValue?: never;
    clearable?: boolean;
} | {
    value: string;
    onChange: NonNullable<NativeProps['onChange']>;
    onValueChange?: never;
    defaultValue?: never;
    clearable?: false;
} | {
    value?: never;
    defaultValue?: string;
    onValueChange?: (value: string) => void;
    clearable?: boolean;
};
export type ComposerProps = ComposerInput & NativeProps & ValueProps & {
    headerActions?: ReactNode;
    toolbar?: ReactNode;
    secondaryActions?: ReactNode;
    actions?: ReactNode;
};
export declare function Composer({ label, labelVisibility, description, error, submissionError, status, id, rows, maxRows, maxLength, required, disabled, readOnly, busy, clearable, clearLabel, undoLabel, headerActions, toolbar, secondaryActions, actions, value, defaultValue, onValueChange, onChange, ref, ...props }: ComposerProps): import("react").JSX.Element;
export {};
