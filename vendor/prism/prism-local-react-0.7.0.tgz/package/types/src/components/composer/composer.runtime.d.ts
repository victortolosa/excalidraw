export declare const composerDefaults: {
    readonly labelVisibility: "visible";
    readonly disabled: false;
    readonly readOnly: false;
    readonly busy: false;
    readonly clearable: false;
    readonly rows: 3;
    readonly maxRows: 12;
    readonly clearLabel: "Clear";
    readonly undoLabel: "Undo";
    readonly required: false;
};
