export { composerDefaults } from './composer.runtime.ts';
import { z } from 'zod';
export declare const composerFieldsSchema: z.ZodObject<{
    label: z.ZodString;
    labelVisibility: z.ZodDefault<z.ZodEnum<{
        hidden: "hidden";
        visible: "visible";
    }>>;
    description: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    readOnly: z.ZodDefault<z.ZodBoolean>;
    busy: z.ZodDefault<z.ZodBoolean>;
    clearable: z.ZodDefault<z.ZodBoolean>;
    clearLabel: z.ZodDefault<z.ZodString>;
    undoLabel: z.ZodDefault<z.ZodString>;
    required: z.ZodDefault<z.ZodBoolean>;
    maxLength: z.ZodOptional<z.ZodNumber>;
    maxRows: z.ZodOptional<z.ZodNumber>;
    status: z.ZodOptional<z.ZodString>;
    submissionError: z.ZodOptional<z.ZodString>;
    rows: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export declare function composerConstraints(input: {
    rows: number;
    maxRows?: number;
    required?: boolean;
    labelVisibility: string;
}, ctx: z.RefinementCtx): void;
export declare const composerSchema: z.ZodObject<{
    label: z.ZodString;
    labelVisibility: z.ZodDefault<z.ZodEnum<{
        hidden: "hidden";
        visible: "visible";
    }>>;
    description: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    readOnly: z.ZodDefault<z.ZodBoolean>;
    busy: z.ZodDefault<z.ZodBoolean>;
    clearable: z.ZodDefault<z.ZodBoolean>;
    clearLabel: z.ZodDefault<z.ZodString>;
    undoLabel: z.ZodDefault<z.ZodString>;
    required: z.ZodDefault<z.ZodBoolean>;
    maxLength: z.ZodOptional<z.ZodNumber>;
    maxRows: z.ZodOptional<z.ZodNumber>;
    status: z.ZodOptional<z.ZodString>;
    submissionError: z.ZodOptional<z.ZodString>;
    rows: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export type ComposerInput = z.input<typeof composerSchema>;
export declare const composerJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    label: z.ZodString;
    labelVisibility: z.ZodDefault<z.ZodEnum<{
        hidden: "hidden";
        visible: "visible";
    }>>;
    description: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    readOnly: z.ZodDefault<z.ZodBoolean>;
    busy: z.ZodDefault<z.ZodBoolean>;
    clearable: z.ZodDefault<z.ZodBoolean>;
    clearLabel: z.ZodDefault<z.ZodString>;
    undoLabel: z.ZodDefault<z.ZodString>;
    required: z.ZodDefault<z.ZodBoolean>;
    maxLength: z.ZodOptional<z.ZodNumber>;
    maxRows: z.ZodOptional<z.ZodNumber>;
    status: z.ZodOptional<z.ZodString>;
    submissionError: z.ZodOptional<z.ZodString>;
    rows: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>>;
