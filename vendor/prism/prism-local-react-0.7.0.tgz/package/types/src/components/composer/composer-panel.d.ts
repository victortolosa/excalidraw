import type { ReactNode } from 'react';
import type { ComposerInput } from './composer.contract';
type PanelProps = Pick<ComposerInput, 'label' | 'labelVisibility' | 'required' | 'disabled' | 'readOnly' | 'busy' | 'description' | 'error' | 'submissionError' | 'status'> & {
    inputId: string;
    announcement?: string;
    headerActions?: ReactNode;
    toolbar?: ReactNode;
    secondaryActions?: ReactNode;
    actions?: ReactNode;
    children: ReactNode;
    onLabelClick?: () => void;
    component?: string;
};
export declare function ComposerPanel({ label, labelVisibility, required, disabled, readOnly, busy, description, error, submissionError, status, inputId, announcement, headerActions, toolbar, secondaryActions, actions, children, onLabelClick, component }: PanelProps): import("react").JSX.Element;
export {};
