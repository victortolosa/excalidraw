import type { BreadcrumbInput } from './breadcrumb.contract';
export type BreadcrumbProps = BreadcrumbInput;
export declare function Breadcrumb({ label, items }: BreadcrumbProps): import("react").JSX.Element;
