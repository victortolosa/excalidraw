export declare const breadcrumbDefaults: {
    readonly label: "Breadcrumb";
};
