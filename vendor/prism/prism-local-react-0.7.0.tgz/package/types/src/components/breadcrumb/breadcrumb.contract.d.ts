export { breadcrumbDefaults } from './breadcrumb.runtime.ts';
import { z } from 'zod';
export declare const breadcrumbItemSchema: z.ZodObject<{
    id: z.ZodString;
    label: z.ZodString;
    href: z.ZodOptional<z.ZodString>;
    current: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>;
export declare const breadcrumbSchema: z.ZodObject<{
    label: z.ZodDefault<z.ZodString>;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        href: z.ZodOptional<z.ZodString>;
        current: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type BreadcrumbInput = z.input<typeof breadcrumbSchema>;
export declare const breadcrumbJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    label: z.ZodDefault<z.ZodString>;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
        href: z.ZodOptional<z.ZodString>;
        current: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>>;
}, z.core.$strict>>;
