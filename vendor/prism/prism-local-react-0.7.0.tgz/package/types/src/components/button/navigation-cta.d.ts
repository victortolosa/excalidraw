import type { ButtonVariant } from './button.contract';
import type { NavigationCtaInput } from './navigation-cta.contract';
export declare function NavigationCta({ label, href, icon, variant }: NavigationCtaInput & {
    variant?: ButtonVariant;
}): import("react").JSX.Element;
