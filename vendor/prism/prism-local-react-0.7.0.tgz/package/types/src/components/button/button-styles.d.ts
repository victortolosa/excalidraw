export declare const catalogVariants: {
    readonly primary: "default";
    readonly secondary: "outline";
    readonly ghost: "ghost";
    readonly destructive: "outline";
};
export declare const systemClasses: string;
