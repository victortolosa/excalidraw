export { buttonDefaults } from './button.runtime.ts';
import { z } from 'zod';
export declare const buttonIcons: readonly ["add", "close", "edit", "more", "search", "settings", "attachment", "mention", "arrow-right", "pin", "arrow-up-right"];
export declare const buttonVariants: readonly ["primary", "secondary", "ghost", "destructive"];
export declare const buttonTypes: readonly ["button", "submit", "reset"];
export declare const buttonInvalidCombinations: readonly [{
    readonly when: {
        readonly disabled: true;
        readonly loading: true;
    };
    readonly message: "Use loading for pending work and disabled for unavailable actions, not both.";
}];
export declare const buttonSchema: z.ZodObject<{
    children: z.ZodString;
    icon: z.ZodOptional<z.ZodEnum<{
        search: "search";
        close: "close";
        add: "add";
        edit: "edit";
        more: "more";
        settings: "settings";
        attachment: "attachment";
        mention: "mention";
        "arrow-right": "arrow-right";
        pin: "pin";
        "arrow-up-right": "arrow-up-right";
    }>>;
    iconPosition: z.ZodOptional<z.ZodEnum<{
        end: "end";
        start: "start";
    }>>;
    variant: z.ZodDefault<z.ZodEnum<{
        secondary: "secondary";
        primary: "primary";
        destructive: "destructive";
        ghost: "ghost";
    }>>;
    type: z.ZodDefault<z.ZodEnum<{
        button: "button";
        submit: "submit";
        reset: "reset";
    }>>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    loading: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>;
export type ButtonVariant = (typeof buttonVariants)[number];
export type ButtonType = (typeof buttonTypes)[number];
/** Serializable input accepted from JSON, fixtures, and model output. */
export type ButtonInput = z.input<typeof buttonSchema>;
export declare const buttonJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    children: z.ZodString;
    icon: z.ZodOptional<z.ZodEnum<{
        search: "search";
        close: "close";
        add: "add";
        edit: "edit";
        more: "more";
        settings: "settings";
        attachment: "attachment";
        mention: "mention";
        "arrow-right": "arrow-right";
        pin: "pin";
        "arrow-up-right": "arrow-up-right";
    }>>;
    iconPosition: z.ZodOptional<z.ZodEnum<{
        end: "end";
        start: "start";
    }>>;
    variant: z.ZodDefault<z.ZodEnum<{
        secondary: "secondary";
        primary: "primary";
        destructive: "destructive";
        ghost: "ghost";
    }>>;
    type: z.ZodDefault<z.ZodEnum<{
        button: "button";
        submit: "submit";
        reset: "reset";
    }>>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    loading: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>>;
