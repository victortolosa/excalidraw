import type { ComponentPropsWithRef } from 'react';
import type { ButtonInput } from './button.contract';
type ReactOnlyProps = Pick<ComponentPropsWithRef<'button'>, 'ref' | 'id' | 'name' | 'value' | 'form' | 'onClick' | 'onFocus' | 'onBlur' | 'aria-describedby'>;
type ExclusiveStates = {
    disabled?: boolean;
    loading?: false;
} | {
    disabled?: false;
    loading: boolean;
};
export type ButtonProps = ButtonInput & ExclusiveStates & ReactOnlyProps;
export declare function Button({ children, icon, iconPosition, variant, type, disabled, loading, onClick, ...rest }: ButtonProps): import("react").JSX.Element;
export {};
