export declare const buttonMeta: {
    readonly id: "button";
    readonly name: "Button";
    readonly status: "experimental";
    readonly sources: {
        readonly styles: "src/components/button/button-styles.ts";
        readonly "navigation-implementation": "src/components/button/navigation-cta.tsx";
        readonly "navigation-contract": "src/components/button/navigation-cta.contract.ts";
        readonly contract: "src/components/button/button.contract.ts";
        readonly implementation: "src/components/button/button.tsx";
        readonly catalog: "src/components/ui/button.tsx";
        readonly guidance: "src/components/button/button.mdx";
        readonly fixtures: "src/components/button/button.fixtures.ts";
        readonly stories: "src/components/button/button.stories.tsx";
        readonly "catalog-spinner": "src/components/ui/spinner.tsx";
    };
    readonly tokens: readonly ["primary", "primary-foreground", "background", "foreground", "border", "input", "muted", "ring", "destructive"];
    readonly origin: {
        readonly kind: "shadcn-wrapper";
        readonly catalogSources: readonly ["catalog", "catalog-spinner"];
    };
    readonly dependencies: readonly [];
};
