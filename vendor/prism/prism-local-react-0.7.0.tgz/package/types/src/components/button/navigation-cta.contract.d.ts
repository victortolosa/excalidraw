import { z } from 'zod';
export declare const navigationCtaSchema: z.ZodObject<{
    label: z.ZodString;
    href: z.ZodUnion<readonly [z.ZodString, z.ZodURL]>;
    icon: z.ZodOptional<z.ZodEnum<{
        search: "search";
        close: "close";
        add: "add";
        edit: "edit";
        more: "more";
        settings: "settings";
        attachment: "attachment";
        mention: "mention";
        "arrow-right": "arrow-right";
        pin: "pin";
        "arrow-up-right": "arrow-up-right";
    }>>;
}, z.core.$strict>;
export type NavigationCtaInput = z.input<typeof navigationCtaSchema>;
