export declare const buttonDefaults: {
    readonly variant: "primary";
    readonly type: "button";
    readonly disabled: false;
    readonly loading: false;
};
