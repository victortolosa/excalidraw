import { type ReactNode } from 'react';
import type { CardInput } from './card.contract';
export type CardProps = CardInput & {
    children: ReactNode;
};
export declare function Card({ title, label, description, surface, scheme, headingLevel, children }: CardProps): import("react").JSX.Element;
