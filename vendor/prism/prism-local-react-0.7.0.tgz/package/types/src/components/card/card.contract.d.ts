export { cardDefaults } from './card.runtime.ts';
import { z } from 'zod';
import themes from '../../../tokens/themes.json';
export declare const cardSurfaces: (keyof typeof themes.schemes)[];
export declare const cardSchema: z.ZodObject<{
    title: z.ZodOptional<z.ZodString>;
    label: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    surface: z.ZodOptional<z.ZodEnum<{
        default: "default";
        subtle: "subtle";
        emphasis: "emphasis";
    }>>;
    scheme: z.ZodOptional<z.ZodEnum<{
        default: "default";
        subtle: "subtle";
        emphasis: "emphasis";
    }>>;
    headingLevel: z.ZodDefault<z.ZodEnum<{
        2: "2";
        3: "3";
        4: "4";
    }>>;
}, z.core.$strict>;
export type CardInput = z.input<typeof cardSchema>;
export declare const cardJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    title: z.ZodOptional<z.ZodString>;
    label: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    surface: z.ZodOptional<z.ZodEnum<{
        default: "default";
        subtle: "subtle";
        emphasis: "emphasis";
    }>>;
    scheme: z.ZodOptional<z.ZodEnum<{
        default: "default";
        subtle: "subtle";
        emphasis: "emphasis";
    }>>;
    headingLevel: z.ZodDefault<z.ZodEnum<{
        2: "2";
        3: "3";
        4: "4";
    }>>;
}, z.core.$strict>>;
