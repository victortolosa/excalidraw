export declare const cardDefaults: {
    readonly headingLevel: "2";
};
