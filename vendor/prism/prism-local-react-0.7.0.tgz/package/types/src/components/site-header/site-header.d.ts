import { type ReactNode } from 'react';
import type { SiteHeaderInput } from './site-header.contract';
export type SiteHeaderProps = SiteHeaderInput & {
    actions?: ReactNode;
    identityContent?: ReactNode;
};
export declare function SiteHeader({ siteName, homeHref, logoSrc, navigation, mainId, menuLabel, skipLabel, layout, primaryAction, navigationPlacement, identityContent, actions }: SiteHeaderProps): import("react").JSX.Element;
