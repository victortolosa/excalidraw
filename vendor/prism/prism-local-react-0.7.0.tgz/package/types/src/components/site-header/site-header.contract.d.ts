export { siteHeaderDefaults } from './site-header.runtime.ts';
import { z } from 'zod';
export declare const siteHeaderSchema: z.ZodObject<{
    layout: z.ZodDefault<z.ZodEnum<{
        compact: "compact";
        distributed: "distributed";
    }>>;
    primaryAction: z.ZodOptional<z.ZodObject<{
        label: z.ZodString;
        href: z.ZodUnion<readonly [z.ZodString, z.ZodURL]>;
        icon: z.ZodOptional<z.ZodEnum<{
            search: "search";
            close: "close";
            add: "add";
            edit: "edit";
            more: "more";
            settings: "settings";
            attachment: "attachment";
            mention: "mention";
            "arrow-right": "arrow-right";
            pin: "pin";
            "arrow-up-right": "arrow-up-right";
        }>>;
    }, z.core.$strict>>;
    navigationPlacement: z.ZodDefault<z.ZodEnum<{
        separate: "separate";
        "with-actions": "with-actions";
    }>>;
    siteName: z.ZodString;
    homeHref: z.ZodUnion<readonly [z.ZodString, z.ZodURL]>;
    logoSrc: z.ZodOptional<z.ZodString>;
    navigation: z.ZodObject<{
        label: z.ZodString;
        items: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            href: z.ZodUnion<readonly [z.ZodString, z.ZodURL]>;
        }, z.core.$strict>>;
        currentId: z.ZodOptional<z.ZodString>;
        orientation: z.ZodDefault<z.ZodEnum<{
            horizontal: "horizontal";
            vertical: "vertical";
        }>>;
    }, z.core.$strict>;
    mainId: z.ZodDefault<z.ZodDefault<z.ZodString>>;
    menuLabel: z.ZodDefault<z.ZodString>;
    skipLabel: z.ZodDefault<z.ZodString>;
}, z.core.$strict>;
export type SiteHeaderInput = z.input<typeof siteHeaderSchema>;
export declare const siteHeaderJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    layout: z.ZodDefault<z.ZodEnum<{
        compact: "compact";
        distributed: "distributed";
    }>>;
    primaryAction: z.ZodOptional<z.ZodObject<{
        label: z.ZodString;
        href: z.ZodUnion<readonly [z.ZodString, z.ZodURL]>;
        icon: z.ZodOptional<z.ZodEnum<{
            search: "search";
            close: "close";
            add: "add";
            edit: "edit";
            more: "more";
            settings: "settings";
            attachment: "attachment";
            mention: "mention";
            "arrow-right": "arrow-right";
            pin: "pin";
            "arrow-up-right": "arrow-up-right";
        }>>;
    }, z.core.$strict>>;
    navigationPlacement: z.ZodDefault<z.ZodEnum<{
        separate: "separate";
        "with-actions": "with-actions";
    }>>;
    siteName: z.ZodString;
    homeHref: z.ZodUnion<readonly [z.ZodString, z.ZodURL]>;
    logoSrc: z.ZodOptional<z.ZodString>;
    navigation: z.ZodObject<{
        label: z.ZodString;
        items: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
            href: z.ZodUnion<readonly [z.ZodString, z.ZodURL]>;
        }, z.core.$strict>>;
        currentId: z.ZodOptional<z.ZodString>;
        orientation: z.ZodDefault<z.ZodEnum<{
            horizontal: "horizontal";
            vertical: "vertical";
        }>>;
    }, z.core.$strict>;
    mainId: z.ZodDefault<z.ZodDefault<z.ZodString>>;
    menuLabel: z.ZodDefault<z.ZodString>;
    skipLabel: z.ZodDefault<z.ZodString>;
}, z.core.$strict>>;
