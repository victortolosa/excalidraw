export declare const siteHeaderDefaults: {
    readonly layout: "compact";
    readonly navigationPlacement: "separate";
    readonly mainId: "main-content";
    readonly menuLabel: "Menu";
    readonly skipLabel: "Skip to content";
};
