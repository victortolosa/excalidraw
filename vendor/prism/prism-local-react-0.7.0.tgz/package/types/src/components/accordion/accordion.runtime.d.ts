export declare const accordionDefaults: {
    readonly type: "single";
    readonly defaultValue: "";
    readonly disabled: false;
};
