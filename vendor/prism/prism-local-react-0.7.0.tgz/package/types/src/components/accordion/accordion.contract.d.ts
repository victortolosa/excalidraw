export { accordionDefaults } from './accordion.runtime.ts';
import { z } from 'zod';
export declare const accordionItemSchema: z.ZodObject<{
    id: z.ZodString;
    title: z.ZodString;
    disabled: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>;
export declare const accordionSchema: z.ZodUnion<readonly [z.ZodObject<{
    type: z.ZodDefault<z.ZodLiteral<"single">>;
    defaultValue: z.ZodDefault<z.ZodString>;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        disabled: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    disabled: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"multiple">;
    defaultValue: z.ZodDefault<z.ZodArray<z.ZodString>>;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        disabled: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    disabled: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>]>;
export type AccordionInput = z.input<typeof accordionSchema>;
export declare const accordionJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodUnion<readonly [z.ZodObject<{
    type: z.ZodDefault<z.ZodLiteral<"single">>;
    defaultValue: z.ZodDefault<z.ZodString>;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        disabled: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    disabled: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"multiple">;
    defaultValue: z.ZodDefault<z.ZodArray<z.ZodString>>;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        disabled: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    disabled: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>]>>;
