import type { ReactNode } from 'react';
import type { AccordionInput } from './accordion.contract';
type Base = Pick<AccordionInput, 'items' | 'disabled'> & {
    renderPanel: (id: string) => ReactNode;
};
type ValueProps<T> = {
    value: T;
    onValueChange: (value: T) => void;
    defaultValue?: never;
} | {
    value?: never;
    defaultValue?: T;
    onValueChange?: (value: T) => void;
};
export type AccordionProps = Base & (({
    type?: 'single';
} & ValueProps<string>) | ({
    type: 'multiple';
} & ValueProps<string[]>));
export declare function Accordion(props: AccordionProps): import("react").JSX.Element;
export {};
