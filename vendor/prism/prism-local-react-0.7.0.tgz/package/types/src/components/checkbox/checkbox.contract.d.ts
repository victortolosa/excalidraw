export { checkboxDefaults } from './checkbox.runtime.ts';
import { z } from 'zod';
export declare const checkboxSchema: z.ZodObject<{
    label: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    required: z.ZodDefault<z.ZodBoolean>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    defaultChecked: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>;
export type CheckboxInput = z.input<typeof checkboxSchema>;
export declare const checkboxJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    label: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    required: z.ZodDefault<z.ZodBoolean>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    defaultChecked: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>>;
