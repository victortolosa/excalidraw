import type { CheckboxInput } from './checkbox.contract';
type ReactProps = {
    id?: string;
    name?: string;
    value?: string;
    form?: string;
};
type CheckedProps = {
    checked: boolean;
    onCheckedChange: (checked: boolean) => void;
    defaultChecked?: never;
} | {
    checked?: never;
    defaultChecked?: boolean;
    onCheckedChange?: (checked: boolean) => void;
};
export type CheckboxProps = CheckboxInput & ReactProps & CheckedProps;
export declare function Checkbox({ label, description, error, id, name, value, form, required, disabled, checked, defaultChecked, onCheckedChange, }: CheckboxProps): import("react").JSX.Element;
export {};
