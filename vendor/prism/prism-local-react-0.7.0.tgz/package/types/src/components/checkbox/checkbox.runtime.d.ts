export declare const checkboxDefaults: {
    readonly required: false;
    readonly disabled: false;
    readonly defaultChecked: false;
};
