export { textFieldDefaults } from './text-field.runtime.ts';
import { z } from 'zod';
export declare const textFieldSchema: z.ZodObject<{
    label: z.ZodString;
    labelVisibility: z.ZodDefault<z.ZodEnum<{
        hidden: "hidden";
        visible: "visible";
    }>>;
    description: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    type: z.ZodDefault<z.ZodEnum<{
        text: "text";
        email: "email";
        password: "password";
    }>>;
    required: z.ZodDefault<z.ZodBoolean>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    readOnly: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>;
export type TextFieldInput = z.input<typeof textFieldSchema>;
export declare const textFieldJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    label: z.ZodString;
    labelVisibility: z.ZodDefault<z.ZodEnum<{
        hidden: "hidden";
        visible: "visible";
    }>>;
    description: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    type: z.ZodDefault<z.ZodEnum<{
        text: "text";
        email: "email";
        password: "password";
    }>>;
    required: z.ZodDefault<z.ZodBoolean>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    readOnly: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>>;
