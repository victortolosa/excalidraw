import { type ComponentPropsWithRef } from 'react';
import type { TextFieldInput } from './text-field.contract';
type NativeProps = Pick<ComponentPropsWithRef<'input'>, 'id' | 'ref' | 'name' | 'form' | 'autoComplete' | 'onChange' | 'onBlur' | 'onFocus'>;
type ValueProps = {
    value: string;
    onChange: NonNullable<NativeProps['onChange']>;
    defaultValue?: never;
} | {
    value?: never;
    defaultValue?: string;
};
export type TextFieldProps = TextFieldInput & NativeProps & ValueProps;
export declare function TextField({ label, labelVisibility, description, error, id, type, required, disabled, readOnly, ...props }: TextFieldProps): import("react").JSX.Element;
export {};
