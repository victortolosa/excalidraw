export declare const textFieldDefaults: {
    readonly labelVisibility: "visible";
    readonly type: "text";
    readonly required: false;
    readonly disabled: false;
    readonly readOnly: false;
};
