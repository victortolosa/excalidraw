export declare const carouselDefaults: {};
