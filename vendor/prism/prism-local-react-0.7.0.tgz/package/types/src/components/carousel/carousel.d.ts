import { type ReactNode } from 'react';
import type { CarouselInput } from './carousel.contract';
export type CarouselProps = CarouselInput & {
    renderSlide: (id: string) => ReactNode;
};
export declare function Carousel({ label, items, renderSlide }: CarouselProps): import("react").JSX.Element;
