import { type ReactNode } from 'react';
import type { PageInput } from './page.contract';
export type PageProps = Omit<PageInput, 'title' | 'labelledBy' | 'description'> & {
    children: ReactNode;
} & ({
    title: string;
    description?: string;
    actions?: ReactNode;
    labelledBy?: never;
    header?: never;
} | {
    labelledBy: string;
    header: ReactNode;
    title?: never;
    description?: never;
    actions?: never;
});
export declare function Page({ id, title, labelledBy, header, description, width, layout, surface, scheme, sectionSpacing, actionsLayout, actions, children }: PageProps): import("react").JSX.Element;
