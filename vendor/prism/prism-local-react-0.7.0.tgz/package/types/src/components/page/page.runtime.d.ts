export declare const pageActionsLayouts: readonly ["auto", "inline", "stacked"];
export declare const pageDefaults: {
    readonly id: "main-content";
    readonly width: "standard";
    readonly layout: "contained";
    readonly actionsLayout: "auto";
};
