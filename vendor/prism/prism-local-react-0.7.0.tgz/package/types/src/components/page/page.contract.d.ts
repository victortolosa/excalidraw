export { pageDefaults } from './page.runtime.ts';
import { z } from 'zod';
export declare const pageSchema: z.ZodObject<{
    actionsLayout: z.ZodDefault<z.ZodEnum<{
        auto: "auto";
        inline: "inline";
        stacked: "stacked";
    }>>;
    sectionSpacing: z.ZodOptional<z.ZodEnum<{
        compact: "compact";
        spacious: "spacious";
        standard: "standard";
    }>>;
    id: z.ZodDefault<z.ZodString>;
    title: z.ZodOptional<z.ZodString>;
    labelledBy: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    width: z.ZodDefault<z.ZodEnum<{
        standard: "standard";
        narrow: "narrow";
        wide: "wide";
    }>>;
    layout: z.ZodDefault<z.ZodEnum<{
        contained: "contained";
        "full-bleed": "full-bleed";
    }>>;
    surface: z.ZodOptional<z.ZodEnum<{
        default: "default";
        subtle: "subtle";
        emphasis: "emphasis";
    }>>;
    scheme: z.ZodOptional<z.ZodEnum<{
        default: "default";
        subtle: "subtle";
        emphasis: "emphasis";
    }>>;
}, z.core.$strict>;
export type PageInput = z.input<typeof pageSchema>;
export declare const pageJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    actionsLayout: z.ZodDefault<z.ZodEnum<{
        auto: "auto";
        inline: "inline";
        stacked: "stacked";
    }>>;
    sectionSpacing: z.ZodOptional<z.ZodEnum<{
        compact: "compact";
        spacious: "spacious";
        standard: "standard";
    }>>;
    id: z.ZodDefault<z.ZodString>;
    title: z.ZodOptional<z.ZodString>;
    labelledBy: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    width: z.ZodDefault<z.ZodEnum<{
        standard: "standard";
        narrow: "narrow";
        wide: "wide";
    }>>;
    layout: z.ZodDefault<z.ZodEnum<{
        contained: "contained";
        "full-bleed": "full-bleed";
    }>>;
    surface: z.ZodOptional<z.ZodEnum<{
        default: "default";
        subtle: "subtle";
        emphasis: "emphasis";
    }>>;
    scheme: z.ZodOptional<z.ZodEnum<{
        default: "default";
        subtle: "subtle";
        emphasis: "emphasis";
    }>>;
}, z.core.$strict>>;
