export declare const avatarDefaults: {
    readonly size: "default";
    readonly decorative: false;
};
/** Up to two initials: the first letters of the first and last words, so "Ada King Lovelace" becomes "AL". */
export declare function avatarInitials(name: string): string;
