import type { AvatarInput } from './avatar.contract';
export type AvatarProps = AvatarInput;
export declare function Avatar({ name, src, size, decorative }: AvatarProps): import("react").JSX.Element;
