export { avatarDefaults, avatarInitials } from './avatar.runtime.ts';
import { z } from 'zod';
export declare const avatarSizes: readonly ["sm", "default", "lg"];
export declare const avatarSchema: z.ZodObject<{
    name: z.ZodString;
    src: z.ZodOptional<z.ZodString>;
    size: z.ZodDefault<z.ZodEnum<{
        default: "default";
        sm: "sm";
        lg: "lg";
    }>>;
    decorative: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>;
export type AvatarSize = (typeof avatarSizes)[number];
export type AvatarInput = z.input<typeof avatarSchema>;
export declare const avatarJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    name: z.ZodString;
    src: z.ZodOptional<z.ZodString>;
    size: z.ZodDefault<z.ZodEnum<{
        default: "default";
        sm: "sm";
        lg: "lg";
    }>>;
    decorative: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>>;
