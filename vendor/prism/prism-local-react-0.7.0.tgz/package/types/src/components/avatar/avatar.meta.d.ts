export declare const avatarMeta: {
    readonly id: "avatar";
    readonly name: "Avatar";
    readonly status: "experimental";
    readonly sources: {
        readonly contract: "src/components/avatar/avatar.contract.ts";
        readonly implementation: "src/components/avatar/avatar.tsx";
        readonly guidance: "src/components/avatar/avatar.mdx";
        readonly fixtures: "src/components/avatar/avatar.fixtures.ts";
        readonly stories: "src/components/avatar/avatar.stories.tsx";
        readonly catalog: "src/components/ui/avatar.tsx";
    };
    readonly tokens: readonly ["border", "muted", "muted-foreground"];
    readonly origin: {
        readonly kind: "shadcn-wrapper";
        readonly catalogSources: readonly ["catalog"];
    };
    readonly dependencies: readonly [];
};
