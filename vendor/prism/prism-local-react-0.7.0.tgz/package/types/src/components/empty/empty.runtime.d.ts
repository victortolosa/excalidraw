export declare const emptyDefaults: {
    readonly headingLevel: "3";
};
