export { emptyDefaults } from './empty.runtime.ts';
import { z } from 'zod';
export declare const emptySchema: z.ZodObject<{
    title: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    headingLevel: z.ZodDefault<z.ZodEnum<{
        2: "2";
        3: "3";
        4: "4";
    }>>;
}, z.core.$strict>;
export type EmptyInput = z.input<typeof emptySchema>;
export declare const emptyJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    title: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    headingLevel: z.ZodDefault<z.ZodEnum<{
        2: "2";
        3: "3";
        4: "4";
    }>>;
}, z.core.$strict>>;
