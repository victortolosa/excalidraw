import { type ReactNode } from 'react';
import type { EmptyInput } from './empty.contract';
export type EmptyProps = EmptyInput & {
    children?: ReactNode;
};
export declare function Empty({ title, description, headingLevel, children }: EmptyProps): import("react").JSX.Element;
