export { textareaDefaults } from './textarea.runtime.ts';
import { z } from 'zod';
export declare const textareaSchema: z.ZodObject<{
    label: z.ZodString;
    labelVisibility: z.ZodDefault<z.ZodEnum<{
        hidden: "hidden";
        visible: "visible";
    }>>;
    description: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    required: z.ZodDefault<z.ZodBoolean>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    readOnly: z.ZodDefault<z.ZodBoolean>;
    rows: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
export type TextareaInput = z.input<typeof textareaSchema>;
export declare const textareaJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    label: z.ZodString;
    labelVisibility: z.ZodDefault<z.ZodEnum<{
        hidden: "hidden";
        visible: "visible";
    }>>;
    description: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    required: z.ZodDefault<z.ZodBoolean>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    readOnly: z.ZodDefault<z.ZodBoolean>;
    rows: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>>;
