export declare const textareaDefaults: {
    readonly labelVisibility: "visible";
    readonly required: false;
    readonly disabled: false;
    readonly readOnly: false;
};
