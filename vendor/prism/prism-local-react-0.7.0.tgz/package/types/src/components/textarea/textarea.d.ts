import { type ComponentPropsWithRef } from 'react';
import type { TextareaInput } from './textarea.contract';
type NativeProps = Pick<ComponentPropsWithRef<'textarea'>, 'id' | 'ref' | 'name' | 'form' | 'autoComplete' | 'placeholder' | 'onChange' | 'onBlur' | 'onFocus'>;
type ValueProps = {
    value: string;
    onChange: NonNullable<NativeProps['onChange']>;
    defaultValue?: never;
} | {
    value?: never;
    defaultValue?: string;
};
export type TextareaProps = TextareaInput & NativeProps & ValueProps;
export declare function Textarea({ label, labelVisibility, description, error, id, rows, required, disabled, readOnly, ...props }: TextareaProps): import("react").JSX.Element;
export {};
