import { type ReactNode, type Ref } from 'react';
import { type RichTextComposerInput } from './rich-text-composer.contract';
import { type RichTextDocument } from './rich-text-composer.runtime';
export type { RichTextDocument } from './rich-text-composer.runtime';
export type RichTextComposerHandle = {
    focus: () => void;
    getDocument: () => RichTextDocument;
    getText: () => string;
    getMarkdown: () => string;
};
type ValueProps<T> = {
    value: T;
    onValueChange: (value: T) => void;
    defaultValue?: never;
} | {
    value?: never;
    defaultValue?: T;
    onValueChange?: (value: T) => void;
};
export type RichTextComposerProps = Omit<RichTextComposerInput, 'defaultValue' | 'format'> & (({
    format?: 'json';
} & ValueProps<RichTextDocument>) | ({
    format: 'markdown';
} & ValueProps<string>)) & {
    ref?: Ref<RichTextComposerHandle>;
    id?: string;
    name?: string;
    form?: string;
    headerActions?: ReactNode;
    secondaryActions?: ReactNode;
    actions?: ReactNode;
};
export declare function RichTextComposer(props: RichTextComposerProps): import("react").JSX.Element;
