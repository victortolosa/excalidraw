import { z } from 'zod';
import { type RichTextDocument } from './rich-text-composer.runtime.ts';
export declare const richTextDocumentSchema: z.ZodType<RichTextDocument>;
export declare const richTextComposerSchema: z.ZodObject<{
    description: z.ZodOptional<z.ZodString>;
    label: z.ZodString;
    status: z.ZodOptional<z.ZodString>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    error: z.ZodOptional<z.ZodString>;
    readOnly: z.ZodDefault<z.ZodBoolean>;
    rows: z.ZodDefault<z.ZodNumber>;
    labelVisibility: z.ZodDefault<z.ZodEnum<{
        hidden: "hidden";
        visible: "visible";
    }>>;
    busy: z.ZodDefault<z.ZodBoolean>;
    clearable: z.ZodDefault<z.ZodBoolean>;
    clearLabel: z.ZodDefault<z.ZodString>;
    undoLabel: z.ZodDefault<z.ZodString>;
    maxRows: z.ZodOptional<z.ZodNumber>;
    submissionError: z.ZodOptional<z.ZodString>;
    format: z.ZodOptional<z.ZodEnum<{
        json: "json";
        markdown: "markdown";
    }>>;
    defaultValue: z.ZodOptional<z.ZodUnion<readonly [z.ZodType<RichTextDocument, unknown, z.core.$ZodTypeInternals<RichTextDocument, unknown>>, z.ZodString]>>;
}, z.core.$strict>;
export type RichTextComposerInput = z.input<typeof richTextComposerSchema>;
export declare const richTextComposerJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    description: z.ZodOptional<z.ZodString>;
    label: z.ZodString;
    status: z.ZodOptional<z.ZodString>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    error: z.ZodOptional<z.ZodString>;
    readOnly: z.ZodDefault<z.ZodBoolean>;
    rows: z.ZodDefault<z.ZodNumber>;
    labelVisibility: z.ZodDefault<z.ZodEnum<{
        hidden: "hidden";
        visible: "visible";
    }>>;
    busy: z.ZodDefault<z.ZodBoolean>;
    clearable: z.ZodDefault<z.ZodBoolean>;
    clearLabel: z.ZodDefault<z.ZodString>;
    undoLabel: z.ZodDefault<z.ZodString>;
    maxRows: z.ZodOptional<z.ZodNumber>;
    submissionError: z.ZodOptional<z.ZodString>;
    format: z.ZodOptional<z.ZodEnum<{
        json: "json";
        markdown: "markdown";
    }>>;
    defaultValue: z.ZodOptional<z.ZodUnion<readonly [z.ZodType<RichTextDocument, unknown, z.core.$ZodTypeInternals<RichTextDocument, unknown>>, z.ZodString]>>;
}, z.core.$strict>>;
