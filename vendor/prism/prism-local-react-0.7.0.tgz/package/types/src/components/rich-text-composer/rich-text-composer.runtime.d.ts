export declare const richTextComposerDefaults: {
    readonly rows: 3;
    readonly maxRows: 12;
};
export type RichTextMark = {
    type: 'bold' | 'italic';
} | {
    type: 'link';
    attrs: {
        href: string;
    };
};
export type RichTextInline = {
    type: 'text';
    text: string;
    marks?: RichTextMark[];
} | {
    type: 'hardBreak';
};
export type RichTextParagraph = {
    type: 'paragraph';
    content?: RichTextInline[];
};
export type RichTextHeading = {
    type: 'heading';
    attrs: {
        level: 1 | 2 | 3;
    };
    content?: RichTextInline[];
};
export type RichTextListItem = {
    type: 'listItem';
    content: [RichTextParagraph, ...(RichTextParagraph | RichTextHeading | RichTextList)[]];
};
export type RichTextList = {
    type: 'bulletList';
    content: RichTextListItem[];
} | {
    type: 'orderedList';
    attrs?: {
        start: number;
    };
    content: RichTextListItem[];
};
export type RichTextDocument = {
    type: 'doc';
    content: (RichTextParagraph | RichTextHeading | RichTextList)[];
};
export declare const emptyRichTextDocument: RichTextDocument;
export declare function isSafeRichTextLink(href: string): boolean;
export declare function richTextContentText(document: RichTextDocument): string;
