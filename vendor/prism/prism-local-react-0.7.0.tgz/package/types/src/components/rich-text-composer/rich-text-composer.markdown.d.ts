export declare function validateRichTextMarkdown(markdown: string): void;
