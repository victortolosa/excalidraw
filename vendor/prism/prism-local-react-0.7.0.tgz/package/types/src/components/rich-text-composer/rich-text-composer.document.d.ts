import { type JSONContent } from '@tiptap/core';
import { type RichTextDocument } from './rich-text-composer.runtime';
export declare const richTextExtensions: import("@tiptap/core").Extension<import("@tiptap/starter-kit").StarterKitOptions, any>[];
export declare function portable(content: JSONContent): RichTextDocument;
export declare function parseRichTextValue(value: RichTextDocument | string | undefined, format: 'json' | 'markdown'): RichTextDocument;
export declare function serializeRichTextMarkdown(document: RichTextDocument): string;
