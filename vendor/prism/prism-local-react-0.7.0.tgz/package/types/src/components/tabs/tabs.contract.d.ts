export { tabsDefaults, firstEnabledTab } from './tabs.runtime.ts';
import { z } from 'zod';
export declare const tabsItemSchema: z.ZodObject<{
    value: z.ZodString;
    label: z.ZodString;
    disabled: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>;
export declare const tabsSizes: readonly ["default", "sm"];
export declare const tabsListSchema: z.ZodObject<{
    label: z.ZodString;
    tabs: z.ZodArray<z.ZodObject<{
        value: z.ZodString;
        label: z.ZodString;
        disabled: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>>;
    truncate: z.ZodOptional<z.ZodBoolean>;
    size: z.ZodDefault<z.ZodEnum<{
        default: "default";
        sm: "sm";
    }>>;
}, z.core.$strict>;
export declare const tabsSchema: z.ZodObject<{
    defaultValue: z.ZodOptional<z.ZodString>;
    label: z.ZodString;
    tabs: z.ZodArray<z.ZodObject<{
        value: z.ZodString;
        label: z.ZodString;
        disabled: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>>;
    truncate: z.ZodOptional<z.ZodBoolean>;
    size: z.ZodDefault<z.ZodEnum<{
        default: "default";
        sm: "sm";
    }>>;
}, z.core.$strict>;
export type TabsItem = z.input<typeof tabsItemSchema>;
export type TabsInput = z.input<typeof tabsSchema>;
export type TabsListInput = z.input<typeof tabsListSchema>;
export declare const tabsJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    defaultValue: z.ZodOptional<z.ZodString>;
    label: z.ZodString;
    tabs: z.ZodArray<z.ZodObject<{
        value: z.ZodString;
        label: z.ZodString;
        disabled: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>>;
    truncate: z.ZodOptional<z.ZodBoolean>;
    size: z.ZodDefault<z.ZodEnum<{
        default: "default";
        sm: "sm";
    }>>;
}, z.core.$strict>>;
export declare const tabsListJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    label: z.ZodString;
    tabs: z.ZodArray<z.ZodObject<{
        value: z.ZodString;
        label: z.ZodString;
        disabled: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>>;
    truncate: z.ZodOptional<z.ZodBoolean>;
    size: z.ZodDefault<z.ZodEnum<{
        default: "default";
        sm: "sm";
    }>>;
}, z.core.$strict>>;
