import type { TabsItem } from './tabs.contract.ts';
export declare const tabsDefaults: {
    readonly size: "default";
};
/** The tab selected when no value is given: the first enabled one. */
export declare const firstEnabledTab: (tabs: readonly TabsItem[]) => string | undefined;
