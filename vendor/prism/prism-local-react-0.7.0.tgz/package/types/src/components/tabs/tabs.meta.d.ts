export declare const tabsMeta: {
    readonly id: "tabs";
    readonly name: "Tabs";
    readonly status: "experimental";
    readonly sources: {
        readonly contract: "src/components/tabs/tabs.contract.ts";
        readonly implementation: "src/components/tabs/tabs.tsx";
        readonly guidance: "src/components/tabs/tabs.mdx";
        readonly fixtures: "src/components/tabs/tabs.fixtures.ts";
        readonly stories: "src/components/tabs/tabs.stories.tsx";
        readonly catalog: "src/components/ui/tabs.tsx";
    };
    readonly tokens: readonly ["background", "foreground", "input", "muted", "muted-foreground", "ring"];
    readonly origin: {
        readonly kind: "shadcn-wrapper";
        readonly catalogSources: readonly ["catalog"];
    };
    readonly dependencies: readonly [];
};
