import type { ReactNode } from 'react';
import type { TabsInput, TabsListInput } from './tabs.contract';
type ValueProps = {
    value: string;
    onValueChange: (value: string) => void;
    defaultValue?: never;
} | {
    value?: never;
    defaultValue?: string;
    onValueChange?: (value: string) => void;
};
export type TabsProps = Omit<TabsInput, 'defaultValue'> & ValueProps & {
    /** Content of the panel for a tab. Only the selected panel is rendered. */
    renderPanel: (value: string) => ReactNode;
};
/** The tab list. Use inside TabsRoot, or let Tabs place it for you. */
export declare function TabsList({ label, tabs, truncate, size }: TabsListInput): import("react").JSX.Element;
type RootValueProps = {
    value: string;
    onValueChange: (value: string) => void;
    defaultValue?: never;
} | {
    value?: never;
    defaultValue: string;
    onValueChange?: (value: string) => void;
};
/** Owns the selected tab for a composed set. TabsList and every TabsPanel must be inside it. */
export declare function TabsRoot({ value, defaultValue, onValueChange, children }: RootValueProps & {
    children: ReactNode;
}): import("react").JSX.Element;
/** The panel for one tab. Only the selected panel is rendered; it is focusable, as the tabs pattern requires. */
export declare function TabsPanel({ value, children }: {
    value: string;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function Tabs({ label, tabs, value, defaultValue, onValueChange, truncate, size, renderPanel }: TabsProps): import("react").JSX.Element;
export {};
