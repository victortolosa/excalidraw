export declare const toastDefaults: {
    readonly variant: "default";
    readonly duration: 6000;
};
