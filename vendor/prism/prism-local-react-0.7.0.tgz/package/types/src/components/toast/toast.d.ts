import { type ReactNode } from 'react';
import type { ToastInput } from './toast.contract';
type ToastId = string | number;
/** Mount once around the application; the host portals to body, outside regional surfaces. */
export declare function ToastProvider({ children, validateInput }: {
    children: ReactNode;
    validateInput?: (input: ToastInput) => ToastInput;
}): import("react").JSX.Element;
export declare function useToast(): {
    show: (input: ToastInput) => ToastId;
    dismiss: (id: ToastId) => void;
};
export {};
