import { type ToastInput } from './toast.contract';
/** Opt-in validation for untrusted input or development checks. */
export declare function validateToast(input: ToastInput): ToastInput;
