export { toastDefaults } from './toast.runtime.ts';
import { z } from 'zod';
export declare const toastVariants: readonly ["default", "success", "info", "warning", "destructive"];
export declare const toastSchema: z.ZodObject<{
    title: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    variant: z.ZodDefault<z.ZodEnum<{
        destructive: "destructive";
        success: "success";
        warning: "warning";
        info: "info";
        default: "default";
    }>>;
    duration: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export type ToastInput = z.input<typeof toastSchema>;
export declare const toastJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    title: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    variant: z.ZodDefault<z.ZodEnum<{
        destructive: "destructive";
        success: "success";
        warning: "warning";
        info: "info";
        default: "default";
    }>>;
    duration: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>>;
