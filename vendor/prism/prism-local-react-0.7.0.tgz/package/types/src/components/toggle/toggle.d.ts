import type { ComponentPropsWithRef } from 'react';
import type { ToggleInput } from './toggle.contract';
type PressedProps = {
    pressed: boolean;
    onPressedChange: (pressed: boolean) => void;
    defaultPressed?: never;
} | {
    pressed?: never;
    onPressedChange?: (pressed: boolean) => void;
    defaultPressed?: boolean;
};
export type ToggleProps = Omit<ToggleInput, 'defaultPressed'> & PressedProps & Pick<ComponentPropsWithRef<'button'>, 'ref' | 'id' | 'aria-describedby'>;
export declare function Toggle({ label, icon, variant, disabled, pending, defaultPressed, onPressedChange, ...state }: ToggleProps): import("react").JSX.Element;
export {};
