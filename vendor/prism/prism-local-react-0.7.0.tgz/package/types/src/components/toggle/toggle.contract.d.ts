export { toggleDefaults } from './toggle.runtime.ts';
import { z } from 'zod';
export declare const toggleSchema: z.ZodObject<{
    label: z.ZodString;
    icon: z.ZodOptional<z.ZodEnum<{
        pin: "pin";
        star: "star";
    }>>;
    variant: z.ZodDefault<z.ZodEnum<{
        outline: "outline";
        plain: "plain";
    }>>;
    pending: z.ZodDefault<z.ZodBoolean>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    defaultPressed: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>;
export type ToggleInput = z.input<typeof toggleSchema>;
export declare const toggleJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    label: z.ZodString;
    icon: z.ZodOptional<z.ZodEnum<{
        pin: "pin";
        star: "star";
    }>>;
    variant: z.ZodDefault<z.ZodEnum<{
        outline: "outline";
        plain: "plain";
    }>>;
    pending: z.ZodDefault<z.ZodBoolean>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    defaultPressed: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>>;
