export declare const toggleDefaults: {
    readonly variant: "plain";
    readonly disabled: false;
    readonly pending: false;
    readonly defaultPressed: false;
};
