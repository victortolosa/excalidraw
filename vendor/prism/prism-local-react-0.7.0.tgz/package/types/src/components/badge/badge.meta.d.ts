export declare const badgeMeta: {
    readonly id: "badge";
    readonly name: "Badge";
    readonly status: "experimental";
    readonly sources: {
        readonly contract: "src/components/badge/badge.contract.ts";
        readonly implementation: "src/components/badge/badge.tsx";
        readonly guidance: "src/components/badge/badge.mdx";
        readonly fixtures: "src/components/badge/badge.fixtures.ts";
        readonly stories: "src/components/badge/badge.stories.tsx";
        readonly catalog: "src/components/ui/badge.tsx";
    };
    readonly tokens: readonly ["destructive", "info", "secondary", "secondary-foreground", "success", "warning"];
    readonly origin: {
        readonly kind: "shadcn-wrapper";
        readonly catalogSources: readonly ["catalog"];
    };
    readonly dependencies: readonly [];
};
