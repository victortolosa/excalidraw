export { badgeDefaults } from './badge.runtime.ts';
import { z } from 'zod';
export declare const badgeVariants: readonly ["neutral", "info", "success", "warning", "destructive"];
export declare const badgeIndicators: readonly ["dot", "sync"];
export declare const badgeSchema: z.ZodObject<{
    children: z.ZodString;
    variant: z.ZodDefault<z.ZodEnum<{
        destructive: "destructive";
        success: "success";
        warning: "warning";
        info: "info";
        neutral: "neutral";
    }>>;
    indicator: z.ZodOptional<z.ZodEnum<{
        sync: "sync";
        dot: "dot";
    }>>;
}, z.core.$strict>;
export type BadgeIndicator = (typeof badgeIndicators)[number];
export type BadgeVariant = (typeof badgeVariants)[number];
export type BadgeInput = z.input<typeof badgeSchema>;
export declare const badgeJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    children: z.ZodString;
    variant: z.ZodDefault<z.ZodEnum<{
        destructive: "destructive";
        success: "success";
        warning: "warning";
        info: "info";
        neutral: "neutral";
    }>>;
    indicator: z.ZodOptional<z.ZodEnum<{
        sync: "sync";
        dot: "dot";
    }>>;
}, z.core.$strict>>;
