export declare const badgeDefaults: {
    readonly variant: "neutral";
};
