import type { BadgeInput } from './badge.contract';
export type BadgeProps = BadgeInput;
export declare function Badge({ children, variant, indicator }: BadgeProps): import("react").JSX.Element;
