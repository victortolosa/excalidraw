import type { ButtonGroupInput } from './button-group.contract';
export type ButtonGroupProps = ButtonGroupInput & {
    onAction: (id: string) => void;
};
export declare function ButtonGroup({ label, items, orientation, onAction }: ButtonGroupProps): import("react").JSX.Element;
