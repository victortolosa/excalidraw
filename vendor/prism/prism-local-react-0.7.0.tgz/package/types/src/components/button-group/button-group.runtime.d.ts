export declare const buttonGroupDefaults: {
    readonly orientation: "horizontal";
};
