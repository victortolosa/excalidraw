export { buttonGroupDefaults } from './button-group.runtime.ts';
import { z } from 'zod';
export declare const buttonGroupItemSchema: z.ZodObject<{
    id: z.ZodString;
    button: z.ZodObject<{
        children: z.ZodString;
        icon: z.ZodOptional<z.ZodEnum<{
            search: "search";
            close: "close";
            add: "add";
            edit: "edit";
            more: "more";
            settings: "settings";
            attachment: "attachment";
            mention: "mention";
            "arrow-right": "arrow-right";
            pin: "pin";
            "arrow-up-right": "arrow-up-right";
        }>>;
        iconPosition: z.ZodOptional<z.ZodEnum<{
            end: "end";
            start: "start";
        }>>;
        variant: z.ZodDefault<z.ZodEnum<{
            secondary: "secondary";
            primary: "primary";
            destructive: "destructive";
            ghost: "ghost";
        }>>;
        type: z.ZodDefault<z.ZodEnum<{
            button: "button";
            submit: "submit";
            reset: "reset";
        }>>;
        disabled: z.ZodDefault<z.ZodBoolean>;
        loading: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const buttonGroupSchema: z.ZodObject<{
    label: z.ZodString;
    orientation: z.ZodDefault<z.ZodEnum<{
        horizontal: "horizontal";
        vertical: "vertical";
    }>>;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        button: z.ZodObject<{
            children: z.ZodString;
            icon: z.ZodOptional<z.ZodEnum<{
                search: "search";
                close: "close";
                add: "add";
                edit: "edit";
                more: "more";
                settings: "settings";
                attachment: "attachment";
                mention: "mention";
                "arrow-right": "arrow-right";
                pin: "pin";
                "arrow-up-right": "arrow-up-right";
            }>>;
            iconPosition: z.ZodOptional<z.ZodEnum<{
                end: "end";
                start: "start";
            }>>;
            variant: z.ZodDefault<z.ZodEnum<{
                secondary: "secondary";
                primary: "primary";
                destructive: "destructive";
                ghost: "ghost";
            }>>;
            type: z.ZodDefault<z.ZodEnum<{
                button: "button";
                submit: "submit";
                reset: "reset";
            }>>;
            disabled: z.ZodDefault<z.ZodBoolean>;
            loading: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ButtonGroupInput = z.input<typeof buttonGroupSchema>;
export declare const buttonGroupJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    label: z.ZodString;
    orientation: z.ZodDefault<z.ZodEnum<{
        horizontal: "horizontal";
        vertical: "vertical";
    }>>;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        button: z.ZodObject<{
            children: z.ZodString;
            icon: z.ZodOptional<z.ZodEnum<{
                search: "search";
                close: "close";
                add: "add";
                edit: "edit";
                more: "more";
                settings: "settings";
                attachment: "attachment";
                mention: "mention";
                "arrow-right": "arrow-right";
                pin: "pin";
                "arrow-up-right": "arrow-up-right";
            }>>;
            iconPosition: z.ZodOptional<z.ZodEnum<{
                end: "end";
                start: "start";
            }>>;
            variant: z.ZodDefault<z.ZodEnum<{
                secondary: "secondary";
                primary: "primary";
                destructive: "destructive";
                ghost: "ghost";
            }>>;
            type: z.ZodDefault<z.ZodEnum<{
                button: "button";
                submit: "submit";
                reset: "reset";
            }>>;
            disabled: z.ZodDefault<z.ZodBoolean>;
            loading: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
}, z.core.$strict>>;
