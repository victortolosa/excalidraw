export declare const tableDefaults: {
    readonly hideCaption: false;
    readonly emptyMessage: "No items to show.";
};
export declare const tableColumnDefaults: {
    readonly align: "start";
};
