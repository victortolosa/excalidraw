import type { ReactNode } from 'react';
import type { TableInput, TableRowData } from './table.contract';
export type TableProps<Row extends TableRowData = TableRowData> = Omit<TableInput, 'rows'> & {
    rows: readonly Row[];
    /** Rich content for a cell, such as an Avatar or Badge. Return undefined to show the row's text value. */
    renderCell?: (columnKey: string, row: Row) => ReactNode;
};
export declare function Table<Row extends TableRowData>({ caption, hideCaption, columns, rows, emptyMessage, renderCell, }: TableProps<Row>): import("react").JSX.Element;
