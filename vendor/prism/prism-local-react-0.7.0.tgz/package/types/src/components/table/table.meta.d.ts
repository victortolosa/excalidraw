export declare const tableMeta: {
    readonly id: "table";
    readonly name: "Table";
    readonly status: "experimental";
    readonly sources: {
        readonly contract: "src/components/table/table.contract.ts";
        readonly implementation: "src/components/table/table.tsx";
        readonly guidance: "src/components/table/table.mdx";
        readonly fixtures: "src/components/table/table.fixtures.ts";
        readonly stories: "src/components/table/table.stories.tsx";
        readonly catalog: "src/components/ui/table.tsx";
    };
    readonly tokens: readonly ["border", "foreground", "muted", "muted-foreground"];
    readonly origin: {
        readonly kind: "shadcn-wrapper";
        readonly catalogSources: readonly ["catalog"];
    };
    readonly dependencies: readonly [];
};
