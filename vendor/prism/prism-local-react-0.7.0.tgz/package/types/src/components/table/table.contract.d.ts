export { tableDefaults, tableColumnDefaults } from './table.runtime.ts';
import { z } from 'zod';
export declare const tableAlignments: readonly ["start", "end"];
export declare const tableColumnSchema: z.ZodObject<{
    key: z.ZodString;
    header: z.ZodString;
    align: z.ZodDefault<z.ZodEnum<{
        end: "end";
        start: "start";
    }>>;
}, z.core.$strict>;
export declare const tableRowSchema: z.ZodObject<{
    id: z.ZodString;
}, z.core.$catchall<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>>;
export declare const tableSchema: z.ZodObject<{
    caption: z.ZodString;
    hideCaption: z.ZodDefault<z.ZodBoolean>;
    columns: z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        header: z.ZodString;
        align: z.ZodDefault<z.ZodEnum<{
            end: "end";
            start: "start";
        }>>;
    }, z.core.$strict>>;
    rows: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
    }, z.core.$catchall<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>>>;
    emptyMessage: z.ZodDefault<z.ZodString>;
}, z.core.$strict>;
export type TableAlignment = (typeof tableAlignments)[number];
export type TableRowData = z.infer<typeof tableRowSchema>;
export type TableInput = z.input<typeof tableSchema>;
export declare const tableJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    caption: z.ZodString;
    hideCaption: z.ZodDefault<z.ZodBoolean>;
    columns: z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        header: z.ZodString;
        align: z.ZodDefault<z.ZodEnum<{
            end: "end";
            start: "start";
        }>>;
    }, z.core.$strict>>;
    rows: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
    }, z.core.$catchall<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>>>;
    emptyMessage: z.ZodDefault<z.ZodString>;
}, z.core.$strict>>;
