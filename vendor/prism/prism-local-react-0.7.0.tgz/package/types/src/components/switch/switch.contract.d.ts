export { switchDefaults } from './switch.runtime.ts';
import { z } from 'zod';
export declare const switchSchema: z.ZodObject<{
    label: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    required: z.ZodDefault<z.ZodBoolean>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    defaultChecked: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>;
export type SwitchInput = z.input<typeof switchSchema>;
export declare const switchJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    label: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    error: z.ZodOptional<z.ZodString>;
    required: z.ZodDefault<z.ZodBoolean>;
    disabled: z.ZodDefault<z.ZodBoolean>;
    defaultChecked: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>>;
