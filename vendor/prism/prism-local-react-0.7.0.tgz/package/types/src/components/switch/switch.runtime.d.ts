export declare const switchDefaults: {
    readonly required: false;
    readonly disabled: false;
    readonly defaultChecked: false;
};
