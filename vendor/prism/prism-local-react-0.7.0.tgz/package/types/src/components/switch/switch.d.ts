import type { SwitchInput } from './switch.contract';
type ReactProps = {
    id?: string;
    name?: string;
    value?: string;
    form?: string;
};
type CheckedProps = {
    checked: boolean;
    onCheckedChange: (checked: boolean) => void;
    defaultChecked?: never;
} | {
    checked?: never;
    defaultChecked?: boolean;
    onCheckedChange?: (checked: boolean) => void;
};
export type SwitchProps = SwitchInput & ReactProps & CheckedProps;
export declare function Switch({ label, description, error, id, name, value, form, required, disabled, checked, defaultChecked, onCheckedChange, }: SwitchProps): import("react").JSX.Element;
export {};
