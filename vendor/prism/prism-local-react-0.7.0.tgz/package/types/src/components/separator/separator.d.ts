import type { SeparatorInput } from './separator.contract';
export type SeparatorProps = SeparatorInput;
export declare function Separator({ orientation, decorative }: SeparatorProps): import("react").JSX.Element;
