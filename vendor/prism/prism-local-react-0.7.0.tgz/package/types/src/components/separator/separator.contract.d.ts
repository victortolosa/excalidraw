export { separatorDefaults } from './separator.runtime.ts';
import { z } from 'zod';
export declare const separatorSchema: z.ZodObject<{
    orientation: z.ZodDefault<z.ZodEnum<{
        horizontal: "horizontal";
        vertical: "vertical";
    }>>;
    decorative: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>;
export type SeparatorInput = z.input<typeof separatorSchema>;
export declare const separatorJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    orientation: z.ZodDefault<z.ZodEnum<{
        horizontal: "horizontal";
        vertical: "vertical";
    }>>;
    decorative: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>>;
