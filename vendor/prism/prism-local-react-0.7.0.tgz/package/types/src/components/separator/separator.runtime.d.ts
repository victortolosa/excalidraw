export declare const separatorDefaults: {
    readonly orientation: "horizontal";
    readonly decorative: true;
};
