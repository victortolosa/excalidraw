export declare const actionIconNames: readonly ["add", "close", "edit", "more", "search", "settings", "attachment", "mention", "arrow-right", "pin", "arrow-up-right"];
export type ActionIconName = typeof actionIconNames[number];
