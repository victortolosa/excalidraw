export declare const contentWidths: readonly ["narrow", "standard", "wide"];
export declare const contentWidthClasses: {
    readonly narrow: "max-w-2xl";
    readonly standard: "max-w-5xl";
    readonly wide: "max-w-7xl";
};
