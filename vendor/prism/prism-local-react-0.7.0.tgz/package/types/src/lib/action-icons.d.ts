import { type LucideIcon } from 'lucide-react';
export declare const actionIcons: {
    readonly add: LucideIcon;
    readonly close: LucideIcon;
    readonly edit: LucideIcon;
    readonly more: LucideIcon;
    readonly search: LucideIcon;
    readonly settings: LucideIcon;
    readonly attachment: LucideIcon;
    readonly mention: LucideIcon;
    readonly 'arrow-right': LucideIcon;
    readonly pin: LucideIcon;
    readonly 'arrow-up-right': LucideIcon;
};
