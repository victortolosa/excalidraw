export declare const sectionSpacings: readonly ["compact", "standard", "spacious"];
export type SectionSpacing = typeof sectionSpacings[number];
