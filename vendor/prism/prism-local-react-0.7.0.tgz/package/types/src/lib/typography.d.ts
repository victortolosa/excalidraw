import themes from '../../tokens/themes.json';
export declare const typographyProperties: {
    readonly fontFamily: {
        readonly suffix: "font-family";
        readonly type: "fontFamily";
        readonly css: "font-family";
    };
    readonly fontSize: {
        readonly suffix: "font-size";
        readonly type: "dimension";
        readonly css: "font-size";
    };
    readonly fontWeight: {
        readonly suffix: "font-weight";
        readonly type: "fontWeight";
        readonly css: "font-weight";
    };
    readonly lineHeight: {
        readonly suffix: "line-height";
        readonly type: "number";
        readonly css: "line-height";
    };
    readonly letterSpacing: {
        readonly suffix: "letter-spacing";
        readonly type: "number";
        readonly css: "letter-spacing";
    };
};
export type TypographyComponent = keyof typeof themes.typographySlots;
export type TypographySlot<C extends TypographyComponent> = keyof (typeof themes.typographySlots)[C] & string;
export declare function typographyProps<C extends TypographyComponent>(component: C, slot: TypographySlot<C>): {
    'data-typography': string;
};
export declare function typographyToken<C extends TypographyComponent>(component: C, slot: TypographySlot<C>, property: keyof typeof typographyProperties): string;
export declare function penTypography<C extends TypographyComponent>(component: C, slot: TypographySlot<C>): {
    [k: string]: string;
};
