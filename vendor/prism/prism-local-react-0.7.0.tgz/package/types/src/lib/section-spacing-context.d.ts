export declare const SectionSpacingContext: import("react").Context<"compact" | "spacious" | "standard" | undefined>;
