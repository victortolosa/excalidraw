export declare const signupFormDefaults: {
    readonly title: "Create an account";
    readonly description: "Enter your information below to create your account";
    readonly nameLabel: "Full Name";
    readonly emailLabel: "Email";
    readonly emailDescription: "We'll use this to contact you.";
    readonly passwordLabel: "Password";
    readonly passwordDescription: "Must be at least 8 characters long.";
    readonly confirmationLabel: "Confirm Password";
    readonly confirmationDescription: "Please confirm your password.";
    readonly submitLabel: "Create Account";
    readonly providerLabel: "Sign up with Google";
    readonly signInPrompt: "Already have an account?";
    readonly signInLabel: "Sign in";
};
