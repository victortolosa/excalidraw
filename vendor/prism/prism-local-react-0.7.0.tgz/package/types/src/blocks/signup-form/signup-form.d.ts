import { type SignupFormInput, type SignupSubmission } from './signup-form.contract';
export type SignupFormProps = SignupFormInput & {
    onSubmit: (values: SignupSubmission) => Promise<{
        message: string;
    }>;
    onGoogleSignup: () => Promise<{
        message: string;
    }>;
};
export declare function SignupForm({ onSubmit, onGoogleSignup, signInHref, ...content }: SignupFormProps): import("react").JSX.Element;
