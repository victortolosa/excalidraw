import type { ReactNode } from 'react';
import type { HeroInput } from './hero.contract';
type ActionProps = {
    onAction?: (id: string) => void;
    pendingAction?: string;
};
export type HeroProps = Omit<HeroInput, 'media'> & ActionProps & ({
    media?: Extract<NonNullable<HeroInput['media']>, {
        kind: 'image';
    }>;
    mediaContent?: never;
} | {
    media: Extract<NonNullable<HeroInput['media']>, {
        kind: 'slot';
    }>;
    mediaContent: ReactNode;
});
export declare function Hero({ headingId, heading, eyebrow, description, composition, primaryAction, secondaryAction, media, mediaContent, onAction, pendingAction }: HeroProps): import("react").JSX.Element;
export {};
