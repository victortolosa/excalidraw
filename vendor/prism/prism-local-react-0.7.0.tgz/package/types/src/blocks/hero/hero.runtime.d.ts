export declare const heroDefaults: {
    readonly composition: "centered";
};
