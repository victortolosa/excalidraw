export { heroDefaults } from './hero.runtime.ts';
import { z } from 'zod';
export declare const heroActionSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    label: z.ZodString;
    href: z.ZodUnion<readonly [z.ZodString, z.ZodURL]>;
    icon: z.ZodOptional<z.ZodEnum<{
        search: "search";
        close: "close";
        add: "add";
        edit: "edit";
        more: "more";
        settings: "settings";
        attachment: "attachment";
        mention: "mention";
        "arrow-right": "arrow-right";
        pin: "pin";
        "arrow-up-right": "arrow-up-right";
    }>>;
    kind: z.ZodLiteral<"link">;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"action">;
    label: z.ZodString;
    id: z.ZodString;
    icon: z.ZodOptional<z.ZodEnum<{
        search: "search";
        close: "close";
        add: "add";
        edit: "edit";
        more: "more";
        settings: "settings";
        attachment: "attachment";
        mention: "mention";
        "arrow-right": "arrow-right";
        pin: "pin";
        "arrow-up-right": "arrow-up-right";
    }>>;
}, z.core.$strict>], "kind">;
export declare const heroMediaSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"image">;
    src: z.ZodString;
    alt: z.ZodString;
    width: z.ZodNumber;
    height: z.ZodNumber;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"slot">;
    label: z.ZodString;
}, z.core.$strict>], "kind">;
export declare const heroSchema: z.ZodObject<{
    headingId: z.ZodString;
    heading: z.ZodArray<z.ZodObject<{
        text: z.ZodString;
        emphasis: z.ZodOptional<z.ZodBoolean>;
        breakBefore: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    composition: z.ZodDefault<z.ZodEnum<{
        split: "split";
        centered: "centered";
        "centered-media": "centered-media";
    }>>;
    eyebrow: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    primaryAction: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        label: z.ZodString;
        href: z.ZodUnion<readonly [z.ZodString, z.ZodURL]>;
        icon: z.ZodOptional<z.ZodEnum<{
            search: "search";
            close: "close";
            add: "add";
            edit: "edit";
            more: "more";
            settings: "settings";
            attachment: "attachment";
            mention: "mention";
            "arrow-right": "arrow-right";
            pin: "pin";
            "arrow-up-right": "arrow-up-right";
        }>>;
        kind: z.ZodLiteral<"link">;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"action">;
        label: z.ZodString;
        id: z.ZodString;
        icon: z.ZodOptional<z.ZodEnum<{
            search: "search";
            close: "close";
            add: "add";
            edit: "edit";
            more: "more";
            settings: "settings";
            attachment: "attachment";
            mention: "mention";
            "arrow-right": "arrow-right";
            pin: "pin";
            "arrow-up-right": "arrow-up-right";
        }>>;
    }, z.core.$strict>], "kind">>;
    secondaryAction: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        label: z.ZodString;
        href: z.ZodUnion<readonly [z.ZodString, z.ZodURL]>;
        icon: z.ZodOptional<z.ZodEnum<{
            search: "search";
            close: "close";
            add: "add";
            edit: "edit";
            more: "more";
            settings: "settings";
            attachment: "attachment";
            mention: "mention";
            "arrow-right": "arrow-right";
            pin: "pin";
            "arrow-up-right": "arrow-up-right";
        }>>;
        kind: z.ZodLiteral<"link">;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"action">;
        label: z.ZodString;
        id: z.ZodString;
        icon: z.ZodOptional<z.ZodEnum<{
            search: "search";
            close: "close";
            add: "add";
            edit: "edit";
            more: "more";
            settings: "settings";
            attachment: "attachment";
            mention: "mention";
            "arrow-right": "arrow-right";
            pin: "pin";
            "arrow-up-right": "arrow-up-right";
        }>>;
    }, z.core.$strict>], "kind">>;
    media: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"image">;
        src: z.ZodString;
        alt: z.ZodString;
        width: z.ZodNumber;
        height: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"slot">;
        label: z.ZodString;
    }, z.core.$strict>], "kind">>;
}, z.core.$strict>;
export type HeroInput = z.input<typeof heroSchema>;
export declare const heroJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    headingId: z.ZodString;
    heading: z.ZodArray<z.ZodObject<{
        text: z.ZodString;
        emphasis: z.ZodOptional<z.ZodBoolean>;
        breakBefore: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    composition: z.ZodDefault<z.ZodEnum<{
        split: "split";
        centered: "centered";
        "centered-media": "centered-media";
    }>>;
    eyebrow: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    primaryAction: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        label: z.ZodString;
        href: z.ZodUnion<readonly [z.ZodString, z.ZodURL]>;
        icon: z.ZodOptional<z.ZodEnum<{
            search: "search";
            close: "close";
            add: "add";
            edit: "edit";
            more: "more";
            settings: "settings";
            attachment: "attachment";
            mention: "mention";
            "arrow-right": "arrow-right";
            pin: "pin";
            "arrow-up-right": "arrow-up-right";
        }>>;
        kind: z.ZodLiteral<"link">;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"action">;
        label: z.ZodString;
        id: z.ZodString;
        icon: z.ZodOptional<z.ZodEnum<{
            search: "search";
            close: "close";
            add: "add";
            edit: "edit";
            more: "more";
            settings: "settings";
            attachment: "attachment";
            mention: "mention";
            "arrow-right": "arrow-right";
            pin: "pin";
            "arrow-up-right": "arrow-up-right";
        }>>;
    }, z.core.$strict>], "kind">>;
    secondaryAction: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        label: z.ZodString;
        href: z.ZodUnion<readonly [z.ZodString, z.ZodURL]>;
        icon: z.ZodOptional<z.ZodEnum<{
            search: "search";
            close: "close";
            add: "add";
            edit: "edit";
            more: "more";
            settings: "settings";
            attachment: "attachment";
            mention: "mention";
            "arrow-right": "arrow-right";
            pin: "pin";
            "arrow-up-right": "arrow-up-right";
        }>>;
        kind: z.ZodLiteral<"link">;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"action">;
        label: z.ZodString;
        id: z.ZodString;
        icon: z.ZodOptional<z.ZodEnum<{
            search: "search";
            close: "close";
            add: "add";
            edit: "edit";
            more: "more";
            settings: "settings";
            attachment: "attachment";
            mention: "mention";
            "arrow-right": "arrow-right";
            pin: "pin";
            "arrow-up-right": "arrow-up-right";
        }>>;
    }, z.core.$strict>], "kind">>;
    media: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"image">;
        src: z.ZodString;
        alt: z.ZodString;
        width: z.ZodNumber;
        height: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"slot">;
        label: z.ZodString;
    }, z.core.$strict>], "kind">>;
}, z.core.$strict>>;
