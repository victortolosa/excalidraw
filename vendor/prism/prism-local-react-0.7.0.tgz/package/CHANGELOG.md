# @prism-local/react

## 0.7.0

### Minor Changes

- Support star favorites in Toggle with stable accessible names and keyboard/state/theme coverage. Remove color transitions from Button, SearchField, TextField, Select, Tabs and Toggle so theme changes retain contrast. Support React and React DOM ^19.0.0, verified with the Excalidraw app's React 19.0.0 and matching types in the packed consumer.

  Add an icon-only DropdownMenu trigger, a focus-preserving pending Toggle state, controlled SearchField clearing, and destructive Button/Dialog confirmation. Existing defaults remain unchanged. Toast outcomes use existing variants; action/Undo support remains deferred.

  Migration: new props are opt-in. Set DropdownMenu trigger="icon" with a contextual label; own Toggle pending and saved state in the app; provide SearchField onClear with controlled value/onChange; choose Dialog confirmVariant="destructive" for irreversible actions and provide a surviving returnFocusRef when deletion removes the trigger.

## 0.6.0

### Minor Changes

- efd54ec: Add explicit Markdown input/output to RichTextComposer with `format="markdown"`, string value/defaultValue and string onValueChange callbacks. JSON remains the default and existing JSON consumers require no migration. Both formats use the same visual formatting toolbar, selection, Clear/Undo, form reset and editor history. The ref adds getMarkdown(); getDocument() remains JSON in both modes. Hidden form values use the selected format.

  Markdown supports the existing toolbar subset: headings 1–3, bold, italic, lists, hard breaks and safe links. Unsupported syntax is rejected, and serialization normalizes whitespace and delimiter choices. This does not preserve raw Markdown source byte for byte or add image/code/table support. The Markdown parser is pinned to the existing Tiptap editor version.

## 0.5.0

### Minor Changes

- 8448c8b: Add a decorative Badge `indicator` (`dot` or `sync`; the sync icon animates only when motion is allowed) and a React-only Alert `action` slot for one Button or link, rendered below the text.
- 8448c8b: Add Card headingless mode and Section `titleStyle`. Card `title` is now optional in its schema: provide exactly one of `title` or `label` (an accessible name, with no description); existing cards with a title are unchanged, but generated JSON Schemas no longer list `title` as required. Section `titleStyle` is `default` or `label`; `label` uses a new registered typography slot (`section.label-*`), so consumers with their own token files must add it from `tokens/components/section.json`.
- 8448c8b: Add Composer, a multiline panel wrapping the catalog input group with an internal labeled header and React-only headerActions, toolbar, secondaryActions and actions slots. It shares Textarea typography, grows from rows to maxRows, distinguishes submission feedback from validation, and supports optional Clear with persistent Undo.

  Existing value/onChange usage remains supported. Controlled Clear/Undo requires onValueChange for string updates; onChange continues to report native input events only. Read-only hides mutation slots; busy locks editing while leaving host-owned loading actions visible. No image-upload lifecycle is included.

  Add RichTextComposer as a separate entry sharing Composer’s panel. It accepts allowlisted structured JSON and supports bold, italic, lists, link editing, keyboard toolbar navigation and editor history. Plain-text Composer retains its string API and does not import the editor engine. Images remain outside this release scope. Heading levels 1–3 use a split toolbar button: toggle the selected level on/off or choose Paragraph or a heading level from its dropdown. Structured documents preserve heading levels.

  Fix secondary Button contrast inside tinted panels by using solid dark background and hover roles instead of stacking catalog opacity fills.

  Expose the supported ghost Button variant for low-prominence utility actions, and use it for Composer and RichTextComposer Clear/Undo.

  Use the existing container surface roles for both Composer panels instead of a border-derived translucent input fill, reducing dark-mode prominence.

  Soften the shared border token and its input/sidebar-border aliases across all components, including TextField and both Composers. Composer uses one opaque outline color on every edge. Focus and validation tokens are unchanged. The fallback chart-4 color inherits border. Custom themes can retain their existing border values; the default theme updates light, dark and emphasis outline colors.

- 8448c8b: Add Item and ItemGroup for repeated list rows: title, supporting line, status text and a trailing actions slot, with plain and outlined variants. Title, description and status are registered typography slots (`item.title-*`, `item.description-*`, `item.status-*`); consumers with their own token files must add them from `tokens/components/item.json`.
- 8448c8b: Add `labelVisibility` (`visible` or `hidden`) to TextField, Textarea, Select, Combobox and SearchField. A hidden label stays the accessible name and is only removed from view. Hidden combined with `required` is rejected for fields that have `required`. Use it only when visible context already names the field.
- 8448c8b: Add composed Tabs pieces (`TabsRoot`, `TabsList`, `TabsPanel`) so a tab list can sit in a page header while panels render elsewhere in the same root, and a `size` option (`default` or `sm`) that tightens horizontal padding. Existing `Tabs` is unchanged. Add the `arrow-up-right` action icon.

## 0.4.0

### Minor Changes

- Make Toast runtime validation opt-in through a separate validator entry. Ship Tailwind source and component dependency source manifests for app-sized CSS. Emit local font files separately from CSS and use the source workflow in the React starter.
- Make Page header actions wrap according to available space by default, independent of description length. Add inline and stacked action layouts and guidance for choosing icon-only versus text actions. Migration: existing Page headers now use content-driven wrapping instead of forced mobile stacking; set actionsLayout="inline" for compact actions or "stacked" for a dedicated action row at every width.

### Patch Changes

- optimizations

## 0.3.1

### Patch Changes

- fixes

## 0.3.0

### Minor Changes

- Optimized library for composable use

### Patch Changes

- Preserve ES module boundaries so unused components can be removed from consumer bundles. Add typed component and block subpath imports while retaining root imports.
- Separate authoritative rendering defaults and helpers from schema construction so ordinary components do not load Zod. Preserve schema exports, inferred types and runtime validation in ButtonGroup, Toast and SignupForm.

## 0.2.0

### Minor Changes

- Export all 33 completed Prism components and both supported blocks, with React types, portable guidance, schemas and matching consumer discovery.

### Patch Changes

- exporting all components

## 0.1.6

### Patch Changes

- Fixed tab text length behavior. Truncates no longer break lines.

## 0.1.5

### Patch Changes

- Ship release-matched agent discovery, generated consumer rules, audit policy/template, a portable page skill and an executable composition recipe. Add prism-setup to connect existing project instructions and a project skill without replacing user rules or validation. Include experience/platform/viewport selection guidance and validate packaged links, release identity and setup across consumer updates.

## 0.1.4

### Patch Changes

- Preserve the starter's Git ignore rules inside packed releases and restore them during bootstrap. Ignore local update locks/history while keeping vendored releases available to other checkouts.

## 0.1.3

### Patch Changes

- Ship a matching React/Vite starter and pinned toolchain inside the local release. Verify staged consumer updates and rollback, CSS module typing, and settled theme accessibility checks. Keep component implementations and token ownership unchanged.

## 0.1.2

### Patch Changes

- Extend consumer checks for literal visual values, unknown semantic roles and explicit Prism styling overrides. Include release notes for staged consumer updates. Add an independent React/Vite starter and local update/rollback workflow.

## 0.1.1

### Patch Changes

- Add the portable prism-check command to reject direct shadcn dependencies, catalog imports, private Prism subpaths, and recognized local catalog copies in consumer source. The check reports source locations and fails on computed module loading it cannot inspect.
