import themes from './theme-policy.json' with { type: 'json' };
const roles = new Set(Object.keys(themes.required));
const colorPrefixes = 'ring-offset|border-[trblxyse]|bg|text|border|ring|outline|fill|stroke|from|via|to|divide|decoration|caret|accent|placeholder';
// Tailwind keywords and non-color utilities that share the color prefixes.
const notColors = /^([trblxyse]|transparent|current|inherit|white|black|none|xs|sm|base|lg|xl|\dxl|left|right|center|justify|start|end|solid|dashed|dotted|double|hidden|auto|full|px|\d+(\.\d+)?|offset|inset|clip-.+|blend-.+|gradient-to-[trbl]{1,2}|linear-.+|radial(-.+)?|conic(-.+)?|collapse|separate|balance|wrap|pretty|nowrap|ellipsis|clip|transparent)$/;
// Runtime variables set by Radix, Base UI, or shadcn components rather than by the theme.
const runtimeVariables = /^(radix-.+|anchor-width|available-height|available-width|transform-origin|gap|card-spacing|sidebar-width(-icon)?|accordion-panel-height|tw-.+)$/;
const radiusVariables = /^radius(-(sm|md|lg|xl|2xl|3xl|4xl))?$/;
// Component tokens listed in themes.json, as CSS variables: --button-padding-x.
const componentVariables = new Set(Object.entries(themes.components ?? {}).flatMap(([component, tokens]) => Object.keys(tokens).map(name => `${component}-${name}`)));
const componentPrefixes = new RegExp(`^(${Object.keys(themes.components ?? {}).join('|') || '(?!)'})-`);
export function unknownThemeRoles(source) {
    const unknown = new Set();
    for (const [, prefix, name] of source.matchAll(new RegExp(`(?<![\\w\\[-])(?:[\\w\\[\\]=*&/.-]+:)*(${colorPrefixes})-([a-z]+(?:-[a-z]+)*)(?:/\\d+)?(?![\\w-])`, 'g'))) {
        if (!notColors.test(name) && !roles.has(name))
            unknown.add(`${prefix}-${name}`);
    }
    for (const [, name] of source.matchAll(/var\(--([a-z0-9-]+)/g)) {
        if (componentVariables.has(name))
            continue;
        if (!roles.has(name.replace(/^semantic-/, '')) && !radiusVariables.test(name) && !runtimeVariables.test(name))
            unknown.add(`var(--${name})`);
    }
    // Tailwind's shorthand for a variable, px-(--button-padding-x) or text-(length:--button-font-size).
    for (const [, name] of source.matchAll(/-\((?:[a-z-]+:)?--([a-z0-9-]+)\)/g)) {
        if (componentPrefixes.test(name) && !componentVariables.has(name) && !runtimeVariables.test(name))
            unknown.add(`(--${name})`);
    }
    return [...unknown];
}
