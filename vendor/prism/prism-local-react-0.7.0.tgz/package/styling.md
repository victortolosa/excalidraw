## App-sized CSS with Tailwind 4

Use the source entry instead of styles.css when the app builds Tailwind. Install Tailwind 4 and its framework integration. For Vite, enable @tailwindcss/vite and set build.assetsInlineLimit to 0 to retain separate font files.

In a stylesheet under the app's src directory:

```css
@import "@prism-local/react/tailwind.css";
@import "@prism-local/react/sources/button.css";
@import "@prism-local/react/sources/card.css";
@source "./";
```

Import that stylesheet once. Add one source import for each Prism component or block the app uses. Each manifest includes the selected component's internal dependencies, supported variants and states; do not scan the whole package. The @source directive registers the app's own classes. Rebuild after changing selected components. Do not also import the compiled styles.css entry.

The source stylesheet contains the same tokens, base rules and accessibility defaults as the compiled stylesheet. Tailwind generates utilities for selected components and app sources; it does not prune the shared token declarations. Local fonts load separately and can be cached independently.

## Toast input validation

Toast inputs use static TypeScript checks by default. To validate untrusted data or enable development checks, opt in:

```tsx
import { ToastProvider } from '@prism-local/react/toast'
import { validateToast } from '@prism-local/react/toast/validation'

<ToastProvider validateInput={validateToast}>{children}</ToastProvider>
```

The validator preserves the contract's defaults and rejection rules and loads Zod. Import it only where validation is needed. Ordinary Toast imports exclude Zod; ButtonGroup and SignupForm still validate their inputs.

