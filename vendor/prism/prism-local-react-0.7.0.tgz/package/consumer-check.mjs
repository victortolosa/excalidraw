#!/usr/bin/env node
import { readFileSync, readdirSync, existsSync, realpathSync } from 'node:fs'
import { resolve, relative, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createHash } from 'node:crypto'
import ts from 'typescript'

export function catalogFingerprint(text) {
  const source = ts.createSourceFile('catalog.tsx', text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX)
  return createHash('sha256').update(ts.createPrinter({ removeComments: true }).printFile(source)).digest('hex')
}
const catalogPath = path => /(?:^|\/)components\/ui(?:\/|$)/.test(path.replaceAll('\\', '/'))
const blockedPackage = name => name === 'shadcn' || name === '@shadcn/react' || name.startsWith('@shadcn/')
const packageName = name => name.startsWith('@') ? name.split('/').slice(0, 2).join('/') : name.split('/')[0]

export function checkConsumer({ root, sources, policy, packageDirectory, styleRules }) {
  root = realpathSync(root)
  const diagnostics = []
  const report = (file, line, column, code, message) => diagnostics.push({ file: relative(root, file), line, column, code, message })
  const manifestFile = resolve(root, 'package.json')
  const manifest = JSON.parse(readFileSync(manifestFile, 'utf8'))
  const dependencies = { ...manifest.dependencies, ...manifest.devDependencies, ...manifest.peerDependencies, ...manifest.optionalDependencies }
  const aliases = new Set()
  for (const [name, value] of Object.entries(dependencies)) {
    if (blockedPackage(name) || (typeof value === 'string' && /^npm:(?:shadcn(?:@|$)|@shadcn\/)/.test(value))) {
      aliases.add(name)
      report(manifestFile, 1, 1, 'catalog-dependency', `Direct dependency ${name} bypasses Prism. Remove it and use supported Prism exports.`)
    }
  }
  if (!dependencies[policy.packageName]) report(manifestFile, 1, 1, 'missing-prism', `Declare ${policy.packageName} as a consumer dependency.`)
  const release = JSON.parse(readFileSync(resolve(packageDirectory, 'release.json'), 'utf8'))
  const installed = JSON.parse(readFileSync(resolve(packageDirectory, 'package.json'), 'utf8'))
  if (release.version !== installed.version || policy.version !== release.version || policy.sourceDigest !== release.sourceDigest) {
    report(manifestFile, 1, 1, 'release-mismatch', 'Installed Prism implementation, release metadata and consumer policy must match.')
  }
  const configPath = ts.findConfigFile(root, ts.sys.fileExists)
  let options = { allowJs: true, moduleResolution: ts.ModuleResolutionKind.Bundler, module: ts.ModuleKind.ESNext }
  if (configPath) {
    const config = ts.readConfigFile(configPath, ts.sys.readFile)
    if (config.error) throw new Error(ts.flattenDiagnosticMessageText(config.error.messageText, '\n'))
    const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, dirname(configPath))
    if (parsed.errors.length) throw new Error(parsed.errors.map(e => ts.flattenDiagnosticMessageText(e.messageText, '\n')).join('\n'))
    options = { ...options, ...parsed.options }
  }
  const files = new Set()
  const walk = path => {
    const real = realpathSync(path)
    if (relative(root, real).startsWith('..')) throw new Error(`Consumer source escapes project root: ${path}`)
    if (real.includes('/node_modules/')) return
    const entries = readdirSync(real, { withFileTypes: true })
    for (const entry of entries) {
      if (['node_modules', '.git', 'dist', 'generated', '.next'].includes(entry.name)) continue
      const child = resolve(real, entry.name)
      if (entry.isSymbolicLink()) throw new Error(`Source symlink requires explicit review: ${child}`)
      if (entry.isDirectory()) walk(child)
      else if (/\.(?:[cm]?[jt]sx?|css)$/.test(child) && !child.endsWith('.d.ts')) files.add(child)
    }
  }
  const roots = sources ?? ['src', 'app', 'pages', 'components'].filter(path => existsSync(resolve(root, path)))
  if (!roots.length) throw new Error('No consumer source roots found. Pass --source <directory>.')
  for (const source of roots) walk(resolve(root, source))
  if (!files.size) throw new Error('No JavaScript or TypeScript files found in selected consumer roots.')
  const uiAlias = existsSync(resolve(root, 'components.json')) ? JSON.parse(readFileSync(resolve(root, 'components.json'), 'utf8')).aliases?.ui : undefined
  // Follow resolved local modules too, so a barrel outside a selected source root cannot hide catalog usage.
  for (const file of files) {
    if (catalogPath(file)) report(file, 1, 1, 'catalog-source', 'Local components/ui implementations are outside the Prism production library.')
    const text = readFileSync(file, 'utf8')
    if (styleRules && file.endsWith('.css')) {
      // Import/source filenames are paths, not utility classes or token roles.
      const clean = text.replace(/\/\*[\s\S]*?\*\//g, '').replace(/@(?:import|source)\s+(?:"[^"]*"|'[^']*')/g, '')
      for (const [name, pattern] of styleRules.forbiddenVisualValues) if (pattern.test(clean)) report(file, 1, 1, 'raw-visual-value', `CSS contains ${name}. Use semantic roles.`)
      for (const value of styleRules.unknownThemeRoles(clean)) report(file, 1, 1, 'unknown-role', `Unknown token role ${value}.`)
      if (/\[data-(?:component|typography)\b/.test(clean) || /(?:^|[{}])[^{}]*(?:\bbutton|\binput|\bselect|\btextarea)\b[^{}]*\{/.test(clean)) report(file, 1, 1, 'component-override', 'CSS targets shared component anatomy. Compose layout around components instead.')
      for (const match of clean.matchAll(/(?:^|[;{])\s*(color|background-color|border-color|font-family|border-radius)\s*:\s*([^;}]+)/g)) {
        if (!/^(?:var\(--|inherit\b|currentColor\b|transparent\b|none\b)/.test(match[2].trim())) report(file,1,1,'raw-visual-value',`CSS ${match[1]} must use a semantic token.`)
      }
      continue
    }
    if (policy.catalogFingerprints.includes(catalogFingerprint(text))) report(file, 1, 1, 'catalog-copy', 'This source matches a vendored catalog implementation, including under a renamed path.')
    const ast = ts.createSourceFile(file, text, ts.ScriptTarget.Latest, true)
    const add = (node, code, message) => {
      const { line, character } = ast.getLineAndCharacterOfPosition(node.getStart(ast))
      report(file, line + 1, character + 1, code, message)
    }
    for (const error of ast.parseDiagnostics) add(ast, 'parse-error', ts.flattenDiagnosticMessageText(error.messageText, '\n'))
    const inspect = (node, literal) => {
      if (!literal || !ts.isStringLiteralLike(literal)) { add(node, 'dynamic-module', 'Computed module loading cannot be verified; use a literal module path.'); return }
      const specifier = literal.text
      const name = packageName(specifier)
      if (blockedPackage(name) || aliases.has(name) || catalogPath(specifier) || (uiAlias && (specifier === uiAlias || specifier.startsWith(`${uiAlias}/`)))) {
        add(node, 'catalog-import', `Unsupported catalog import ${specifier}; use a supported Prism export.`)
      }
      if (specifier.startsWith(`${policy.packageName}/`) && !policy.publicSubpaths.includes(specifier.slice(policy.packageName.length))) {
        add(node, 'private-import', `Unsupported Prism subpath ${specifier}.`)
      }
      const resolved = ts.resolveModuleName(specifier, file, options, ts.sys).resolvedModule?.resolvedFileName
      if (resolved && !resolved.includes('/node_modules/') && !resolved.endsWith('.d.ts')) {
        const real = realpathSync(resolved)
        if (relative(root, real).startsWith('..')) add(node, 'external-source', 'Local imports outside the consumer root cannot be verified.')
        else files.add(real)
      }
    }
    const bindings = new Set(); const namespaces = new Set()
    for (const statement of ast.statements) {
      if (ts.isImportDeclaration(statement) && statement.moduleSpecifier.text === policy.packageName) {
        const binding = statement.importClause?.namedBindings
        if (binding && ts.isNamedImports(binding)) for (const element of binding.elements) if (policy.componentExports?.includes((element.propertyName ?? element.name).text)) bindings.add(element.name.text)
        if (binding && ts.isNamespaceImport(binding)) namespaces.add(binding.name.text)
      }
    }
    const values = new Map()
    const collect = node => { if (ts.isVariableDeclaration(node) && ts.isIdentifier(node.name) && node.initializer) values.set(node.name.text,node.initializer); ts.forEachChild(node,collect) }
    collect(ast)
    const strings = (node, seen = new Set()) => {
      if (ts.isStringLiteralLike(node)) return [node.text]
      if (ts.isIdentifier(node) && values.has(node.text) && !seen.has(node.text)) return strings(values.get(node.text),new Set([...seen,node.text]))
      const result = []; ts.forEachChild(node, child => result.push(...strings(child,seen))); return result
    }
    const validateVisual = (node, text) => {
      for (const [name, pattern] of styleRules.forbiddenVisualValues) if (pattern.test(text)) add(node,'raw-visual-value',`Unsupported ${name}; use semantic roles.`)
      for (const role of styleRules.unknownThemeRoles(text)) add(node,'unknown-role',`Unknown token role ${role}.`)
    }
    const visit = node => {
      if ((ts.isImportDeclaration(node) || ts.isExportDeclaration(node)) && node.moduleSpecifier) inspect(node, node.moduleSpecifier)
      else if (ts.isImportEqualsDeclaration(node) && ts.isExternalModuleReference(node.moduleReference)) inspect(node, node.moduleReference.expression)
      else if (ts.isCallExpression(node) && (node.expression.kind === ts.SyntaxKind.ImportKeyword || (ts.isIdentifier(node.expression) && node.expression.text === 'require'))) inspect(node, node.arguments[0])
      if (styleRules && ts.isJsxAttribute(node) && ['className','style','fill','stroke','color'].includes(node.name.getText(ast)) && node.initializer) {
        const text = strings(node.initializer).join(' ')
        validateVisual(node,text)
        if (!text && node.name.getText(ast) === 'className') add(node,'unverified-style','Computed styling cannot be verified; use explicit layout/role classes.')
        if (node.name.getText(ast) === 'style' && ts.isJsxExpression(node.initializer) && node.initializer.expression && ts.isObjectLiteralExpression(node.initializer.expression)) {
          for (const property of node.initializer.expression.properties) {
            if (ts.isPropertyAssignment(property) && /^(?:color|backgroundColor|borderColor|fontFamily|borderRadius)$/.test(property.name.getText(ast)) && !/^var\(--/.test(strings(property.initializer).join(' '))) add(property,'raw-visual-value','Visual style values must use semantic tokens.')
          }
        }
      }
      if (styleRules && (ts.isJsxOpeningElement(node) || ts.isJsxSelfClosingElement(node))) {
        const tag = node.tagName.getText(ast)
        const shared = bindings.has(tag) || (namespaces.has(tag.split('.')[0]) && policy.componentExports?.includes(tag.split('.')[1]))
        for (const prop of node.attributes.properties) {
          if (shared && ts.isJsxAttribute(prop) && ['className','style'].includes(prop.name.getText(ast))) add(prop,'component-override','Prism components cannot receive className/style overrides.')
          if (shared && ts.isJsxSpreadAttribute(prop)) {
            const expression = ts.isIdentifier(prop.expression) ? values.get(prop.expression.text) : prop.expression
            if (!expression || !ts.isObjectLiteralExpression(expression)) add(prop,'unverified-props','Computed Prism prop spreads require review; use explicit props.')
            else for (const value of expression.properties) if (!value.name || ts.isComputedPropertyName(value.name) || ['className','style'].includes(value.name.getText(ast).replace(/["']/g,''))) add(prop,'component-override','Prism prop spread includes styling or cannot be verified.')
          }
        }
      }
      ts.forEachChild(node, visit)
    }
    visit(ast)
  }
  return { diagnostics, filesChecked: files.size, version: release.version }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === realpathSync(resolve(process.argv[1]))) {
  try {
    let root = process.cwd(); const sources = []
    for (let i = 2; i < process.argv.length; i++) {
      const flag = process.argv[i]
      if (!['--root', '--source'].includes(flag) || !process.argv[i + 1]) throw new Error('Usage: prism-check [--root <project>] [--source <directory>]')
      const value = process.argv[++i]
      if (flag === '--root') root = resolve(value); else sources.push(value)
    }
    const packageDirectory = dirname(fileURLToPath(import.meta.url))
    const policy = JSON.parse(readFileSync(resolve(packageDirectory, 'consumer-policy.json'), 'utf8'))
    const styleRules = { ...(await import('./theme-usage.mjs')), ...(await import('./visual-rules.mjs')) }
    const result = checkConsumer({ root, sources: sources.length ? sources : undefined, policy, packageDirectory, styleRules })
    for (const d of result.diagnostics) console.error(`${d.file}:${d.line}:${d.column} [${d.code}] ${d.message}`)
    if (result.diagnostics.length) process.exitCode = 1
    else console.log(`Prism ${result.version}: static conformance checks passed (${result.filesChecked} source files). Run TypeScript and app checks separately.`)
  } catch (error) { console.error(`Prism check failed: ${error.message}`); process.exitCode = 1 }
}
