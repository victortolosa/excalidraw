import assert from 'node:assert/strict'
import { readFileSync, mkdirSync } from 'node:fs'
import { createServer } from 'vite'
import { chromium } from 'playwright'
const server = await createServer({ server: { host: '127.0.0.1', port: 0 } })
let browser
try {
  await server.listen(); browser = await chromium.launch({ headless: true })
  const page = await browser.newPage({ viewport: { width: 320, height: 900 } })
  const errors = []; page.on('pageerror', error => errors.push(error.message))
  page.setDefaultTimeout(10000)
  await page.goto(`${server.resolvedUrls.local[0]}?failOnce`)
  const name = page.getByLabel('Display name', { exact: false })
  const email = page.getByLabel('Email address', { exact: false })
  const save = page.getByRole('button', { name: 'Save changes', exact: true })
  await name.fill(''); await email.fill('bad'); await save.click()
  assert.equal(await name.evaluate(el => el === document.activeElement), true)
  assert.equal(await name.getAttribute('aria-invalid'), 'true')
  await name.fill('Ada Lovelace'); await save.click()
  assert.equal(await email.evaluate(el => el === document.activeElement), true)
  await name.fill('Ada Lovelace'); await email.fill('ada@example.com'); await save.click()
  await page.getByRole('status').filter({hasText:'Saving your profile'}).waitFor()
  assert.equal(await name.getAttribute('readonly'), '')
  await page.getByRole('button', {name:'Saving…',exact:true}).evaluate(el => {el.click(); el.click()})
  await page.getByRole('alert').waitFor()
  assert.equal(await name.inputValue(), 'Ada Lovelace')
  await save.click(); await page.getByRole('status').filter({hasText:'Your profile has been saved'}).waitFor()
  const toggle = page.getByRole('switch', {name:'Product updates'})
  await toggle.click(); assert.equal(await toggle.getAttribute('aria-checked'), 'false')
  await toggle.focus(); await page.keyboard.press('Space'); assert.equal(await toggle.getAttribute('aria-checked'), 'true')
  const themes = JSON.parse(readFileSync('node_modules/@prism-local/react/context/resolved-themes.json','utf8'))
  const axe = readFileSync('node_modules/axe-core/axe.min.js','utf8')
  // The matrix uses the installed release vocabulary, not an independently maintained list.
  for (const context of themes.themes) {
    const {mode,surface:scheme} = context
    const key = `${mode}/${scheme}`
    await page.evaluate(({mode,scheme})=>{document.documentElement.dataset.mode=mode;document.documentElement.dataset.scheme=scheme}, {mode,scheme})
    await page.waitForFunction(() => document.getAnimations().every(animation => animation.playState !== 'running'))
    await page.addScriptTag({content:axe})
    const violations = await page.evaluate(async()=> (await window.axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21a','wcag21aa']}})).violations)
    assert.deepEqual(violations.map(v=>v.id), [], key)
    assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth <= innerWidth), true, key)
  }
  const config = JSON.parse(readFileSync('node_modules/@prism-local/react/types/tokens/themes.json','utf8'))
  for (const density of config.densities) {
    await page.evaluate(value => {document.documentElement.dataset.density = value}, density)
    assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth <= innerWidth), true, density)
  }
  await name.fill('A very long display name that remains editable and scrolls naturally within the input')
  await page.emulateMedia({reducedMotion:'reduce'})
  assert.equal(await page.evaluate(()=>matchMedia('(prefers-reduced-motion: reduce)').matches), true)
  const evidence = process.env.PRISM_EVIDENCE_DIR
  if (evidence) mkdirSync(evidence,{recursive:true})
  for (const width of [320,768,1280]) {
    await page.setViewportSize({width,height:900})
    assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth <= innerWidth), true, `viewport ${width}`)
    if (evidence && width !== 768) await page.screenshot({path:`${evidence}/account-settings-${width}.png`,fullPage:true})
  }
  await page.setViewportSize({width:1280,height:900})
  assert.equal(await page.getByRole('main').count(),1)
  assert.equal(await page.getByRole('heading',{level:1}).count(),1)
  assert.deepEqual(errors, [])
  console.log('Account-settings browser behavior and theme accessibility checks passed.')
} finally { await browser?.close(); await server.close() }
