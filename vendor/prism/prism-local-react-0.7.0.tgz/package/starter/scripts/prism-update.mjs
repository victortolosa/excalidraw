import { readFileSync, writeFileSync, existsSync, mkdirSync, mkdtempSync, cpSync, renameSync, rmSync, readdirSync, realpathSync, rmdirSync } from 'node:fs'
import { resolve, dirname, relative, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { x, t } from 'tar'
const packageName = '@prism-local/react'
const sha = bytes => createHash('sha256').update(bytes).digest('hex')

export async function inspectArtifact(artifact) {
  artifact = resolve(artifact)
  const bytes = readFileSync(artifact)
  const checksum = readFileSync(`${artifact}.sha256`, 'utf8').trim().split(/\s+/)[0]
  if (!/^[a-f0-9]{64}$/.test(checksum) || checksum !== sha(bytes)) throw new Error('Release checksum mismatch.')
  const temp = mkdtempSync(join(dirname(artifact), '.inspect-'))
  try {
    const allowed = ['package/package.json', 'package/release.json', 'package/consumer-policy.json', 'package/CHANGELOG.md']
    await x({file:artifact,cwd:temp,strict:true,filter:(path,entry)=>allowed.includes(path) && entry.type === 'File'})
    const pkg = JSON.parse(readFileSync(join(temp,'package/package.json'),'utf8'))
    const release = JSON.parse(readFileSync(join(temp,'package/release.json'),'utf8'))
    const policy = JSON.parse(readFileSync(join(temp,'package/consumer-policy.json'),'utf8'))
    if (pkg.name !== packageName || !/^\d+\.\d+\.\d+(?:-[\w.-]+)?$/.test(pkg.version)) throw new Error('Not a supported Prism artifact.')
    if (pkg.version !== release.version || policy.version !== release.version || policy.sourceDigest !== release.sourceDigest) throw new Error('Inconsistent release metadata.')
    const notes = existsSync(join(temp,'package/CHANGELOG.md')) ? readFileSync(join(temp,'package/CHANGELOG.md'),'utf8') : 'No changelog supplied.'
    let hasStarter = false
    await t({file:artifact,onReadEntry: entry => { if (entry.path === 'package/starter/package.json' && entry.type === 'File') hasStarter = true }})
    return {artifact,bytes,checksum,version:pkg.version,sourceDigest:release.sourceDigest,notes,hasStarter}
  } finally {rmSync(temp,{recursive:true,force:true})}
}
const ignored = new Set(['node_modules','.git','dist','.prism'])
function digest(root) {
  const hash = createHash('sha256')
  const walk = dir => {
    for (const entry of readdirSync(dir,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))) {
      if (ignored.has(entry.name)) continue
      const path = join(dir,entry.name)
      if (entry.isSymbolicLink()) throw new Error(`Source symlink requires explicit handling: ${path}`)
      hash.update(relative(root,path)).update('\0')
      if (entry.isDirectory()) walk(path); else hash.update(readFileSync(path))
    }
  }
  walk(root); return hash.digest('hex')
}
export async function updateConsumer(root, artifact, {offline=false}={}) {
  root = realpathSync(root)
  const selected = await inspectArtifact(artifact)
  const previousManifest = readFileSync(join(root,'package.json'))
  const previousLock = readFileSync(join(root,'package-lock.json'))
  const previous = JSON.parse(previousManifest).dependencies?.[packageName]
  const installed = JSON.parse(readFileSync(join(root,'node_modules/@prism-local/react/release.json'),'utf8'))
  if (!previous?.startsWith('file:vendor/prism/')) throw new Error('Updater requires a vendored Prism dependency; bootstrap with the starter first.')
  if (installed.version === selected.version && installed.sourceDigest !== selected.sourceDigest) throw new Error('Same version has different source contents; release a new version.')
  console.log(`Prism ${installed.version} → ${selected.version}\n${selected.notes}`)
  const originalDigest = digest(root)
  const stage = mkdtempSync(join(dirname(root), '.prism-update-'))
  const filename = `prism-local-react-${selected.version}.tgz`
  const vendorPath = `vendor/prism/${filename}`
  const destination = join(root,vendorPath)
  if (existsSync(destination) && sha(readFileSync(destination)) !== selected.checksum) {rmSync(stage,{recursive:true,force:true});throw new Error('Existing vendored version has different contents.')}
  const lock = join(root,'.prism/update.lock')
  mkdirSync(join(root,'.prism'),{recursive:true})
  try {mkdirSync(lock)} catch {rmSync(stage,{recursive:true,force:true});throw new Error('Another update is active, or a prior interrupted update left .prism/update.lock. Inspect before retrying.')}
  let swapped = false; let hadModules = false; let committed = false
  try {
    cpSync(root,stage,{recursive:true,filter:path=>path === root || !ignored.has(relative(root,path).split('/')[0])})
    mkdirSync(join(stage,'vendor/prism'),{recursive:true})
    writeFileSync(join(stage,vendorPath),selected.bytes)
    writeFileSync(`${join(stage,vendorPath)}.sha256`,`${selected.checksum}  ${filename}\n`)
    const installArgs = ['install','--ignore-scripts','--no-audit','--no-fund','--save-exact',`file:${vendorPath}`]
    if (offline) installArgs.push('--offline')
    execFileSync('npm',installArgs,{cwd:stage,stdio:'inherit'})
    const candidate = JSON.parse(readFileSync(join(stage,'node_modules/@prism-local/react/release.json'),'utf8'))
    if (candidate.version !== selected.version || candidate.sourceDigest !== selected.sourceDigest) throw new Error('Installed artifact identity differs from selection.')
    execFileSync('npm',['run','validate'],{cwd:stage,stdio:'inherit'})
    if (digest(root) !== originalDigest) throw new Error('Consumer source changed during staging. Retry against the current source.')
    // The staged install and lockfile use project-relative vendor paths. Move the verified
    // dependency tree locally; source files, services and screens are never replaced.
    mkdirSync(join(root,'vendor/prism'),{recursive:true})
    writeFileSync(destination,selected.bytes)
    writeFileSync(`${destination}.sha256`,`${selected.checksum}  ${filename}\n`)
    hadModules = existsSync(join(root,'node_modules'))
    if (hadModules) renameSync(join(root,'node_modules'),join(stage,'previous-node_modules'))
    swapped = true
    renameSync(join(stage,'node_modules'),join(root,'node_modules'))
    writeFileSync(join(root,'package.json'),readFileSync(join(stage,'package.json')))
    writeFileSync(join(root,'package-lock.json'),readFileSync(join(stage,'package-lock.json')))
    mkdirSync(join(root,'.prism/history'),{recursive:true})
    writeFileSync(join(root,'.prism/history/latest.json'),JSON.stringify({previousArtifact:previous.slice(5),from:installed.version,to:selected.version},null,2)+'\n')
    committed = true
    console.log(`Verified Prism ${selected.version} installed. Review package.json, package-lock.json and ${vendorPath}.`)
  } catch (error) {
    if (swapped) {
      rmSync(join(root,'node_modules'),{recursive:true,force:true})
      if (hadModules) renameSync(join(stage,'previous-node_modules'),join(root,'node_modules'))
      writeFileSync(join(root,'package.json'),previousManifest)
      writeFileSync(join(root,'package-lock.json'),previousLock)
    }
    throw error
  } finally {
    if (!swapped || committed || existsSync(join(root,'node_modules'))) rmSync(stage,{recursive:true,force:true})
    rmdirSync(lock)
  }
}
if (process.argv[1] && fileURLToPath(import.meta.url) === realpathSync(resolve(process.argv[1]))) {
  try {
    const args = process.argv.slice(2); const root = process.cwd()
    const offline = args.includes('--offline'); const choice = args.filter(arg=>arg !== '--offline')
    if (choice.length !== 1) throw new Error('Usage: npm run prism:update -- <artifact.tgz|--rollback> [--offline]')
    const artifact = choice[0] === '--rollback' ? resolve(root,JSON.parse(readFileSync('.prism/history/latest.json','utf8')).previousArtifact) : resolve(choice[0])
    await updateConsumer(root,artifact,{offline})
  } catch (error) {console.error(`Prism update failed; current source/dependency state retained: ${error.message}`);process.exitCode=1}
}
