# Prism React starter

This is a local account-settings fixture with no backend or persistence. Shared components are imported from the pinned Prism package; local profile behavior lives in src/.

Create an independent project with Prism's `npm run starter:create -- /absolute/destination /absolute/release.tgz`. The command copies this template and vendors the selected release with its checksum. It never overwrites an existing directory.

Run `npm install`, then `npm run prism:setup` to connect release instructions and a project skill while preserving project rules. Install Playwright Chromium if absent with `npx playwright install chromium`, and run `npm run validate`. Start the app with `npm run dev`. Dependencies and vendored release assets are recorded in package.json/package-lock.json. Commit vendor/prism/ so another checkout can install without the Prism repository.

Use `npm run prism:update -- /absolute/new-release.tgz` to stage and validate an update, or `npm run prism:update -- --rollback` for the previous successful release. The updater requires the tarball's matching SHA-256 sidecar, retains local artifacts and leaves source changes untouched. Failed checks preserve the current installation. No Git commits, pushes or registry publication occur.

Mode, scheme and density attributes live on index.html. Theme vocabulary comes from the installed release context. This example builds Prism Tailwind source through @tailwindcss/vite. src/styles.css selects its components and scans local app sources; add a sources/<component>.css import when adding a component. Fonts ship as separate local files, and assetsInlineLimit is zero so production builds preserve separate caching. No remote font service is required.
