import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './styles.css'
import { AccountSettings } from './AccountSettings'
createRoot(document.getElementById('root')!).render(<StrictMode><AccountSettings /></StrictMode>)
