# Prism consumer project

After installing dependencies, run `npm run prism:setup` to connect the installed release instructions and project skill. Read node_modules/@prism-local/react/AGENTS.md before Prism work. The installed rules, inventory and audit workflow are authoritative; retrieve only selected context.

Project services, state, routing and screen code belong here. This starter uses local fixtures with no backend or persistence. Run npm run validate. Use npm run prism:update for explicit release upgrades and its --rollback option for the previous successful release. Re-read installed instructions after an update.
