# Dialog

## When to use

Use for a short, focused task or decision that must be finished or dismissed before returning to the page: confirming a member's removal, inviting a teammate, or editing one setting. The dialog blocks the rest of the page while open.

Source story evidence (not installed): src/components/dialog/dialog.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Not for messages that need no response; use Alert on the page. Not for brief confirmations after an action; use Toast when it is available. Not for long or multi-step forms, or content people need to compare with the page; use a page. Do not open a dialog on page load, or one dialog from another.

## States

Closed and open. While open, focus moves into the dialog and stays there; Escape, the close button, and the cancel action close it and return focus to the trigger. When `onConfirm` returns a promise, the confirm button shows loading and the dialog stays open until it settles. On success it closes. On failure it stays open: set `error` to say what went wrong and what to do, and it is announced.

## Content

The title names the task, often the same words as the trigger and the confirm action, such as "Remove member". The description says what will happen, including anything that cannot be undone. The confirm label is a verb phrase naming the result, never "OK" or "Yes". Use "Close" as the cancel label when there is no confirm action. Long titles and labels wrap; content taller than the screen scrolls inside the dialog.

## Composition
`confirmVariant="destructive"` uses the destructive Button treatment and initially focuses Cancel. Keep explicit consequence text and an action-specific confirm label. Async confirmation and error handling are unchanged. When deletion removes the original trigger, point returnFocusRef at a surviving logical target supplied by the consumer.

Layout belongs to the parent. No className or style props are exposed. Pass a system Button as `trigger`, or control `open` and `onOpenChange` when another component opens it, such as a menu item or a table row action. In the controlled case, pass `returnFocusRef` pointing to the originating control so closing restores keyboard focus. The ref is React-only and stays outside the serializable schema. Body content goes in `children`, for example TextField or Select; keep it to a few fields. The dialog renders at the end of the page, so it uses the page theme and the default surface, whatever section opened it.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/dialog.tsx
Dependencies: alert, button

## Catalog base

Wraps catalog `dialog` (`src/components/ui/dialog.tsx`): Dialog, DialogTrigger, DialogContent with its close button, DialogHeader, DialogTitle, DialogDescription, DialogFooter, and DialogClose. The free-form header and footer are replaced by a fixed structure; footer actions are system Buttons, and errors use the system Alert. Styling overrides, each required by this contract: content taller than the viewport scrolls inside the dialog instead of running off-screen, and long titles wrap with readable line height and leave room for the close button.

## API

API schema: ../schemas/dialog.schema.json

## Tokens

Semantic tokens: border, font-heading, foreground, muted, muted-foreground, popover, popover-foreground

## Themes

Uses the popover roles in the page theme and the default surface. The check below opens the dialog and runs contrast checks in each page theme.

Source story evidence (not installed): src/components/dialog/dialog.stories.tsx#ThemeChecks. See packaged agent recipes for executable examples.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="dialog" />
