# Breadcrumb

## When to use

Use for a nested page's location within a website or resource hierarchy. It is a secondary path, so keep the site's primary navigation in SiteHeader.

Source story evidence (not installed): src/components/breadcrumb/breadcrumb.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Do not use for a one-level site, progress steps, or primary navigation. Use links or a step-specific pattern for those needs.

## States

Ancestor locations are native links. The final location is marked `aria-current="page"` and is not interactive. Keyboard users tab through ancestor links; separators are hidden from assistive technology.

## Content

Use concise, recognizable ancestor labels and a visible current-page label. Provide a stable unique `id` and `href` for each ancestor. Only the last item is current and has no `href`. Long labels wrap; avoid truncating the current location.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/breadcrumb.tsx
Dependencies: none

## Catalog base

Wraps the vendored Breadcrumb, BreadcrumbList, BreadcrumbItem, BreadcrumbLink, BreadcrumbPage, and BreadcrumbSeparator. Ellipsis is omitted because the catalog's decorative ellipsis alone would hide ancestor destinations without giving users a way to reach them. The wrapper keeps native links and adds the system focus ring and wrapping behavior.

## API

API schema: ../schemas/breadcrumb.schema.json

## Tokens

Semantic tokens: foreground, muted-foreground, ring

## Themes

The component inherits the foreground and muted roles from its container; focus uses the ring role. It supports every brand, mode, and scheme without conditional styling.

Source story evidence (not installed): src/components/breadcrumb/breadcrumb.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="breadcrumb" />
