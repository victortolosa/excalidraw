# Accordion

## When to use

Use for optional supporting content or advanced settings under an h2 section. The catalog supplies h3 disclosure headings. renderPanel receives an item ID and returns React content; it is outside the serializable schema.

Source story evidence (not installed): src/components/accordion/accordion.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Do not hide required steps, essential instructions, or form errors. Use Tabs for peer views. Other heading levels, horizontal layout, and custom trigger content are not exposed; record a gap when needed.

## States

Single mode (default) opens at most one panel and can close all panels. Multiple mode allows independent expansion with an array of unique item IDs. An empty string is the closed value. Use defaultValue for initial state, or value with onValueChange for controlled state. In single mode the controlled value must be empty or identify an item; in multiple mode it is an array of unique existing item IDs. Enter/Space toggle; arrow keys and Home/End move through enabled headings. Disabled disclosures cannot be toggled. Panel content unmounts on close, so preserve durable form state in the caller.

## Content

Use meaningful, unique IDs and concise headings. Keep triggers free of nested controls. Long headings and content wrap. The caller owns loading, errors, and content state inside each panel. Cross-item ID and initial-value constraints are checked by Zod, not fully captured in JSON Schema.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/accordion.tsx
Dependencies: none

## Catalog base

Wraps catalog Accordion, Item, Trigger, and Content in single/collapsible mode. The existing catalog heading stays h3. Overrides strengthen focus, wrap long text, add inner padding for focus visibility, and replace the inner measured height with auto height so changing content can grow.

## API

<h3>Single mode</h3>
API schema: ../schemas/accordion.schema.json

<h3>Multiple mode</h3>
API schema: ../schemas/accordion.schema.json

## Tokens

Semantic tokens: foreground, muted-foreground, ring

## Typography

Edit component typography values or aliases in Foundation/Theme editor. Validate and save to apply the source changes.

## Themes

Inherits regional roles. SchemeMatrix renders open content in every configured scheme for the selected brand and mode. The current reduced-motion CSS policy applies to disclosure animations.

Source story evidence (not installed): src/components/accordion/accordion.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

Reference: [upstream behavior and accessibility](https://www.radix-ui.com/primitives/docs/components/accordion).

## Multiple mode

Set type="multiple" and use string arrays for defaultValue or value/onValueChange. Single mode retains its string API and default behavior.

Source story evidence (not installed): src/components/accordion/accordion.stories.tsx#Multiple. See packaged agent recipes for executable examples.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="accordion" />
