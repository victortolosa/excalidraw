# Alert

## When to use

Use for a message about the page, an account, or a task that the reader should notice: a failed payment, a trial ending, a completed setup, planned maintenance. Use `neutral` for general notices, and `info`, `success`, `warning`, or `destructive` only for the status they name.

Source story evidence (not installed): src/components/alert/alert.stories.tsx#Variants. See packaged agent recipes for executable examples.

## When not to use

Not for an error on one field; use the field's `error` prop, which is tied to the input. Not for a short label on an item; use Badge. Not for brief confirmations that need no lasting space; use Toast when it is available. Not for questions that need an answer before continuing; use a dialog.

## States

Alerts are static text and are not focusable. `live` controls announcement. Leave it `off` for alerts present when the page loads. Use `polite` when an alert appears after an action, such as a saved form, and `assertive` only for errors that block the task. Render a live alert after the action, not on page load; for repeated updates, keep one alert mounted and change its text.

## Content

The title says what happened in one short sentence, such as "Payment failed". The description says why it matters and what to do next. The title must carry the meaning without the color or icon. Long words and URLs wrap, and the alert grows in height.

## Composition

Layout belongs to the parent. No className or style props are exposed. Place an alert at the top of the region it is about: the page, a Card, or a form. Show one alert per region, with the most severe first. An alert may carry one action through the React-only `action` slot: a Button or a link that resolves the alert, such as "Add payment method". It sits below the text. Use at most one; offer further choices in a dialog.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/alert.tsx
Dependencies: none

## Catalog base

Wraps catalog `alert` (`src/components/ui/alert.tsx`): Alert, AlertTitle, and AlertDescription. `neutral` maps to the catalog `default` variant and `destructive` to `destructive`. The catalog has no success, warning, or info variant, so those apply the destructive pattern with their own role: role text, with the description at 90%. The token tests check both pairs on card in every theme. Status variants add an icon hidden from assistive technology. AlertAction is not used: it is absolutely positioned and would cover long text on narrow screens, so the `action` slot renders below the text instead. Overrides: the catalog always sets `role="alert"`, which interrupts screen readers even for alerts present on page load, so the role follows `live`; long words and URLs wrap instead of widening the alert.

## API

API schema: ../schemas/alert.schema.json

## Tokens

Semantic tokens: border, card, card-foreground, destructive, info, muted-foreground, success, warning

## Themes

Alerts use the card role and adapt to the containing surface. Status colors come from the theme's status roles. On emphasis surfaces they are near-white, so the title and icon carry the status there.

Source story evidence (not installed): src/components/alert/alert.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="alert" />
