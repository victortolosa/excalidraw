# Separator

## When to use

Use to draw a boundary between related content groups. Use decorative mode when headings or layout already convey the separation; expose separator semantics only when the boundary itself communicates structure.

Source story evidence (not installed): src/components/separator/separator.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Do not use as a resize handle, progress indicator, or substitute for headings. Prefer whitespace when no visible boundary is needed.

## States

Non-interactive and absent from keyboard navigation. Decorative separators have no separator role; semantic vertical separators expose their orientation.

## Content

No content or label is accepted. Layout and spacing belong to the parent. A vertical separator stretches in a flex row with a meaningful content height; it does not invent its own height.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/separator.tsx
Dependencies: none

## Catalog base

Wraps catalog Separator without styling overrides. Radix supplies decorative and semantic behavior.

## API

API schema: ../schemas/separator.schema.json

## Tokens

Semantic tokens: border

## Themes

Uses the border role on the inherited surface. SchemeMatrix and Catalog/Surface checks cover its surrounding theme context; contrast of essential boundaries still depends on token policy and visual review.

Source story evidence (not installed): src/components/separator/separator.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

Reference: [upstream behavior and accessibility](https://www.radix-ui.com/primitives/docs/components/separator).
