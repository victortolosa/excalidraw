# Popover

## When to use
Use for non-modal rich content adjacent to a button, such as annotation details or a short supplementary form.
Source story evidence (not installed): src/components/popover/popover.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use
Use Tooltip for a short hint, Dialog for blocking decisions, and DropdownMenu for action lists. Do not hide essential content exclusively behind a hover interaction.

## States
Closed, open and controlled. Enter/Space activate the trigger. Focus enters content; Escape closes and restores trigger focus. Outside click dismisses and allows the outside target to retain focus.

## Content
Provide a visible title, optional description and React body content. The title names the popup; description is associated when provided.

## Composition
trigger is a single system Button React element (forwarding ref and Radix trigger props); body uses children. Use open/onOpenChange or defaultOpen. side and align are preferred positions, adjusted by Radix collisions. No custom styling or modal mode.

## Implementation origin
Origin: shadcn-wrapper. src/components/ui/popover.tsx
Dependencies: button

## Catalog base
Wraps catalog popover. Contract overrides: Constrain width to viewport minus 2rem, scroll tall content within available height, wrap unbroken text and use a full-strength focus ring. The wrapper supplies semantic heading and accessible title/description associations.

## API
API schema: ../schemas/popover.schema.json

## Tokens
Semantic tokens: popover, popover-foreground, foreground, muted-foreground, ring

## Themes
The portal uses the page brand/mode and default scheme, not the trigger region. ThemeChecks opens content in every page theme.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="popover" />
