# Page

## When to use

Page represents the overall view: one main landmark, one H1, and optional page actions. Section represents a content region; its background and inner content container are separate layout decisions. Use one Page per document or route. Its `id` is the skip-link target for SiteHeader.

Source story evidence (not installed): src/components/page/page.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

A nested region or a card does not need another Page. Use Section for content within the existing main landmark.

## States

Page is structural and has no disabled, invalid, or loading state. Keep its title and landmark present while child content loads or reports an error. The main landmark accepts keyboard focus after the skip link.

## Content

Use a short, unique page title. The description summarizes the view; action controls are React children. The default `actionsLayout="auto"` places them beside the title when they fit and wraps them below when space is insufficient. Description length does not determine wrapping. Choose narrow, standard, or wide from the contract, based on content density.

For a custom Hero header, omit title/description/actions, supply `labelledBy` referencing its single H1, and pass the Hero through the React-only `header` slot. Page retains the main landmark and skip-link target. The caller must render exactly one matching H1; browser stories verify this relationship. Do not hide a duplicate title.

### Responsive header actions

Use `actionsLayout="inline"` for a compact action such as `<IconButton icon="settings" label="Settings" />`. It reserves an action column beside the title while long headings wrap. Keep this mode for compact actions; larger text groups belong in auto or stacked mode.

Use `actionsLayout="stacked"` to keep actions below the heading and description at every width. Auto responds to the available header width, including narrow containers on desktop, rather than a viewport breakpoint. Action groups can wrap internally. Preserve DOM order: title, description, actions, content.

Keep section-specific actions with their section. For Capture, Settings belongs in Page actions; “Change destination” belongs beside the destination information. Use visible text when an edit icon would leave the action ambiguous. See Button and IconButton guidance.

Source story evidence (not installed): src/components/page/page.stories.tsx#CompactActions. See packaged agent recipes for executable examples.
Source story evidence (not installed): src/components/page/page.stories.tsx#ResponsiveActions. See packaged agent recipes for executable examples.

## Best practices

### Separate the page from its regions

| Construct | Use it for |
| --- | --- |
| Page | The overall view, main landmark, page heading and skip-link target |
| Section | A coherent content region, its heading and optional regional background |
| Content container | Content width, horizontal alignment and gutters |
| Inner surface | An optional painted area with its own theme context |
| Card | A distinct content group using supported shadcn-backed card anatomy |

Content containers and inner surfaces are currently internal Section structure, not exported components. Use native layout elements for grids and columns rather than adding Pages or Cards for layout alone.

### Choose bounds from the content

Use contained content for settings, forms and application views that share one readable content boundary. Keep focused forms narrow; give tables and dense overviews more room. A wider container does not require wider paragraphs: keep long prose at a readable measure.

Use full-width sections when regional backgrounds need to reach the available page edges. Set each Section's `contentWidth` explicitly so its heading, actions and children retain gutters. Match the Page header width and section content widths for a consistent alignment; choose a narrower section container only when its content benefits from it.

In the current API, contained Page `width` bounds the main content; with `layout="full-bleed"`, it bounds only the header. See Current API terminology below. Full-width sections fill their parent and do not escape a constrained application shell.

### Give backgrounds a purpose

Let ordinary sections inherit their theme. Use `scheme` to distinguish a meaningful region, such as a finder or an itinerary, rather than alternating colors mechanically.

Keep the content container transparent unless the content needs a separate surface. Use Section `contentScheme` for a flat inner surface and a complete theme reset. Use Card when the group needs card anatomy; its existing `scheme` can reset the Card context independently. Avoid redundant surfaces, borders and padding around every content group.

Use configured schemes and semantic roles so foregrounds, controls and focus rings follow the background. Never override shadcn component colors to compensate for a regional scheme. Overlays use the page theme and default scheme, so verify dialogs and menus opened from emphasis regions too.

### Preserve structure and navigation

Keep SiteHeader and SiteFooter outside Page. Match SiteHeader `mainId` to Page `id`, and verify that the skip link focuses the main landmark. Render one H1: use the default Page title or a custom header with a matching `labelledBy`, never both.

Use Section h2 headings under the page H1 and h3 headings for subordinate groups. Name meaningful regions; use untitled groups for purely visual structure. Heading levels describe hierarchy, not text size. These practices follow the [W3C page-region guidance](https://www.w3.org/WAI/tutorials/page-structure/regions/).

Keep DOM reading order meaningful when columns stack. Use native links for destinations and buttons for actions. Preserve the supported anatomy and nesting of composed controls, consistent with [shadcn composition guidance](https://ui.shadcn.com/docs/changelog/2026-04-component-composition).

### Check the composed page

Review long headings, translated-length copy, empty and error states, and wrapped actions at 320px and desktop widths. Avoid fixed content heights, horizontal overflow and containers that clip focus rings. Check all supported brands and modes, plus nested schemes and keyboard navigation. A passing build does not establish visual quality.

Verify section backgrounds reach the intended edges while text and controls remain inside their content bounds. Review the complete page for consistent alignment, spacing, hierarchy and unnecessary nesting.

## Implementation origin

Origin: system-authored. No catalog component owns a page main landmark, h1, bounded widths, and page-level actions.
Dependencies: none

## API

API schema: ../schemas/page.schema.json

## Tokens

Semantic tokens: font-heading, foreground, muted-foreground, space-panel, space-section-compact-mobile, space-section-compact-desktop, space-section-standard-mobile, space-section-standard-desktop, space-section-spacious-mobile, space-section-spacious-desktop, space-stack, space-tight, space-section, ring

## Themes

Width and spacing use semantic roles. Brand, mode, and scheme colors inherit from the active theme; Page does not paint a scheme unless its optional `scheme` prop sets one. Its title and actions wrap at 320px.

Source story evidence (not installed): src/components/page/page.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Full-width sections

The full-width sections example demonstrates Section backgrounds reaching the Page edges. The existing API calls this `layout="full-bleed"`; full bleed describes the section background, not another kind of page landmark.

Set `layout="full-bleed"` to let the main landmark span its parent. `width` still bounds and centers the default or custom header, with panel gutters. Children are stacked without page-level gaps so adjacent section backgrounds meet. Give each Section `contentWidth` to bound its content and provide gutters; an unbounded Section remains the caller's explicit choice. Full bleed reaches the parent edges, not past a constrained application shell.

The default `layout="contained"` preserves existing main width, padding, and section gaps. Do not use viewport-width breakouts or add another main landmark.

Source story evidence (not installed): src/components/page/page.stories.tsx#FullBleed. See packaged agent recipes for executable examples.

### Current API terminology

In contained mode, Page `width` bounds the entire main content. In full-width sections mode, it bounds only the page header; each Section `contentWidth` bounds its own content container. This difference remains in the current API and should be corrected in a separate structural change. A content container is currently internal layout, not an exported component.

## Section rhythm

Set `Page sectionSpacing` to `compact`, `standard`, or `spacious` to control outer vertical section padding independently of control density. Sections inherit through layout wrappers; a Section can override with its own `sectionSpacing`. Nested Sections retain legacy spacing unless explicitly configured. Omit the Page setting to preserve existing layouts.

Explicit Page rhythm removes the content stack gap in both layouts; adjacent sections supply their own padding, inside their backgrounds. Horizontal gutters, inner surface padding, heading gaps, and control sizes remain unchanged. The Page header retains its existing spacing. Use this setting for pages composed of Sections; wrap other page content in a Section when it needs the same rhythm.

Shared padding per edge at the default root size: compact 16px mobile / 24px desktop, standard 24px / 48px, spacious 40px / 80px. Desktop starts at 48rem. These are semantic rem tokens and may be themed; density does not scale them.

### Choose and compare presets

Use compact for task-focused layouts, standard for general content, or spacious for a more open visual direction. Content grouping determines the choice. See Page layout (repository reference; not installed) for a complete example and spacing ownership. A Section-only override leaves any legacy parent Page gap intact.

Source story evidence (not installed): src/components/page/page.stories.tsx#CompactSections. See packaged agent recipes for executable examples.
Source story evidence (not installed): src/components/page/page.stories.tsx#StandardSections. See packaged agent recipes for executable examples.
Source story evidence (not installed): src/components/page/page.stories.tsx#SpaciousSections. See packaged agent recipes for executable examples.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="page" />
