# Tabs

## When to use

Use to switch between related views of the same subject in one place, where only one view is needed at a time: a dashboard's overview, activity, and usage. Every tab's panel has content.

Source story evidence (not installed): src/components/tabs/tabs.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Not for navigation between pages or routes; use links, which keep URLs and history. Not for steps in a sequence; use a form with clear next and back actions. Not for a choice that changes data; use RadioGroup or Select. Not when readers need to compare the panels side by side; show them together.

## States

One tab is always selected. Without `defaultValue` or `value`, the first enabled tab is selected. Disabled tabs stay visible but cannot be selected and are skipped by arrow keys; explain elsewhere why they are unavailable. Keyboard: Tab reaches the selected tab, arrow keys, Home, and End move between tabs and select them, and Tab again moves into the panel.

## Content

Tab labels are one or two words, in sentence case, and name the panel's content. Use two to five tabs. Long labels wrap by default, and the tab row grows in height instead of scrolling. Set `truncate` to keep each label on one line with an ellipsis instead; use it only when labels stay recognizable when shortened, because truncated text is cut off visually. The `label` names the set of tabs for screen readers, such as "Dashboard views".

## Composition

Layout belongs to the parent. No className or style props are exposed. `renderPanel(value)` returns the content of each panel; only the selected panel is rendered. For controlled state, pass `value` and `onValueChange`; otherwise use `defaultValue`. Do not nest Tabs inside a tab panel.

When the list belongs in one place and the panels in another, such as a list in a page header and panels in the page body, compose the pieces: `TabsRoot` owns the selected tab (`defaultValue`, or `value` with `onValueChange`), `TabsList` renders the tabs, and each tab has one `TabsPanel` with the same `value`. Both must sit inside the same `TabsRoot`. The tab-to-panel wiring and arrow-key behavior are the same as `Tabs`. `size="sm"` tightens horizontal padding for a list in a header; it keeps a target height of at least 24px.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/tabs.tsx
Dependencies: none

## Catalog base

Wraps catalog `tabs` (`src/components/ui/tabs.tsx`): Tabs, TabsList, TabsTrigger, and TabsContent, in the default list style and horizontal orientation. The line variant and vertical orientation are not exposed. Styling overrides, each required by this contract: labels wrap (or truncate with an ellipsis when `truncate` is set) and the tab row fits its container, so tabs do not overflow at 320px; focus uses the full-strength ring role; and panels, which are focusable in the tabs pattern, show a focus ring instead of none.

## API

API schema: ../schemas/tabs.schema.json

TabsList takes the same `label`, `tabs`, `truncate` and `size`, without `defaultValue`.

API schema: ../schemas/tabs.schema.json

## Tokens

Semantic tokens: background, foreground, input, muted, muted-foreground, ring

## Themes

The tab row uses the muted roles and the selected tab the background role; they adapt to the containing surface.

Source story evidence (not installed): src/components/tabs/tabs.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="tabs" />
