# SearchField

## When to use

Use for a query that searches or filters application content. The application owns filtering, submission, results, and feedback. A decorative search icon communicates purpose without replacing the visible label.

Source story evidence (not installed): src/components/search-field/search-field.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Use TextField for ordinary text or email entry, Combobox for searchable option selection. This is not autocomplete or a global command palette. Arbitrary addons, embedded buttons, loading indicators, and hidden labels are outside the contract.

## States

Default, disabled, readOnly, invalid, and focus are supported. Disabled removes the field from tab order; readOnly preserves focus. Error text is associated with the input while description persists. Value and change handlers are React-only; controlled values require onChange. Native search-clearing behavior varies by browser. No custom clear button is provided.

Source story evidence (not installed): src/components/search-field/search-field.stories.tsx#Invalid. See packaged agent recipes for executable examples.

## Content
For controlled inputs, supply React-only `onClear` to show a trailing clear action for nonempty values. The callback clears consumer state; the action returns focus to the native search input. It is absent for empty, disabled and read-only fields. Filtering, debounce and cancellation remain consumer-owned.

A label is always rendered and is always the accessible name. `labelVisibility="hidden"` removes it from view but keeps it as the accessible name, for a field that visible context already names. Hide a label only when that context sits right next to the field and the accessibility profile allows contextual labels.

Use a visible label describing what is searched. Placeholder is optional and never substitutes for the label. Labels and guidance wrap; the single-line query scrolls natively. Keyboard typing and submission use native input/form behavior; do not intercept Escape or Enter without an application requirement.

## Catalog base

Wraps the locked shadcn Input Group, Input, and Field. Input precedes the addon in DOM order; the addon is decorative. Wrapper overrides keep input text on foreground and use a full-strength ring on keyboard focus, including invalid state. No new tokens or brand conditionals are added.

Origin: shadcn-wrapper. src/components/ui/input-group.tsx, src/components/ui/field.tsx, src/components/ui/input.tsx
Dependencies: icon-button

## API

API schema: ../schemas/search-field.schema.json

## Tokens

Semantic tokens: foreground, input, ring, destructive, muted-foreground

## Themes

The field inherits brand, mode, density, and regional scheme. Use a parent for width and placement; className and style are not exposed.

Source story evidence (not installed): src/components/search-field/search-field.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="search-field" />
