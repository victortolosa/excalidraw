# Textarea

## When to use

Use for multiline text inputs such as comments, descriptions, notes, and addresses. Every input has a visible label.

Source story evidence (not installed): src/components/textarea/textarea.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Not for single-line inputs (use TextField), passwords, rich text formatting, or file uploads.

## States

Disabled removes the input from tab order; readOnly preserves focus and copying. Error text marks the input invalid and keeps guidance visible.

## Content

A label is always rendered and is always the accessible name. By default it is visible. `labelVisibility="hidden"` removes it from view but keeps it as the accessible name, for a field that visible context already names, such as the single composer under a "Note" heading. Hide a label only when that context sits right next to the field and the accessibility profile allows contextual labels. A hidden label cannot be combined with `required`, because the required marker would be hidden too. Keep the placeholder as a hint, not as the name.

Use concise labels and persistent instructions. Long prose wraps. Text areas allow multiline entry and expand according to rows or content size.

## Composition

Layout belongs to the parent. No className or style props are exposed. Values, refs, IDs, autocomplete, placeholder, form association, and event handlers are React-only. Controlled values require onChange; do not mix value and defaultValue.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/field.tsx, src/components/ui/textarea.tsx
Dependencies: none

## Catalog base

Wraps catalog Textarea and Field (FieldLabel, FieldDescription, FieldError). The wrapper associates labels, guidance, and errors. Input values use foreground because inherited destructive text fails contrast on tinted emphasis inputs. Its focus override uses the full-strength checked ring, including invalid fields. Wrapping classes prevent long guidance from overflowing.

## API

API schema: ../schemas/textarea.schema.json

## Tokens

Semantic tokens: destructive, foreground, input, muted-foreground, ring

## Themes

Inherits the containing scheme; never accepts a scheme prop. No brand branches are used.

Source story evidence (not installed): src/components/textarea/textarea.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="textarea" />
