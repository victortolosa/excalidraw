# Section

## When to use

Section represents a coherent content region within a Page with an optional heading, description, and actions. Named sections use a native section landmark; untitled visual groups use a div to avoid empty landmarks.

Source story evidence (not installed): src/components/section/section.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Do not use Section for every small card or row. Use the appropriate content component inside Page instead.

## States

Section has no disabled, invalid, or loading state. Child controls own those states. Named sections expose their heading as the accessible landmark name.

## Content

Prefer a concise heading and a short description. Set headingLevel to match the document outline, usually 2 under Page. Actions are React children and wrap on narrow screens. Omit title only when the group does not need a landmark.

## Implementation origin

Origin: system-authored. No catalog component provides unboxed content grouping with optional headings and inherited regional context.
Dependencies: none

## API

API schema: ../schemas/section.schema.json

## Tokens

Semantic tokens: font-heading, background, foreground, muted-foreground, space-panel, space-section-compact-mobile, space-section-compact-desktop, space-section-standard-mobile, space-section-standard-desktop, space-section-spacious-mobile, space-section-spacious-desktop, space-stack, space-tight

## Themes

Section inherits the current theme. An explicit `scheme` switches the section to a named scheme from the theme; without one, it leaves the parent scheme untouched. `surface` is a temporary compatibility alias.

Source story evidence (not installed): src/components/section/section.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Title style

`titleStyle` changes how the heading looks, not what it is: the heading element and `headingLevel` are unchanged. `default` is a large heading for page regions. `label` is a small, muted heading for grouping content inside a product screen, such as "Outbox" above a list. Use `label` with Section's unboxed layout; do not pair it with a painted `scheme` band.

## Section background, content container, and inner surface

`scheme` themes the outer section. `contentWidth` centers and bounds the complete section content, including its heading and actions, with horizontal panel gutters and vertical section padding. The content container controls width, alignment, and gutters. It is transparent and inherits the section scheme.

`contentScheme` adds an inner surface within the content container and resets its semantic roles independently of the section background. It includes panel padding and may be used with or without `contentWidth`. This is a flat regional surface, not a Card variant: use Card for a bordered, rounded content group. Existing Card wrappers keep their shadcn anatomy and can independently reset their own scheme.

For edge-to-edge section backgrounds, place these Sections inside `Page layout="full-bleed"`. Inside a contained Page, sections remain bounded by that Page. Omitting both new props preserves existing layout.

## Section rhythm

Set `Page sectionSpacing` to `compact`, `standard`, or `spacious` to control outer vertical section padding independently of control density. Sections inherit through layout wrappers; a Section can override with its own `sectionSpacing`. Nested Sections retain legacy spacing unless explicitly configured. Omit the Page setting to preserve existing layouts.

Explicit Page rhythm removes the content stack gap in both layouts; adjacent sections supply their own padding, inside their backgrounds. Horizontal gutters, inner surface padding, heading gaps, and control sizes remain unchanged. The Page header retains its existing spacing. Use this setting for pages composed of Sections; wrap other page content in a Section when it needs the same rhythm.

Shared padding per edge at the default root size: compact 16px mobile / 24px desktop, standard 24px / 48px, spacious 40px / 80px. Desktop starts at 48rem. These are semantic rem tokens and may be themed; density does not scale them.

### Override the page rhythm

Use `sectionSpacing="compact"` for a deliberately tighter region within a spacious page. The override applies to this Section only; nested groups keep legacy spacing. Outside an explicitly configured Page, the override does not remove parent gaps. See Page layout (repository reference; not installed) for an example.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="section" />
