# Badge

## When to use

Use for a short label that describes an item: a member's role, a record's status, or a category. Use `neutral` for roles and categories, and `info`, `success`, `warning`, or `destructive` only for the status they name.

Source story evidence (not installed): src/components/badge/badge.stories.tsx#Variants. See packaged agent recipes for executable examples.

## When not to use

Not for actions, filters, or navigation; use Button or a link. Not for messages that need explanation or a next step; use Alert. Not for counts that change live, which need their own announcement. Do not pick a status variant for decoration or to make a role stand out.

## States

None. A badge is static text: it is not focusable and has no hover, disabled, or loading state. When the status it shows changes, render the new label.

An optional `indicator` adds a decorative mark before the label: `dot` for a live state such as "Online", `sync` for work in progress such as "Syncing". Indicators are hidden from assistive technology, so the label must still name the state. The sync icon spins only when the reader has not requested reduced motion.

## Content

One to three words, in sentence case, such as "Active", "Invited", or "Payment failed". The label carries the meaning; color only reinforces it, so the words must name the status without the variant. Longer labels wrap and the badge grows in height; they never clip or truncate.

## Composition

Layout belongs to the parent. No className or style props are exposed. Place a badge next to the text it describes, inside the same table cell, list row, or heading line. Do not nest a badge in a button or link.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/badge.tsx
Dependencies: none

## Catalog base

Wraps catalog `badge` (`src/components/ui/badge.tsx`). `neutral` maps to the catalog `secondary` variant and `destructive` to `destructive`. The catalog has no success, warning, or info variant, so those apply the destructive pattern with their own role: role text on a 10% tint of the role, 20% in dark mode. The token tests check these pairs in every theme. The catalog `default`, `outline`, `ghost`, and `link` variants and `asChild` are hidden. One override: long labels wrap instead of overflowing the fixed catalog height.

## API

API schema: ../schemas/badge.schema.json

## Tokens

Semantic tokens: destructive, info, secondary, secondary-foreground, success, warning

## Themes

Adapts to the containing surface. Status colors come from the theme's status roles; on emphasis surfaces they are near-white, so the label alone carries the status there.

Source story evidence (not installed): src/components/badge/badge.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="badge" />
