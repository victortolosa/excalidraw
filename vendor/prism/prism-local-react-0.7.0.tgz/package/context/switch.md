# Switch

## When to use

Use for settings that take effect immediately on toggle, such as enabling notifications, airplane mode, or feature flags. Every switch has a visible label.

Source story evidence (not installed): src/components/switch/switch.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Not for form values that require explicit submission (use Checkbox instead). Not for selecting between more than two options (use RadioGroup or Select).

## States

Off, on, and disabled states. Disabled removes the switch from tab order and prevents interaction. Error text marks the switch invalid and keeps guidance visible.

## Content

Labels should describe the setting, not the action. The label should read as a complete statement when applied to the on state (e.g. "Two-factor authentication" not "Enable 2FA"). Optional description provides persistent context for the setting's impact.

## Composition

Layout belongs to the parent. No className or style props are exposed. The label and description appear on the left; the toggle control on the right, following the standard settings layout. Controlled state uses checked and onCheckedChange; uncontrolled state uses defaultChecked.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/field.tsx, src/components/ui/switch.tsx
Dependencies: none

## Catalog base

Wraps catalog Switch and Field (FieldLabel, FieldDescription, FieldError, FieldContent) in a horizontal orientation. The label on the left is associated with the switch via id/htmlFor. A small top margin on the switch aligns it with the first line of the label.

## API

API schema: ../schemas/switch.schema.json

## Tokens

Semantic tokens: background, destructive, foreground, input, primary, primary-foreground, ring

## Themes

Adapts to the containing surface. On-state and focus ring use system semantic tokens.

Source story evidence (not installed): src/components/switch/switch.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="switch" />
