# Empty

## When to use

Use for an empty list or result set that needs a short explanation or recovery action. Use distinct copy for an initially empty collection and for a search with no matches.

Source story evidence (not installed): src/components/empty/empty.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Do not use for loading or failure states. Use a status message and retry for load failure. For tabular data, preserve the table caption and headers and use `Table.emptyMessage`.

## States

The message itself is not interactive. Optional children are content such as a Button or link and retain their native keyboard behavior. Empty content is not announced as a live update; add status semantics only when a user action changes the results and requires an announcement.

## Content

Use a brief heading that names the state. Explain how to recover in the description when possible. Keep actions focused on one useful next step. Long text wraps within the parent width.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/empty.tsx
Dependencies: none

## Catalog base

Wraps catalog `empty` (`src/components/ui/empty.tsx`) and its header, description, and content slots. It keeps a native heading level and does not expose generic media slots or style props. The optional `children` slot is React-only so actions can use system components without executable values in the schema.

## API

API schema: ../schemas/empty.schema.json

## Tokens

Semantic tokens: font-heading, muted-foreground, primary

## Themes

Typography and muted text use semantic roles and inherit the surrounding scheme. The catalog root remains transparent so the empty message does not introduce another container plane.

Source story evidence (not installed): src/components/empty/empty.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="empty" />
