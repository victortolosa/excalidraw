# RichTextComposer

## When to use

Use for a single note, comment or message stored as structured JSON or Markdown, requiring headings, bold, italic, bulleted lists, numbered lists and links. It shares Composer’s panel anatomy and token typography.

Source story evidence (not installed): src/components/rich-text-composer/rich-text-composer.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Use Composer for plain text. This editor does not support images, attachments, arbitrary HTML, collaborative editing or multi-field forms. Select the storage format explicitly; plain Composer strings remain plain text. Markdown mode edits rendered content, not raw Markdown source.

## States

Focus highlights the panel. The formatting toolbar uses Radix roving focus: Tab enters once; arrows move between available controls; Tab leaves for the editor. Toggles expose pressed state. Disabled blocks editing and toolbar commands; busy locks mutations while preserving host action feedback. Read-only hides mutations and retains selectable content. Validation error marks the editor invalid; submissionError preserves the document without marking its content invalid. The host disables its supplied slot actions explicitly.

## Content

Provide a visible label by default. Contextually hidden labels remain associated by aria-labelledby. rows and maxRows bound the natural editor height using current typography. The toolbar scrolls horizontally while preserving control targets; focused controls are brought into view. Long labels and content wrap.

JSON is the default format. Store the versioned component contract’s allowlisted JSON document: doc, paragraph, heading (levels 1–3), text, hardBreak, bulletList, orderedList and listItem with bold, italic and safe link marks. Values are validated at the editor boundary. HTML strings and unknown nodes/attributes are rejected. Editor-specific link attributes are stripped from emitted documents. Only absolute http, https and mailto destinations are allowed. Pasted HTML is parsed by the supported editor schema; unsupported formatting and executable links are not persisted.

For controlled JSON editing use value and onValueChange(document). External replacements reset history; controlled echoes preserve selection/history. Use a key per draft identity. defaultValue initializes uncontrolled editing. name/form submit a hidden value in the selected format: serialized JSON or Markdown, never rendered HTML. Form reset restores the current uncontrolled defaultValue and clears history; controlled drafts retain the host value. A typed ref exposes focus(), getDocument(), getMarkdown() and getText(); getText inserts newline separators between blocks and list-item paragraphs and uses UTF-16 string semantics. Semantic emptiness ignores formatting-only paragraphs; hosts own required validation and counting policy.

For Markdown storage set format="markdown" and provide string value/defaultValue; onValueChange receives a Markdown string. The same toolbar edits headings 1–3, bold, italic, nested bullet/numbered lists, hard breaks and safe links. getDocument() remains JSON and getMarkdown() is available in either format. JSON and Markdown value types are checked separately by the React API; no format guessing is performed. Use a key when changing draft identity or switching an uncontrolled editor’s format.

```tsx
const [markdown, setMarkdown] = useState('# Project handoff')
<RichTextComposer label="Note" format="markdown" value={markdown} onValueChange={setMarkdown} />
```

Markdown parsing and serialization use the official Tiptap MarkdownManager, pinned to the editor version. Markdown output normalizes whitespace, delimiter choices and formatting-only empty documents; source strings are not preserved byte for byte. Unsupported headings, images, tables, task lists, quotes, code, strikethrough, raw HTML, link titles and unsafe destinations are rejected at the value boundary rather than silently dropped. Hosts importing arbitrary Markdown must resolve unsupported content before supplying it. Reference-style links normalize to inline links. This is the existing toolbar’s Markdown subset, not a general-purpose Markdown editor.

Controlled echoes retain selection/history and skip reparsing values just emitted by the editor. External replacements reset history in either format. Clear, Undo, form reset, busy and read-only behavior are shared.

Source story evidence (not installed): src/components/rich-text-composer/rich-text-composer.stories.tsx#MarkdownEditing. See packaged agent recipes for executable examples.

The heading split button shows H1, H2 or H3. Its left button toggles that level on/off; off restores a paragraph and remembers the level. The arrow uses a narrower 24px target while retaining the toolbar height. It opens a radio menu with Paragraph and H1–H3; selecting Paragraph restores default text, and selecting a heading level applies it to the selected block. The radio selection reflects the current block style. Escape cancels without changing the document. Selection is preserved on menu open and returns to the editor after applying a level. Commands unavailable in a list context are disabled. Heading typography uses existing heading-family and text-scale roles.

Source story evidence (not installed): src/components/rich-text-composer/rich-text-composer.stories.tsx#HeadingSplitButton. See packaged agent recipes for executable examples.

Clear and Undo use low-prominence ghost buttons. Clear is opt-in and uses editor history so Undo restores formatting and links. The toolbar also provides Undo edit and Redo edit. Typing after an undo starts a new history branch. Link editing preserves the range, supports text/destination, rejects unsafe URLs and restores selection/focus on cancel. Submission, retries, persistence and success resets remain host-owned.

## Implementation origin

Origin: system-authored. JSON and Markdown share one structured editor, which requires document, selection and history behavior absent from catalog input-group; shares the existing Composer panel.
Dependencies: composer, button, dialog, text-field, catalog/dropdown-menu

## API

API schema: ../schemas/rich-text-composer.schema.json

## Tokens

The resting outline uses the shared input role, aliased to border, uniformly on every edge. Focus and validation retain their dedicated indicators. The panel uses the existing surface.container / content.on-container roles through card / card-foreground utilities. The solid container fill replaces the catalog input-border tint, keeping dark Composer between the canvas and stronger muted fills.

Semantic tokens: card, card-foreground, popover, popover-foreground, foreground, primary, secondary, secondary-foreground, accent, accent-foreground, border, input, ring, muted-foreground, destructive

## Themes

Uses shared textarea typography and existing foreground, primary/link, secondary, accent, border, input and ring roles. No editor-engine styling preset or new theme authority is used.

Source story evidence (not installed): src/components/rich-text-composer/rich-text-composer.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.
