# Toggle

## When to use
Use for a pressed/unpressed toolbar mode. A pin icon supports pin mode; a star icon supports favorites. Text labels can name other modes.
Source story evidence (not installed): src/components/toggle/toggle.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use
Use Button for one-time actions, Switch for immediate settings, RadioGroup for exclusive choices, and Checkbox for form selections. No arbitrary icons or custom variants.

## States
`pending` prevents pointer and keyboard activation, sets aria-disabled and aria-busy, and retains focus and the current pressed state. Use controlled state for async persistence; the consumer owns optimistic updates, rollback and errors. `disabled` means unavailable and removes the target from the tab order.

Off, on, disabled and controlled. Enter/Space toggle aria-pressed; keep the accessible name stable.

## Content
label is required. With icon=pin or icon=star it names the icon-only button; without an icon it is visible text. Icons are decorative. For favorites, use a stable name such as “Favorite drawing name” and aria-pressed for the saved state; do not switch the name to “Unfavorite”. Persist controlled state in the consumer and report save failures there.

## Composition
Use pressed/onPressedChange for controlled state or defaultPressed for uncontrolled state; never mix them. Ref, id and aria-describedby are React-only.

## Implementation origin
Origin: shadcn-wrapper. src/components/ui/toggle.tsx
Dependencies: none

## Catalog base
Wraps catalog toggle. Contract overrides: Wrap long labels; minimum 36px target; full-strength focus ring; accent/accent-foreground selected and hover fills replace muted so pressed state remains visible on subtle schemes.

## API
API schema: ../schemas/toggle.schema.json

## Tokens
Semantic tokens: foreground, muted, input, ring, accent, accent-foreground

## Themes
Inherits the containing brand, mode and scheme. Stories cover off/on/outline across all schemes, including favorites.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="toggle" />
