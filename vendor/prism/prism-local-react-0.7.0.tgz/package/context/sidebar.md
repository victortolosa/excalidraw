# Sidebar

## When to use

Use Sidebar for a product-level, persistent set of top-level destinations. Give the navigation landmark a name that distinguishes it from any other navigation on the page, and set `currentId` from routing state.

Source story evidence (not installed): src/components/sidebar/sidebar.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Use NavigationMenu for inline page navigation. Compose a product shell when the design needs a header, footer, nested groups, account controls, badges, search, or other application-specific content.

## States

The current destination has `aria-current="page"` and the catalog active treatment. The trigger switches between expanded labels and icon-only navigation. Every item requires an icon so the collapsed state remains identifiable; its tooltip supplies the destination name. Links retain native focus and keyboard behavior.

## Content

Use concise, familiar destination names and keep the list to top-level pages. Do not put actions, counts, nested navigation, or user controls in this first system contract. Use the icon that best matches the destination rather than treating icon choice as decorative.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/sidebar.tsx
Dependencies: none

## Catalog base

Wraps catalog `sidebar` (`src/components/ui/sidebar.tsx`). It fixes the catalog to left-side, standard sidebar presentation, top-level link items, and icon collapse. It deliberately hides catalog layout variants, submenus, headers, footers, rails, form controls, menu actions, badges, and custom styling hooks because no supported screen needs them yet.

## API

API schema: ../schemas/sidebar.schema.json

## Tokens

Semantic tokens: background, sidebar, sidebar-accent, sidebar-accent-foreground, sidebar-border, sidebar-foreground, sidebar-ring

## Themes

Sidebar consumes the `sidebar`, `sidebar-foreground`, `sidebar-accent`, `sidebar-accent-foreground`, `sidebar-border`, and `sidebar-ring` semantic roles. It adapts through the active brand and mode; callers do not set colors or styles directly.

Source story evidence (not installed): src/components/sidebar/sidebar.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="sidebar" />
