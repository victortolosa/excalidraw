# Carousel

## When to use

Use for optional featured content browsed one slide at a time. Give the region a unique accessible name and each slide a descriptive label. renderSlide returns React content for an ID; keep it outside serialized input.

Source story evidence (not installed): src/components/carousel/carousel.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Prefer a list or grid for important content that must be discoverable without navigation. No autoplay, looping, custom Embla plugins, vertical mode, or controlled index is exposed. Previous/next labels and position text are currently English; localization is a contract extension.

## States

Visible Previous slide and Next slide buttons advance manually and disable at the boundaries. The focusable region also responds to left/right arrows; keys from slide controls are left alone. Offscreen slides remain mounted but are inert and hidden from assistive technology. A polite status announces position. Reduced-motion preference changes are observed and disable Embla scroll animation. There is no automatic movement to pause.

## Content

Use unique stable IDs and keep the item order stable while someone is interacting. Preserve important content elsewhere if discovering it is required. Slide children own their behavior; avoid nested carousels. Long content wraps; the carousel height follows the tallest mounted slide rather than clipping shorter or taller text. Cross-item uniqueness is a Zod check, not a complete JSON Schema guarantee.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/carousel.tsx
Dependencies: button

## Catalog base

Wraps catalog Carousel, Content, and Item and uses system Buttons for navigation. Controls stay in normal flow instead of outside the frame. Wrapper overrides add focus visibility, protect child focus rings with padding, and replace unconditional catalog arrow capture so embedded inputs keep their arrow keys. The wrapper cleans up its Embla event listeners.

## API

API schema: ../schemas/carousel.schema.json

## Tokens

Semantic tokens: muted-foreground, radius, ring

## Themes

Inherits regional roles. SchemeMatrix and Catalog/Surface checks include real input content. LongContent covers a narrow container. Automated checks do not replace manual screen-reader review of slide and status announcements.

Source story evidence (not installed): src/components/carousel/carousel.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

Reference: [upstream behavior and accessibility](https://www.w3.org/WAI/tutorials/carousels/).

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="carousel" />
