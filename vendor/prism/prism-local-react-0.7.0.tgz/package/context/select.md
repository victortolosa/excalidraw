# Select

## When to use

Use for picking one option from a predefined list when choices take too much horizontal space for a radio group. Every select input has a visible label.

Source story evidence (not installed): src/components/select/select.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Not for multi-select, freeform text entry (use TextField), or binary on/off decisions (use Switch or Checkbox). For small sets of 2–4 options, prefer RadioGroup so all choices remain visible.

## States

Disabled removes the trigger from tab order and prevents interaction. Error text marks the trigger invalid and keeps guidance visible.

## Content

A label is always rendered and is always the accessible name. `labelVisibility="hidden"` removes it from view but keeps it as the accessible name, for a field that visible context already names. Hide a label only when that context sits right next to the field and the accessibility profile allows contextual labels. A hidden label cannot be combined with `required`, because the required marker would be hidden too.

Use concise labels and clear option names. A placeholder can provide a selection prompt when no default is selected.

## Composition

Layout belongs to the parent. No className or style props are exposed. Controlled values use value and onValueChange; uncontrolled values use defaultValue. Overlays render in a portal using the page theme and default surface.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/field.tsx, src/components/ui/select.tsx
Dependencies: none

## Catalog base

Wraps catalog Select (SelectTrigger, SelectValue, SelectContent, SelectItem) and Field (FieldLabel, FieldDescription, FieldError). The trigger is full-width to fill form columns. Focus and invalid states adhere to system contrast standards.

## API

API schema: ../schemas/select.schema.json

## Tokens

Semantic tokens: accent, accent-foreground, border, destructive, foreground, input, muted-foreground, popover, popover-foreground, ring

## Themes

Inherits the containing scheme for the field trigger; never accepts a scheme prop. The dropdown menu renders in a portal on the page theme and default scheme.

Source story evidence (not installed): src/components/select/select.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="select" />
