# Table

## When to use

Use for records that share the same fields and are compared across rows: team members, invoices, recent activity. Pass columns and rows as data; the component builds the caption, headers, and row headers.

Source story evidence (not installed): src/components/table/table.stories.tsx#WithComponents. See packaged agent recipes for executable examples.

## When not to use

Not for page or form layout; use layout utilities. Not for one record's details; use a Card with a description list. Not for a single list of items without columns; use a list. Sorting, filtering, pagination, and row selection are not supported yet.

## States

With rows, and empty. When there are no rows, the table keeps its caption and headers and shows `emptyMessage` in one full-width cell. Say why it is empty and what to do next. Rows are not focusable or clickable. Put actions inside a cell as buttons or links.

## Content

The caption names what the rows are, such as "Team members". Headers are short nouns. The first column must identify the row, usually a name, because it becomes each row's header for screen readers. Order columns by importance. Align numbers and amounts to the end with `align: 'end'`, and format them before passing them in. Cells wrap, breaking long values such as email addresses, so keep tables to about four columns if they must fit a phone.

## Composition

Layout belongs to the parent. No className or style props are exposed. `renderCell(columnKey, row)` returns rich content for a cell, such as an Avatar, Badge, or row action; return `undefined` to show the row's text value. Rows may carry extra fields for renderCell, such as an image URL. Inside a Card whose title names the table, set `hideCaption`; the caption stays as the accessible name. When an Avatar sits next to the name it shows, make it decorative.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/table.tsx
Dependencies: none

## Catalog base

Wraps catalog `table` (`src/components/ui/table.tsx`): Table, TableCaption, TableHeader, TableBody, TableRow, TableHead, and TableCell. TableFooter and the selected row state are not exposed. Styling overrides, each required by this contract: cells wrap instead of staying on one line, so tables fit 320px without sideways scrolling; headers follow their column's alignment; and the caption sits above the table because it names it.

## API

API schema: ../schemas/table.schema.json

## Tokens

Semantic tokens: border, foreground, muted, muted-foreground

## Themes

Text, borders, and the row hover use the foreground, border, and muted roles, and adapt to the containing surface.

Source story evidence (not installed): src/components/table/table.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="table" />
