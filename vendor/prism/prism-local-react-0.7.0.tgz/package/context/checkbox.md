# Checkbox

## When to use

Use for binary choices that can be toggled on or off independently, such as accepting terms, enabling settings, or selecting items from a list. Every checkbox has a visible label.

Source story evidence (not installed): src/components/checkbox/checkbox.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Not for mutually exclusive options (use RadioGroup or Select) or immediate on/off actions that take effect without form submission (use Switch).

## States

Unchecked, checked, and disabled states. Disabled removes the checkbox from tab order and prevents interaction. Error text marks the input invalid and keeps guidance visible.

## Content

Labels should be concise and describe what happens when checked. Instructions or secondary details belong in description.

## Composition

Layout belongs to the parent. No className or style props are exposed. Controlled state uses checked and onCheckedChange; uncontrolled state uses defaultChecked. The checkbox indicator uses primary color roles for high contrast in all themes.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/field.tsx, src/components/ui/checkbox.tsx
Dependencies: none

## Catalog base

Wraps catalog Checkbox and Field (FieldLabel, FieldDescription, FieldError, FieldContent) in a horizontal orientation. The wrapper associates the input with its label, description, and error via IDs and ARIA attributes.

## API

API schema: ../schemas/checkbox.schema.json

## Tokens

Semantic tokens: destructive, input, primary, primary-foreground, ring

## Themes

Adapts to the containing surface. Checked indicator and focus ring use system semantic tokens.

Source story evidence (not installed): src/components/checkbox/checkbox.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="checkbox" />
