# IconButton

Component ID: `icon-button`. Status: experimental.

IconButton triggers a familiar compact action. It wraps the shadcn catalog Button and renders a native `<button>` with a required accessible name.

Source story evidence (not installed): src/components/icon-button/icon-button.stories.tsx#Primary. See packaged agent recipes for executable examples.

## When to use

- Use a familiar, repeated action where a visible text label would be redundant, such as closing a dialog or editing a row.
- Use `primary` only for the main compact action in a region; otherwise use `secondary`.
- Use the supported Lucide icon that most directly matches the action.

## When not to use

- A primary action whose meaning needs visible text: use Button.
- An unfamiliar, destructive, toggle, menu, or navigation action: use the component or pattern that expresses that behavior.
- An arbitrary SVG, a brand mark, or an icon outside the supported icon set: report a gap instead of bypassing the contract.

## States

- `disabled` removes the control from the tab order. Explain nearby why the action is unavailable.
- Focus uses the full-strength `ring` role, matching Button.
- There is no loading state. A pending compact action needs an explicit supported state before it is added.

Source story evidence (not installed): src/components/icon-button/icon-button.stories.tsx#Disabled. See packaged agent recipes for executable examples.

## Content

`label` is required and becomes the native button's accessible name. Describe the action and its target, such as "Edit project" rather than "Edit". The icon is hidden from assistive technology. A Tooltip may supplement a familiar action, but must not be required to understand it on touch devices. Use a visible Button label for unfamiliar or ambiguous actions. Settings is a suitable page action; a pencil suits editing a clearly scoped item. Keep “Change destination” as text when the action selects a different destination rather than editing its content.

Source story evidence (not installed): src/components/icon-button/icon-button.stories.tsx#Icons. See packaged agent recipes for executable examples.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/button.tsx
Dependencies: none

## Catalog base

Wraps the catalog Button (`src/components/ui/button.tsx`) with its `icon-lg` size. The system fixes a square target from the `icon-button.size` token, scales it with density, uses the brand Button radius, requires a label, and narrows catalog variants to `primary` and `secondary`. The Lucide React package is already used by the catalog and system; its icon library is ISC-licensed. No additional icon dependency is introduced.

## API

API schema: ../schemas/icon-button.schema.json

### React-only API

The React component also accepts `ref`, `id`, `name`, `value`, `form`, `onClick`, `onFocus`, `onBlur`, and `aria-describedby`. `className`, `style`, and `aria-label` are deliberately excluded; `label` owns the accessible name.

## Tokens

Semantic tokens: primary, primary-foreground, background, foreground, border, input, muted, ring

`icon-button.size` is the comfortable square control size. It scales with the density profile and cannot fall below the 24px minimum target size. Glyphs remain 16px so they stay recognizable.

## Themes

The same markup renders in every brand, mode, and scheme. Colors come from the containing scheme's roles; shape comes from the theme's Button radius. IconButton has no scheme prop: set `data-scheme` on a container.

Source story evidence (not installed): src/components/icon-button/icon-button.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Attachment and mention actions

attachment and mention are supported glyphs for Attach file and Add mention. The callback supplies application behavior; no upload or mention picker is built in. Use Toggle for pin mode, not IconButton.
