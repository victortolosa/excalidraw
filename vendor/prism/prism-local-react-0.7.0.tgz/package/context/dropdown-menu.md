# DropdownMenu

## When to use

Use for a short set of actions on a row or object. Give repeated triggers a visible context, such as “Actions for Grace Hopper”.

Source story evidence (not installed): src/components/dropdown-menu/dropdown-menu.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Use Select or RadioGroup for form values and native links for navigation. Submenus, checkable items, icons, groups, and custom triggers are not supported. Report missing capabilities as gaps.

## States

This is a non-modal action menu: the rest of the page remains available, and outside interaction dismisses it. The trigger can be disabled. Disabled items are skipped by keyboard navigation. Enter or Space opens and activates; arrow keys move between enabled items; typing finds an item; Escape closes and returns focus to the trigger. Selecting an item closes the menu and calls onAction with its ID and the trigger button. Use that button as a return-focus target when an action opens a controlled Dialog. Destructive styling does not provide confirmation: the caller owns confirmation and async feedback.

## Content
The optional `trigger="icon"` uses the existing more IconButton. `label` becomes its accessible name; include object context for repeated menus. The default text trigger is unchanged.

Use concise action verbs and unique IDs. Long labels wrap. Keep async state and callbacks outside the serializable items. Do not delete content immediately when an action needs confirmation.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/dropdown-menu.tsx
Dependencies: button, icon-button

## Catalog base

Wraps catalog DropdownMenu, Trigger, Content, and Item. Overrides only constrain viewport width and wrap long labels. Radix owns focus, selection, dismissal, and portal behavior.

## API

API schema: ../schemas/dropdown-menu.schema.json

## Tokens

Semantic tokens: accent, accent-foreground, border, destructive, foreground, muted-foreground, popover, popover-foreground

## Themes

The trigger inherits its regional context. The menu portals to body and uses the page brand and mode on the default surface. ThemeChecks opens it from emphasis and checks every page theme. LongContent checks portal overflow at the test viewport; a narrow wrapper is not a 320px viewport test.

Source story evidence (not installed): src/components/dropdown-menu/dropdown-menu.stories.tsx#ThemeChecks. See packaged agent recipes for executable examples.

Viewport evidence: S8 overlay review records an additional 320px check of the built long-content story.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="dropdown-menu" />
