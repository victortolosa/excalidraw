# SignupForm

## When to use

Use for account creation with name, email, password confirmation, Google signup and a supplied sign-in destination. Supported block composed from Card, TextField and Button.

Source story evidence (not installed): src/blocks/signup-form/signup-form.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Not for sign-in, workspace setup, consent, subscription selection or authentication infrastructure. Caller owns verification, server validation, password policy and provider integration.

## States

Idle, invalid, submitting, failure/retry and caller result feedback. Both actions are mutually exclusive while pending. First invalid input receives focus. Errors stay associated with inputs; results use a live status and failures an alert. Values remain after failure. Passwords clear after resolved action.

Source story evidence (not installed): src/blocks/signup-form/signup-form.stories.tsx#Invalid. See packaged agent recipes for executable examples.

Source story evidence (not installed): src/blocks/signup-form/signup-form.stories.tsx#Recovery. See packaged agent recipes for executable examples.

## Content

Labels and copy are serializable. Eight-character minimum and matching confirmation preserve the source block's requirement, not a universal password policy. Full name must be nonblank; email must satisfy the shared credential schema. Local fixture callbacks explicitly announce that they do not create accounts. No credentials are stored, logged or serialized in fixtures.

## Composition

Use inside a bounded parent. Block owns transient field state and validation. Required React callbacks: `onSubmit({ name, email, password })` and `onGoogleSignup()`, both return `Promise<{ message: string }>`. Rejection produces recoverable failure; resolution displays caller feedback without inferring authenticated success. Confirmation stays local. No arbitrary styles, slots or inherited Card props. Never nest inside a form.

Source story evidence (not installed): src/blocks/signup-form/signup-form.stories.tsx#PageExample. See packaged agent recipes for executable examples.

## Implementation origin

Adapted from shadcn signup-01, radix-nova. Immutable retrieved snapshot and attribution are in `vendor/shadcn/blocks/signup-01/`; `blocks.lock.json` pins bytes and actual imports, including upstream's undeclared Field dependency. No upstream application source is imported.

## Catalog base

System Card, TextField and Button exclusively. Removed the product-specific email privacy promise and replaced the placeholder sign-in link with a required destination. Next.js routing is excluded. The page example uses Page and Section and adds a visible H1 for Prism's landmark contract.

## API

API schema: generated/schemas/signup-form.schema.json

## Tokens

Inherits component tokens and containing semantic scheme. Local layout uses stack/tight spacing; local status/navigation use foreground, muted-foreground, destructive and ring roles.

## Themes

Supports both modes and all configured regional schemes.

Source story evidence (not installed): src/blocks/signup-form/signup-form.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.
