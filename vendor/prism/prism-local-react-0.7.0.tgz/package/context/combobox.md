# Combobox

## When to use

Use when people need to search a predefined list and select one option. Keep the full choice set available when the field is focused or opened.

Source story evidence (not installed): src/components/combobox/combobox.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Use Select for a short list that does not need search, RadioGroup when a small set of options should remain visible, TextField for freeform values, or Checkbox for independent choices. This component currently supports one selected option; use a documented gap for multi-select.

## States

The input supports typing, filtered results, highlighted options, selection, no matches, required, disabled, and invalid states. Arrow keys move through available results; Enter selects the highlighted result; Escape closes the popup. Disabled options cannot be selected. Error text remains associated with the input when the popup opens.

Source story evidence (not installed): src/components/combobox/combobox.stories.tsx#SearchAndChoose. See packaged agent recipes for executable examples.

## Content

A label is always rendered and is always the accessible name. `labelVisibility="hidden"` removes it from view but keeps it as the accessible name, for a field that visible context already names. Hide a label only when that context sits right next to the field and the accessibility profile allows contextual labels. A hidden label cannot be combined with `required`, because the required marker would be hidden too.

Every field has a visible label. Option labels must distinguish choices and serve as the selected input text. Keep labels concise; long labels wrap within the popup. Use persistent description for guidance and an actionable error for invalid state.

## Composition

Layout belongs to the parent. No className or style props are exposed. Controlled values use `value` and `onValueChange`; uncontrolled values use `defaultValue`. Value props use the option shape `{ value, label }`. The popup renders in a portal using the page theme and default scheme.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/combobox.tsx
Dependencies: none

## Catalog base

Wraps the vendored Base UI Combobox through the catalog `Combobox`, `ComboboxInput`, `ComboboxContent`, `ComboboxList`, `ComboboxItem`, and `ComboboxEmpty` parts, plus Field label, description, and error primitives. The system API deliberately hides catalog chips/multiple selection, custom collection/group composition, trigger placement controls, and style/class overrides. It renders a single-choice input with an explicit no-results message. The catalog trigger is omitted because its current InputGroup composition nests interactive buttons and fails the button-name and nested-interactive checks; opening is supported by focusing or clicking the input and typing. The input fills its form column and explicitly uses foreground text and the full-strength focus ring so it remains readable on emphasis schemes.

## API

API schema: ../schemas/combobox.schema.json

## Tokens

Semantic tokens: accent, accent-foreground, border, destructive, foreground, input, muted, muted-foreground, popover, popover-foreground, ring

## Themes

Inherits the containing scheme for the field input; never accepts a scheme prop. The popup renders in a portal on the page theme and default scheme.

Source story evidence (not installed): src/components/combobox/combobox.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="combobox" />
