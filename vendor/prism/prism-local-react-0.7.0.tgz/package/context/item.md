# Item

## When to use

Use for repeated entries a person scans and acts on: notes in an outbox, people on a team, files in a project. A row is the main grouping pattern for product screens. It holds a title, an optional supporting line, an optional status as text, and trailing actions.

Source story evidence (not installed): src/components/item/item.stories.tsx#WithAction. See packaged agent recipes for executable examples.

## When not to use

Not for one self-contained task or unit; use Card. Not for a message whose color carries meaning; use Alert. Not for tabular data with several comparable columns; use Table. Not outside ItemGroup: the group supplies the list that gives each row its meaning.

## States

Items are static and not focusable. Interactive content goes in the trailing slot using Button or IconButton, which carry their own focus, disabled and loading states. Show a row's state with the `status` text, such as "Waiting to send", never with color alone.

## Content

The title names the row in one short line. The description adds one supporting line. Long words and URLs wrap and the row grows in height; the catalog line clamp is removed so no content is hidden. Give ItemGroup a `label` that names the list.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/item.tsx
Dependencies: none

## Catalog base

Wraps catalog `item` (`src/components/ui/item.tsx`). Wraps catalog `item`: Item, ItemGroup, ItemContent, ItemTitle, ItemDescription, and ItemActions. `plain` maps to the catalog `default` variant and `outlined` to `outline`. The catalog `muted` variant, size scale, media slot, header, footer, separator and `asChild` are not exposed. Overrides: rows use `rounded-panel` so each grouping level has one shape role; title and description drop the catalog line clamp so content is never hidden; each row sets `role="listitem"`, and ItemGroup adds its `label` as the list name. Title, description and status text styles are registered typography slots.

## API

API schema: ../schemas/item.schema.json

ItemGroup takes a single required `label`.

API schema: ../schemas/item.schema.json

## Tokens

Semantic tokens: border, muted-foreground, ring

## Themes

Rows use the border role for the outlined variant and the muted foreground role for supporting text and status, so they adapt to the containing scheme.

Source story evidence (not installed): src/components/item/item.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="item" />
