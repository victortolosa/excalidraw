# Avatar

## When to use

Use to identify a person, team, or organization by picture: member lists, comment authors, account menus, and assignees. Pass the full name; the avatar shows the image when there is one and initials otherwise.

Source story evidence (not installed): src/components/avatar/avatar.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Not for status such as online or away; put a Badge with a text label next to it. Not for product icons, logos in navigation, or illustrations. Not as a button or link by itself; if an avatar opens a profile, wrap it with the visible name in a link.

## States

The image loads over the initials. Initials show while the image loads and when it fails, so there is never an empty circle. The avatar is not focusable and has no hover or disabled state.

## Content

Pass the full name, not initials. The component takes the first letters of the first and last words, so long names always show at most two characters. For a single-word name, one letter shows. Use a square image; it is cropped to a circle.

## Composition

Layout belongs to the parent. No className or style props are exposed. When the name is visible next to the avatar, as in most rows and cards, set `decorative` so screen readers do not read the name twice. Standalone, the avatar is announced as an image named by the full name. Use `sm` in dense tables, `default` in lists, and `lg` in page and profile headers.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/avatar.tsx
Dependencies: none

## Catalog base

Wraps catalog `avatar` (`src/components/ui/avatar.tsx`): Avatar, AvatarImage, and AvatarFallback, with the catalog sizes. The root carries the accessible name; the image and initials are hidden from assistive technology because initials are not a readable label. AvatarBadge is hidden because a status dot shows state by color alone. AvatarGroup and AvatarGroupCount are not wrapped. There are no styling overrides.

## API

API schema: ../schemas/avatar.schema.json

## Tokens

Semantic tokens: border, muted, muted-foreground

## Themes

The initials use the muted roles and adapt to the containing surface. Images are shown as provided.

Source story evidence (not installed): src/components/avatar/avatar.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="avatar" />
