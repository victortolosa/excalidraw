# SiteHeader

## When to use

Use once at the top of a public-site or application layout for site identity, primary navigation, and a skip link to Page. The home link and navigation are separate accessible controls.

Source story evidence (not installed): src/components/site-header/site-header.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Do not use it as a page title bar or duplicate it within a route. Page owns the H1 and page-level actions.

## States

The desktop navigation is visible from the medium breakpoint. At narrow widths, a disclosure button opens a vertical menu. Escape closes it and restores focus to the trigger; selecting a link closes it. The skip link becomes visible on focus.

## Content

Give the site a short name. Navigation uses the documented NavigationMenu input, with concise labels. Keep menuLabel, skipLabel, and mainId aligned with the Page target. Supplementary actions are React children. The actions slot follows navigation. Use the React-only identityContent slot for version or environment metadata beside the home link; it remains outside that link. Neither slot is serialized in the contract.

## Implementation origin

Origin: system-authored. Shared site identity, skip link, and mobile navigation compose system navigation and a catalog disclosure; no catalog header supplies this responsibility.
Dependencies: navigation-menu, button, catalog/collapsible

## API

API schema: ../schemas/site-header.schema.json

## Tokens

Semantic tokens: font-heading, border, background, foreground, space-panel, space-stack, space-tight, radius, ring

## Themes

The header inherits colors from the active brand, mode, and surface. The layout wraps at narrow widths; navigation becomes a disclosure rather than forcing horizontal overflow.

Source story evidence (not installed): src/components/site-header/site-header.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Layout and translation

The header centers a bounded container (`max-w-7xl`) within the viewport. The default compact layout groups identity, navigation and actions at the start. Distributed layout separates these groups across available space; navigation is between the side groups, not necessarily at the exact viewport center. Both layouts wrap when space is limited and retain the mobile disclosure.

Use distributed for public-site headers with separated identity and action groups. Use compact for closely grouped navigation. Do not override internal layout styles from a page. Keep identityContent concise and allow it to wrap; put actions in the actions slot.

Source story evidence (not installed): src/components/site-header/site-header.stories.tsx#Distributed. See packaged agent recipes for executable examples.

## Identity image

Optional logoSrc displays a decorative image beside the required visible siteName. The home link retains its accessible text; do not use an image-only identity or replace the skip-link behavior.

## Primary navigation CTA

Use primaryAction={{label, href, icon}} for a prominent navigation destination such as “Plan a retreat.” It renders a native anchor with filled primary treatment, shared Button sizing and tokens, and an optional decorative icon. It stays visible outside the mobile menu. Keep ordinary navigation in navigation; use the React actions slot for supplementary callback actions. Do not duplicate the primary CTA in both APIs.

## Grouped trailing navigation

Set navigationPlacement="with-actions" to group secondary navigation links with primaryAction at the trailing edge on desktop. Use layout="distributed" for a separated identity and trailing group. The group preserves navigation-before-CTA reading order and wraps without clipping. Mobile navigation still uses the supported Menu disclosure while the primary CTA remains outside it. The default navigationPlacement="separate" preserves existing layouts. This option controls composition, not alignment within NavigationMenu.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="site-header" />
