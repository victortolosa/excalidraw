# TextField

## When to use

Use for single-line text, email and password values. Every input has a visible label.

Source story evidence (not installed): src/components/text-field/text-field.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Not for multiline text, search, or custom input adornments. Request a contract extension.

## States

Disabled removes the input from tab order; readOnly preserves focus and copying. Error text marks the input invalid and keeps guidance visible.

## Content

A label is always rendered and is always the accessible name. By default it is visible. `labelVisibility="hidden"` removes it from view but keeps it as the accessible name, for a field that visible context already names, such as the single composer under a "Note" heading. Hide a label only when that context sits right next to the field and the accessibility profile allows contextual labels. A hidden label cannot be combined with `required`, because the required marker would be hidden too. Keep the placeholder as a hint, not as the name.

Password masks native input content. Supply `autoComplete="new-password"` for signup or `"current-password"` for sign-in. Validation belongs to the form; no reveal toggle is included.

Use concise labels and persistent instructions. Long prose wraps. Single-line input values scroll natively without losing their content.

## Composition

Layout belongs to the parent. No className or style props are exposed. Values, refs, IDs, autocomplete, form association, and event handlers are React-only. Controlled values require onChange; do not mix value and defaultValue.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/field.tsx, src/components/ui/input.tsx
Dependencies: none

## Catalog base

Wraps catalog Field, FieldLabel, FieldDescription, FieldError and Input. The wrapper associates labels, guidance, and errors. Input values use foreground because inherited destructive text fails contrast on tinted emphasis inputs. Its focus override uses the full-strength checked ring, including invalid fields. Wrapping classes prevent long guidance from overflowing.

## API

API schema: ../schemas/text-field.schema.json

## Tokens

Semantic tokens: foreground, input, ring, destructive, muted-foreground

## Themes

Inherits the containing scheme; never accepts a scheme prop. No brand branches are used.

Source story evidence (not installed): src/components/text-field/text-field.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="text-field" />
