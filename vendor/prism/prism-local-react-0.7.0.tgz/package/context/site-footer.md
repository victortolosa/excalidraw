# SiteFooter

## When to use

Use once at the end of a public-site or application layout for grouped destination links and legal information. Group headings help readers scan the footer.

Source story evidence (not installed): src/components/site-footer/site-footer.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Do not use SiteFooter for a local panel footer or dialog actions. Those belong to the enclosing component.

## States

The footer has no interactive state of its own. Links retain native keyboard and focus behavior. If there are no groups or legal links, their navigation landmarks are omitted.

## Content

Give each group a distinct ID and short heading. Write link labels that identify destinations. Legal text is plain text; legal links form a separately named navigation landmark.

## Implementation origin

Origin: system-authored. No catalog component owns grouped site links, identity text, and a legal row in a contentinfo landmark.
Dependencies: badge

## API

API schema: ../schemas/site-footer.schema.json

## Tokens

Semantic tokens: font-heading, border, foreground, muted-foreground, space-panel, space-stack, space-tight, space-section, ring

## Themes

Footer borders, text, and background inherit theme roles. Groups collapse to one column at narrow widths and links wrap without horizontal overflow.

Source story evidence (not installed): src/components/site-footer/site-footer.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Operational status

Optional status displays a static supported Badge beside legal text. Caller owns the label's accuracy; the design system does not monitor uptime. Omit it when no product status is available.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="site-footer" />
