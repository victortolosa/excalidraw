# NavigationMenu

## When to use

Use for a named collection of page destinations. Supply currentId from route state; it marks the current page with aria-current and an underline. Give each navigation landmark a distinct name.

Source story evidence (not installed): src/components/navigation-menu/navigation-menu.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Use DropdownMenu for actions and Tabs for related panels within a page. This initial contract has flat links only: no flyouts, nested groups, router render slots, disabled destinations, or custom link content.

## States

Links retain native navigation behavior and keyboard activation. Tab moves through links; Radix manages directional keys and Home/End. Horizontal links wrap on narrow layouts; vertical links stack. Current-page state is supplied by the caller, not inferred from the browser location.

## Content

Use short destination names and unique IDs. href accepts root-relative paths, queries, fragments, or HTTP(S) URLs; executable schemes are outside the contract. Labels can wrap without truncating the destination. currentId must identify an item. Cross-item identity rules are enforced by Zod, not fully expressible in exported JSON Schema.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/navigation-menu.tsx
Dependencies: none

## Catalog base

Wraps catalog NavigationMenu, List, Item, and Link without a viewport or popup. Overrides constrain width, wrap links, use the full-strength focus ring, and underline the current page. No catalog source changes.

## API

API schema: ../schemas/navigation-menu.schema.json

## Tokens

Semantic tokens: border, foreground, muted, popover, popover-foreground, ring

## Themes

Inherits the current regional scheme. SchemeMatrix shows every configured scheme for the selected brand and mode. LongContent exercises a narrow container.

Source story evidence (not installed): src/components/navigation-menu/navigation-menu.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

Reference: [upstream behavior and accessibility](https://www.radix-ui.com/primitives/docs/components/navigation-menu).

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="navigation-menu" />
