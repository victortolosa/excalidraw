# RadioGroup

## When to use

Use for selecting exactly one option from a small set of mutually exclusive choices (typically 2 to 5 options) where all alternatives should be visible at once. Every group has a visible label or question.

Source story evidence (not installed): src/components/radio-group/radio-group.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Not for multi-select (use Checkbox), large lists of options (use Select), or binary on/off settings that act immediately (use Switch).

## States

Unselected, selected, and disabled states. Disabled removes the radio items from the tab order. Group-level error text marks the group invalid and keeps guidance visible.

## Content

Use concise group labels and descriptive option titles. Individual options can include optional helper descriptions to explain their impact.

## Composition

Layout belongs to the parent. No className or style props are exposed. Controlled state uses value and onValueChange; uncontrolled state uses defaultValue. Supports vertical and horizontal orientations.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/field.tsx, src/components/ui/radio-group.tsx
Dependencies: none

## Catalog base

Wraps catalog RadioGroup and RadioGroupItem, composing them with FieldSet, FieldLegend, Field, and FieldContent. Radio indicator uses primary role styling with proper contrast in all themes.

## API

API schema: ../schemas/radio-group.schema.json

## Tokens

Semantic tokens: destructive, input, primary, primary-foreground, ring

## Themes

Adapts to the containing surface. Selected indicators and focus rings use system semantic tokens.

Source story evidence (not installed): src/components/radio-group/radio-group.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="radio-group" />
