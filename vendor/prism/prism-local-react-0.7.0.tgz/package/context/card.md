# Card

## When to use

Use for a related content group. The Card is not clickable; actions belong inside it.

A card normally has a visible `title`. When the surrounding screen already names the group, such as the single task panel on a product screen, use headingless mode instead: provide `label` (an accessible name, announced as a group) and no `title` or `description`. Provide exactly one of the two. Do not use headingless mode to hide a heading a reader needs to scan.

Source story evidence (not installed): src/components/card/card.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Not for navigation, dialogs, or clickable tiles. Do not put a Card inside a heading or nest forms.

## States

Card has no interactive state. Children own loading, disabled, and error behavior.

## Content

Use concise labels and persistent instructions. Long prose wraps. Single-line input values scroll natively without losing their content.

## Composition

Layout belongs to the parent. No className or style props are exposed. Children are a React-only content slot, not serializable JSON. Use headings in order. A nested Card inherits the same region unless its `scheme` explicitly establishes a new context; use the next heading level.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/card.tsx
Dependencies: none

## Catalog base

Wraps catalog Card, CardHeader, CardDescription and CardContent. The catalog paints `card` and `card-foreground` within the inherited region. An explicit `scheme` resets the complete regional context for the Card and its descendants. Visible overflow preserves child focus rings. A native heading supplies document structure. Wrapping and minimum-width overrides prevent content overflow.

## API

API schema: ../schemas/card.schema.json

## Tokens

Semantic tokens: card, card-foreground, muted-foreground

## Themes

Scheme options come directly from tokens/themes.json. Omit `scheme` to inherit. Pass `scheme="default"` for a neutral working area inside emphasis, or another listed scheme when the whole Card needs that context. Brand and mode remain inherited. `surface` remains a temporary compatibility alias. No brand branches are used.

Source story evidence (not installed): src/components/card/card.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

Source story evidence (not installed): src/components/card/card.stories.tsx#RegionalContexts. See packaged agent recipes for executable examples.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="card" />
