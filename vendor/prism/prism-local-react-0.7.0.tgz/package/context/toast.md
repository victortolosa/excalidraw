# Toast

## When to use

Use for brief, non-blocking outcome feedback, such as a successful save. Mount ToastProvider once around the application, call useToast().show(input) from an event, and retain its returned ID when programmatic dismissal is needed. The hook requires its provider. Inputs are statically typed; runtime validation is opt-in. Import validateToast from @prism-local/react/toast/validation and pass validateInput={validateToast} to ToastProvider when input needs validation. This separate import loads Zod; ordinary Toast usage does not.

Source story evidence (not installed): src/components/toast/toast.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Use inline Alert for persistent errors, essential instructions, or required action, and Dialog for a decision. Toast actions, arbitrary content, loading promises, placement options, and persistent notifications are not supported. Do not call show during rendering.

## States

Notifications announce through Sonner’s polite live region without moving focus. They expire, can be dismissed with the close button or dismiss(id), and pause during Sonner interaction. Alt+T focuses the notification area. Unmounting the provider dismisses its notifications. Variant icons supplement explicit text; color is not the only signal.

## Content

Keep titles short and explicit. Supporting text wraps. Essential feedback must also remain available inline; a disappearing toast is not the sole record of a failed save. show validates serializable input at runtime and rejects unknown fields. IDs and hook functions are React-only API, outside the schema.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/sonner.tsx
Dependencies: none

## Catalog base

Wraps the catalog Toaster and Sonner’s notification API. A body portal prevents regional surface inheritance. The wrapper observes page mode changes. Rich colors stay off so Sonner does not introduce a status palette. Overrides replace description and close-button palette/focus styles with semantic roles and wrap unbroken content.

## API

API schema: ../schemas/toast.schema.json

## Tokens

Semantic tokens: font-body, muted-foreground, ring, border, popover, popover-foreground, radius

## Themes

Notifications use the page brand, mode, and default surface. ThemeChecks checks each variant in every page theme while triggered from emphasis. The fixed overlay’s LongContent story checks overflow at the browser viewport, not a simulated 320px viewport. Manual screen-reader announcement and timeout usability review remain required.

Source story evidence (not installed): src/components/toast/toast.stories.tsx#ThemeChecks. See packaged agent recipes for executable examples.

Viewport evidence: S8 overlay review records an additional 320px check of the built long-content story.

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="toast" />
