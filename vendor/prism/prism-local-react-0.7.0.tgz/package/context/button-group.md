# ButtonGroup

## When to use

Use for two or more related actions with a shared accessible group name. Each item contains an ID and the existing serializable Button contract; onAction receives the activated ID.

Source story evidence (not installed): src/components/button-group/button-group.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Use RadioGroup for one-of-many selection, Tabs for panels, and NavigationMenu for page links. This is not a toolbar with roving focus. Split buttons, arbitrary child controls, separators, and mixed-size buttons are not exposed.

## States

Each enabled button stays in normal tab order and uses native activation. Disabled and loading states follow Button; loading keeps focus and blocks activation. Nested button input is validated against the authoritative Button schema at render time. Do not combine loading and disabled. Native submit/reset types retain their form behavior; avoid duplicating work between onAction and form submission.

## Content

Use related action verbs and unique IDs. Limit group size; long labels wrap within shrinking buttons. Choose vertical orientation when horizontal actions become hard to scan. The group name describes the purpose, not a replacement for each visible button label.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/button-group.tsx
Dependencies: button

## Catalog base

Wraps catalog ButtonGroup and system Button. Only sizing overrides are added so the group and its children fit their parent. Button variants, defaults, invalid combinations, and semantics come from the existing Button contract rather than a second schema.

## API

API schema: ../schemas/button-group.schema.json

## Tokens

Semantic tokens: background, border, foreground, input, muted, primary, primary-foreground, ring

## Themes

Inherits regional roles through its system Buttons. SchemeMatrix shows every configured scheme for the selected brand and mode. LongContent verifies wrapping in a narrow container.

Source story evidence (not installed): src/components/button-group/button-group.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

Reference: [upstream behavior and accessibility](https://ui.shadcn.com/docs/components/radix/button-group).
