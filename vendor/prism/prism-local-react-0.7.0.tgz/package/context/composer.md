# Composer

## When to use

Use for composing one item of text, such as a note, comment or message: a multiline field in a bordered panel, with an optional toolbar above the text and actions below it. It is the main entry point of a product screen's task panel.

Source story evidence (not installed): src/components/composer/composer.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Not for a form with several fields; use TextField and Textarea. Not for formatted text: use RichTextComposer, which shares the panel but accepts a structured JSON document. Composer remains string-based; its toolbar must not imitate formatting commands. Not for search; use SearchField.

## States

The panel shows one focus ring when the text has focus. `disabled` and `readOnly` follow native behavior. `error` sets `aria-invalid` and is associated with the text by `aria-describedby`; `description` stays visible beside an error. Toolbar and action controls keep their own focus, disabled and loading states. Keyboard order follows the DOM: header actions, toolbar, text, then secondary and primary actions. `busy` locks text editing and built-in Clear/Undo while keeping loading actions visible. Slot actions remain host-owned: disable them explicitly when disabled or busy. `readOnly` hides mutation slots and Clear/Undo; text remains selectable. `submissionError` announces failed requests without setting `aria-invalid`.

## Content

A label is always rendered and is the accessible name. `labelVisibility="hidden"` removes it from view when visible context already names the composer, such as one composer under a "Note" heading, and the accessibility profile allows it. Fill `toolbar` with IconButtons (each with a label) and `actions` with a Button, such as "Send note". The `headerActions`, `toolbar`, `secondaryActions` and `actions` slots are React-only and wrap on narrow screens. Empty rows collapse. The visible label belongs inside the header. `rows` sets the minimum height; `maxRows` bounds growth using current typography, then the field scrolls. Without `maxRows`, the limit is the greater of `rows` and 12. Long labels wrap. A required field must have a visible label. `maxLength` uses native UTF-16 code-unit counting; externally supplied content is never silently truncated.

## Draft recovery and host behavior

`clearable` is opt-in. Clear and Undo use low-prominence ghost buttons. Empty drafts hide Clear. Clear snapshots the text and replaces it with an empty string; Undo remains available until typing, external nonempty replacement, form reset, disabling, entering busy/read-only, or turning off clearable. Clear/Undo restore editor focus. Native undo may also restore text; any input event invalidates the component snapshot to avoid overwriting newer content. No recovery timer runs.

For controlled drafts, use `value` and `onValueChange(nextText)` when enabling Clear. This callback reports both typing and Clear/Undo; optional `onChange` reports native input events only. Existing controlled `value`/`onChange` usage remains valid without Clear. Uncontrolled usage accepts `defaultValue` and optional `onValueChange`; native form reset restores its default. Ref, name and form association reach the textarea. Replace the component key when switching between draft identities, including an empty draft, so recovery cannot cross documents.

The host owns submission, retries, timestamp meaning and success resets. Enter inserts a newline; Composer does not intercept it. A host modifier+Enter shortcut must ignore composing input. Preserve the draft on failure, provide Retry through actions and reset only the submitted draft on success. Supply `status` for real feedback; do not imply autosave. The note-capture screen demonstrates a labeled timestamp Checkbox through secondaryActions. Rich text and image lifecycle behavior remain separate work.

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/input-group.tsx, src/components/ui/field.tsx
Dependencies: button

## Catalog base

Wraps catalog `input-group` (`src/components/ui/input-group.tsx`). Uses InputGroup and InputGroupTextarea, plus catalog Field semantics. Native header/toolbar/action containers replace addons so a label or checkbox click does not inherit the addon input-focus handler. The inline addons, text, input control and button sizes are not exposed. Overrides: the panel uses `rounded-panel` so each grouping level has one shape role; focus and invalid rings use the full-strength ring role across regional schemes; the text keeps the checked foreground on tinted fields. The catalog dims the whole panel when any descendant is disabled, so a disabled action such as an empty Send would dim everything and fail contrast; the wrapper removes group dimming while the disabled textarea retains its native catalog styling. Explicit sizing replaces catalog field sizing; the panel owns padding and the editor removes duplicate horizontal padding. Text styles are shared with Textarea's registered typography slots, so the two stay identical.

## API

API schema: ../schemas/composer.schema.json

## Tokens

The resting outline uses the shared input role, aliased to border, uniformly on every edge. Focus and validation retain their dedicated indicators. The panel uses the existing surface.container / content.on-container roles through card / card-foreground utilities. The solid container fill replaces the catalog input-border tint, keeping dark Composer between the canvas and stronger muted fills.

Semantic tokens: card, card-foreground, foreground, border, destructive, input, muted-foreground, ring

## Themes

The panel uses the input and border roles, with destructive for the invalid state and the ring role for focus, so it adapts to the containing scheme.

Source story evidence (not installed): src/components/composer/composer.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.
