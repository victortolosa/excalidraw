# Button

Component ID: `button`. Status: experimental.

Button triggers an action on the current page or submits a form. It wraps the shadcn catalog Button, which renders a native `<button>`, so Enter and Space activate it and forms submit normally.

Source story evidence (not installed): src/components/button/button.stories.tsx#Primary. See packaged agent recipes for executable examples.

## When to use

- Use `primary` for the single most important action in a region, such as saving a form.
- Use `secondary` for alternative actions, such as cancelling.
- Use `ghost` for low-prominence utility actions, such as Composer Clear/Undo. It has no resting fill or visible border; hover reveals a muted background and keyboard focus retains the full ring.
- Use `type: "submit"` only for the button that submits its form.

## When not to use

- Navigation to another page or location: use a link.
- Toggles or menus: use the component that expresses that behavior. For a familiar compact action without visible text, use IconButton.
- Destructive or brand-specific styling: there is no destructive variant, and styling overrides are not accepted.

Source story evidence (not installed): src/components/button/button.stories.tsx#Secondary. See packaged agent recipes for executable examples.

Source story evidence (not installed): src/components/button/button.stories.tsx#Ghost. See packaged agent recipes for executable examples.

## States
The `destructive` variant marks an irreversible action using destructive text and a tinted fill, with explicit action wording. It shares normal, disabled and loading behavior. It does not supply confirmation by itself; use Dialog when a decision is required.

- `disabled`: the action is unavailable. The button is removed from the tab order, so explain nearby why the action is unavailable.
- `loading`: the action is in progress. The button keeps focus, sets `aria-disabled`, and ignores clicks and implicit form submission. Change the label to describe the progress, such as "Saving…". Announce the result with a status message outside the button.
- Invalid combinations are rejected by the schema and the TypeScript types:

Invalid combinations: [{"not":{"required":["disabled","loading"],"properties":{"disabled":{"const":true},"loading":{"const":true}}}},{"if":{"required":["iconPosition"]},"then":{"required":["icon"]}}]

Source story evidence (not installed): src/components/button/button.stories.tsx#Loading. See packaged agent recipes for executable examples.

## Content

The visible text label is the accessible name. Write it as a verb phrase that describes the result. Long labels wrap within the available width, with no truncation.

Source story evidence (not installed): src/components/button/button.stories.tsx#LongLabel. See packaged agent recipes for executable examples.

### Choose text or an icon

Use IconButton for recognizable compact actions such as Settings, Close, or editing a clearly identified row. Keep Button text when the action or target needs explanation. A pencil means editing existing content; choosing a different destination should retain a visible label such as “Change destination”. Do not remove labels solely to fit mobile widths: allow text actions to wrap or move below the heading.

IconButton's required `label` supplies its accessible name. A Tooltip can supplement a familiar icon, but understanding the action must not depend on hover. Preserve the supported target size and keyboard focus.

See [W3C accessible naming guidance](https://www.w3.org/WAI/ARIA/apg/practices/names-and-descriptions/) and [Atlassian icon-action guidance](https://atlassian.design/components/button/link-icon-button/usage).

## Implementation origin

Origin: shadcn-wrapper. src/components/ui/button.tsx, src/components/ui/spinner.tsx
Dependencies: none

## Catalog base

Button renders `src/components/ui/button.tsx` unmodified. The contract narrows it for reliable generation and design-tool parity:

- `primary` maps to the catalog `default` variant and `secondary` to `outline`, and `ghost` to `ghost`. The catalog's `link`, `destructive`, and catalog `secondary` variants, its sizes, and `asChild` are not exposed.
- There is one size. Padding, gap, radius, and type come from the button component tokens instead of the catalog's fixed sizes, and height grows so long labels wrap.
- Focus uses the full-strength `ring` role instead of the catalog's 50% ring, because only the full-strength role is contrast-checked.
- Loading adds the catalog Spinner, hidden from assistive technology, and blocks activation.

Upstream catalog updates reach Button through `catalog:update`. Exposing another catalog variant starts in the contract.

Ghost uses foreground text and solid muted hover roles, including dark mode, to preserve contrast inside tinted panels. Secondary dark backgrounds use solid background and hover muted roles; catalog input opacity fills compound inside tinted panels and can fail text contrast.

## API

Generated from the serializable contract in `button.contract.ts`. The same contract validates fixtures and model-produced JSON.

API schema: ../schemas/button.schema.json

### React-only API

The React component also accepts `ref`, `id`, `name`, `value`, `form`, `onClick`, `onFocus`, `onBlur`, and `aria-describedby`. These are executable or document-specific. They are not in the serializable schema. `className`, `style`, and `aria-label` are deliberately excluded. Arrange layout in the parent, and keep the visible label as the accessible name.

## Tokens

Generated from `button.meta.ts`. A unit test checks that this list matches the classes used by the implementation.

Semantic tokens: primary, primary-foreground, background, foreground, border, input, muted, ring, destructive

Size and type come from the button component tokens: {Object.keys(themes.components.button).map(name => `button.${name}`).join(', ')}. Values are in `tokens/components/button.json`. `button.radius` follows the theme radius unless overridden. Designers can edit them in Foundation/Theme editor in local Storybook.

Hover, active, and disabled styling come from the catalog Button. Focus uses a 3px ring in the `ring` role. On dark bases, secondary uses the `input` role for its border and a translucent fill, as the catalog does.

## Themes

The same markup renders in every brand, mode, and scheme. Radius and type come from the brand through the button component tokens. Colors come from the scheme's roles, so on emphasis the primary Button becomes a white fill with brand-colored text. Button has no scheme prop: set `data-scheme` on a container.

Source story evidence (not installed): src/components/button/button.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.

## Decorative action icons

Optional icon uses the shared deliberate action glyph vocabulary. iconPosition selects start/end (start by default). Position requires an icon. Glyphs are decorative and the visible string label remains the accessible name. Icons do not make Button a navigation link or pressed-state toggle. Loading shows the spinner and retains the action glyph.

Source story evidence (not installed): src/components/button/button.stories.tsx#Icons. See packaged agent recipes for executable examples.

## Navigation CTA rendering

Hero and SiteHeader expose supported navigation CTAs backed by navigation-cta.contract.ts and navigation-cta.tsx. Their anchors reuse the catalog variant definitions and shared button-styles.ts token sizing. Button itself remains an action/submit control. Navigation prominence is independent of semantics: a filled primary CTA may still be a native link. Do not replace href with an onClick redirect or wrap a button in a link.

Reference: [W3C styled navigation links](https://design-system.w3.org/styles/links.html).

## Component typography

Edit existing values in Foundation/Theme editor in local Storybook. Shared component sources affect every brand; brand component sources affect that brand. Validate the draft and save token sources.

<ComponentTypographyTable component="button" />
