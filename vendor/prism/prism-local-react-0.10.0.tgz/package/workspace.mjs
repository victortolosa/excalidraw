import { existsSync, readdirSync } from 'node:fs'
import { basename, resolve } from 'node:path'

const ignored = ['node_modules', '.git']
const childDirectories = base => { try { return readdirSync(base, { withFileTypes: true }).filter(entry => entry.isDirectory() && !ignored.includes(entry.name)).map(entry => resolve(base, entry.name)) } catch { return [] } }
const segmentsOf = pattern => pattern.replaceAll('\\', '/').replace(/^(?:\.\/)+/, '').replace(/\/+$/, '').split('/')

// Expands one workspace pattern (literal paths, `*` within a segment, and `**` for any depth) to existing directories under base.
function expand(base, segments) {
  if (!segments.length) return existsSync(base) ? [base] : []
  const [head, ...rest] = segments
  if (head === '**') return [...expand(base, rest), ...childDirectories(base).flatMap(child => expand(child, segments))]
  if (head.includes('*')) {
    const matcher = new RegExp(`^${head.split('*').map(part => part.replace(/[.+?^${}()|[\]\\]/g, '\\$&')).join('[^/]*')}$`)
    return childDirectories(base).filter(child => matcher.test(basename(child))).flatMap(child => expand(child, rest))
  }
  return expand(resolve(base, head), rest)
}

// Member directories of an npm or Yarn workspace root, from its manifest's `workspaces` field.
// Patterns that are absolute or climb out of the project are ignored, and `!` patterns exclude.
export function workspaceDirectories(root, manifest) {
  const patterns = (Array.isArray(manifest.workspaces) ? manifest.workspaces : manifest.workspaces?.packages ?? [])
    .filter(pattern => typeof pattern === 'string' && !pattern.startsWith('/') && !segmentsOf(pattern.replace(/^!/, '')).includes('..'))
  const members = new Set()
  for (const pattern of patterns.filter(pattern => !pattern.startsWith('!'))) for (const directory of expand(root, segmentsOf(pattern))) members.add(directory)
  for (const pattern of patterns.filter(pattern => pattern.startsWith('!'))) for (const directory of expand(root, segmentsOf(pattern.slice(1)))) members.delete(directory)
  return [...members]
}
