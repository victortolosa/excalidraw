# @prism-local/react

## 0.10.0

### Minor Changes

- b0ee96d: Tighten Hero heading validation and document every Hero field. `heroSchema` now rejects `breakBefore` on the first heading segment, and adjacent Latin, Cyrillic, Greek or numeric segments that would join two words without a space. Emphasized segments now render as `em`, and the H1 takes its accessible name from its visible text instead of a duplicate `aria-label`. Appearance is unchanged.

  Migration: no action is needed for existing React usage, because the package exports `Hero` and its props but not `heroSchema`, and these rules are not in the JSON Schema or TypeScript props. Tests or tools that target the H1's previous inner `span` elements should use the heading role and text instead. Input validated against `heroSchema` in this repository may now fail: remove `breakBefore` from a first segment, and add a space to adjacent segments, such as `{text:'Less '}` followed by `{text:'chasing'}`. Mid-word emphasis in these scripts is no longer accepted.

- 3e9200c: Tighten validation and fix rendering found by describing every field of every supported component and block. All schema fields now have a plain description.

  Validation that now rejects input it used to accept:
  - `Select`, `RadioGroup` and `Combobox` reject duplicate option `value`s, and a `defaultValue` that matches no option.
  - `Breadcrumb` ancestor `href` follows the NavigationMenu rule: `javascript:` and protocol-relative `//host` addresses are rejected.
  - `Table` rejects a column whose key exists only on the object prototype, such as `toString`, when rows don't have their own value for it.

  Rendering and behavior changes:
  - `RadioGroup` ties an option's description to its radio with `aria-describedby`, and builds option ids from position (`<group id>-option-<n>`) instead of from the option value.
  - `Select` and `RadioGroup` now pass their `form` prop to the control. It was accepted and ignored.
  - `RichTextComposer` marks its hidden form input disabled when the composer is disabled, so a disabled composer no longer submits its value.
  - `Carousel` moves keyboard focus to the other control when the focused Previous or Next button becomes disabled at either end. It used to drop to the page.
  - `Avatar` initials ignore bracketed text and leading punctuation: `Ada (admin)` is `A`, not `A(`.

  SignupForm, Carousel and other changes decided after the audit:
  - `SignupForm` callbacks may resolve `{ ok: false, message }` to show a specific failure as an alert and keep the values. A rejection still shows the generic text. New optional fields: `headingLevel`, `passwordMinLength` and ten message fields (`nameError`, `emailError`, `passwordError`, `confirmationError`, `mismatchError`, `invalidMessage`, `submittingMessage`, `providerPendingMessage`, `submitFailure`, `providerFailure`). `passwordDescription` no longer has a schema default; the default hint now names `passwordMinLength`. The `<form>` no longer has an `aria-label`.
  - `Carousel` has optional `previousLabel`, `nextLabel`, `positionLabel` and `slideLabel`. The two templates must keep their `{current}`, `{total}` and `{label}` placeholders.
  - `Section` rejects `headingLevel` or `titleStyle` set to a non-default value without a `title`.
  - `ToastProvider`'s `show` throws a `RangeError` for a `duration` outside 5000 to 30000.
  - `Dialog` disables Cancel and ignores Escape and the close button while a confirm is running.
  - `Combobox` no longer sets `aria-label` on its input, and `SearchField` hides the browser's own cancel button.

  Migration: no action is needed for typical use. Remove duplicate option values and fix any `defaultValue` that names no option. Replace `Breadcrumb` hrefs such as `javascript:...` with real destinations; relative paths need a leading `/`. Tests that select a radio option by its old id (`<group id>-<value>`) should use the label or role instead. Code that relied on `Select` or `RadioGroup` ignoring `form` now submits with the named form. Remove `headingLevel` and `titleStyle` from any `Section` without a title. Catch the `RangeError` from `show`, or fix the duration. A JSON consumer that read the `passwordDescription` default from the schema should read `passwordMinLength` instead.

### Patch Changes

- cbe4097: Tighten SignupForm validation and document every field. The email is now trimmed before validation, so a stray leading or trailing space no longer fails with "Enter a valid email address", and the submitted email is trimmed. `signInHref` now accepts `/`, and rejects `https://` with no host, whitespace and `/\host`. Appearance is unchanged.

  Migration: no action is needed for typical use. Callers that pass `signInHref` values such as `https://` or paths containing spaces will now fail validation and should use a complete address or encode the spaces. Code that relied on an untrimmed submitted email should trim or normalize on its own.

## 0.9.5

### Patch Changes

- `prism-setup` now writes a blank line between the `prism:skill` marker and the heading in the skill adapters it generates, so Markdown formatters such as Prettier leave them unchanged. Re-running setup on an existing project rewrites those adapters once.

## 0.9.4

### Patch Changes

- `prism-setup` now writes blank lines inside its managed `AGENTS.md` and `CLAUDE.md` block markers, so Markdown formatters such as Prettier leave the block unchanged and a project's formatting check does not fail after setup. Re-running setup on an existing project rewrites the block once to the new form.

## 0.9.3

### Patch Changes

- `prism-setup` now works in npm and Yarn workspaces where a member package declares Prism, as `prism-check` already did, so the managed `AGENTS.md`, `CLAUDE.md` and skill adapters can be added to a workspace project. An existing `prism:check` script is still preserved. `prism-check` now skips compiled output folders (`dist`, `build`, `out`, `coverage`, `generated`, `.next`) while walking a source root and lists each one it ignored as `Ignored build output`, so a broad `--source` no longer reports thousands of findings from bundles. A folder passed explicitly with `--source` is still checked.

## 0.9.2

### Patch Changes

- `prism-check --boundary` now reports how many source files it skipped inside the declared boundaries, counting each file once, including files pruned from the source walk. Previously the count covered only import statements, so a boundary holding many files could pass with no number shown. The documentation also states that imports made from inside a boundary are not followed. The workspace-aware dependency check now understands `**` and nested `*` patterns and `!` exclusions in the `workspaces` field, so a Prism dependency declared in such a member is no longer reported missing.

## 0.9.1

### Patch Changes

- Add a `--boundary <directory>` flag (repeatable) to `prism-check` for projects that adopt Prism in only part of their tree. Imports are still followed, so a violation hidden behind a local file is still caught, but files inside a declared boundary are not checked, and every boundary is printed so a pass cannot hide how much was skipped. Boundaries are never applied by default, so full-Prism projects keep the same strictness. The consumer dependency check is also now workspace-aware: the Prism dependency (and any catalog bypass) is found in a workspace member's `package.json`, not only the root manifest.
- Make the built package publishable to GitHub Packages. It no longer carries the `private` flag and targets `https://npm.pkg.github.com`. Components, tokens and tarball installs are unchanged.

## 0.9.0

### Minor Changes

- ca08b1d: `prism-check` now rejects more bypasses, so an app that passed before may fail. New failures cover direct Radix and Base UI use, arbitrary spacing, radius and type classes, chosen values in inline styles, SVG attributes and CSS, token redefinition, class names built by joining text, styling through `createElement` or `cloneElement`, native form controls where Prism has a component, faked control roles, and click handlers on non-interactive elements. Migrate by using a supported component or token. For a reviewed temporary exception, add `prism-allow <code>: <reason>` on or above the line; the check lists each one in its output.

## 0.8.4

### Patch Changes

- 3af8c3e: Hi-fi screens now carry a `NOTES.md` beside the code in `src/screens/<task>/`, written as the agent works: a mapping of screen parts to components with a fit rating, gaps with the user's decision and what the design needed, and poor fits with the workaround and the change that would fix them. Temporary placeholders are marked `FPO(<name>)` in code so they can be found and removed. The wireframe's `GAPS.md` seeds it and stays unchanged, and `prism-build` carries the notes into its audit. Guidance only; no API or visual changes.
- 3af8c3e: New starter projects no longer include the Account settings sample as their home page. The starter is a minimal Prism page, and its `npm run validate` checks that page's rendering, theme accessibility, density and responsive overflow. The account-settings composition is still shipped as a recipe in `agent/recipes`. Existing projects are unaffected; delete the sample from a project created earlier if you do not want it.

## 0.8.3

### Patch Changes

- 3983342: Add a hi-fi route to the shipped `prism-explore` skill and a compact component index. Asking for "hi-fi", "high fidelity" or a "prototype" now builds from the installed components and theme, starting from the wireframe's layout, copy and data, with no hand-written colors, icons or component CSS. The agent reads a component's guidance before calling it a gap and, when a part has no component, stops and asks whether to build it into the system, use a labeled temporary placeholder, or change the design. Wireframes still mock gaps and keep going. Hi-fi and build screens go in `src/screens/<task>/`, not in `exploration/`, and an agent no longer calls a wireframe approved without your say-so. Layout is checked by measuring, and nothing is published unless asked.

  New `agent/components.md` lists every installed component and block with a one-line use and a link to its guidance, so agents no longer need to read the full `agent/manifest.json`. No API or visual changes; the installed guidance updates with the package.

## 0.8.2

### Patch Changes

- Update the shipped `prism-explore` skill and exploration design guidance (`agent/design.md`). Exploration is now wireframe fidelity by default and kept to the bare minimum: the primary journey only, with extra states, screens or variants added when the user asks. Existing system components, APIs and tokens are information, not constraints, and a missing component is mocked and noted as a gap instead of stopping the exploration. Consistency, shared components and tokens remain the `prism-build` skill's responsibility. No API or visual changes. Rerun `prism-setup` is not required; the installed guidance updates with the package.

## 0.8.1

### Patch Changes

- Pin the starter to Vite 8.3.5, which resolves the high severity dev-server advisories reported by `npm audit` against 8.3.1. Existing projects can run `npm install -D vite@8.3.5`.

## 0.8.0

### Minor Changes

- 428e98c: Ship a `prism-explore` skill and exploration design guidance with the package. `prism-setup` now installs `prism-build` and `prism-explore` adapters under both `.agents/skills` and `.claude/skills`, preserving custom skills, and the installed instructions route agents between them. The exploration scaffold and wireframe kit are not included. The `prism-page` skill is renamed `prism-build`: rerun `prism-setup` after upgrading to replace its generated adapter. Custom `prism-page` skills are left in place, and project text that names the old skill needs updating by hand.
- 04c9879: Tighten Hero heading validation and document every Hero field. `heroSchema` now rejects `breakBefore` on the first heading segment, and adjacent Latin, Cyrillic, Greek or numeric segments that would join two words without a space. Emphasized segments now render as `em`, and the H1 takes its accessible name from its visible text instead of a duplicate `aria-label`. Appearance is unchanged.

  Migration: no action is needed for existing React usage, because the package exports `Hero` and its props but not `heroSchema`, and these rules are not in the JSON Schema or TypeScript props. Tests or tools that target the H1's previous inner `span` elements should use the heading role and text instead. Input validated against `heroSchema` in this repository may now fail: remove `breakBefore` from a first segment, and add a space to adjacent segments, such as `{text:'Less '}` followed by `{text:'chasing'}`. Mid-word emphasis in these scripts is no longer accepted.

- 01da2ff: Tighten validation and fix rendering found by describing every field of every supported component and block. All schema fields now have a plain description.

  Validation that now rejects input it used to accept:
  - `Select`, `RadioGroup` and `Combobox` reject duplicate option `value`s, and a `defaultValue` that matches no option.
  - `Breadcrumb` ancestor `href` follows the NavigationMenu rule: `javascript:` and protocol-relative `//host` addresses are rejected.
  - `Table` rejects a column whose key exists only on the object prototype, such as `toString`, when rows don't have their own value for it.

  Rendering and behavior changes:
  - `RadioGroup` ties an option's description to its radio with `aria-describedby`, and builds option ids from position (`<group id>-option-<n>`) instead of from the option value.
  - `Select` and `RadioGroup` now pass their `form` prop to the control. It was accepted and ignored.
  - `RichTextComposer` marks its hidden form input disabled when the composer is disabled, so a disabled composer no longer submits its value.
  - `Carousel` moves keyboard focus to the other control when the focused Previous or Next button becomes disabled at either end. It used to drop to the page.
  - `Avatar` initials ignore bracketed text and leading punctuation: `Ada (admin)` is `A`, not `A(`.

  SignupForm, Carousel and other changes decided after the audit:
  - `SignupForm` callbacks may resolve `{ ok: false, message }` to show a specific failure as an alert and keep the values. A rejection still shows the generic text. New optional fields: `headingLevel`, `passwordMinLength` and ten message fields (`nameError`, `emailError`, `passwordError`, `confirmationError`, `mismatchError`, `invalidMessage`, `submittingMessage`, `providerPendingMessage`, `submitFailure`, `providerFailure`). `passwordDescription` no longer has a schema default; the default hint now names `passwordMinLength`. The `<form>` no longer has an `aria-label`.
  - `Carousel` has optional `previousLabel`, `nextLabel`, `positionLabel` and `slideLabel`. The two templates must keep their `{current}`, `{total}` and `{label}` placeholders.
  - `Section` rejects `headingLevel` or `titleStyle` set to a non-default value without a `title`.
  - `ToastProvider`'s `show` throws a `RangeError` for a `duration` outside 5000 to 30000.
  - `Dialog` disables Cancel and ignores Escape and the close button while a confirm is running.
  - `Combobox` no longer sets `aria-label` on its input, and `SearchField` hides the browser's own cancel button.

  Migration: no action is needed for typical use. Remove duplicate option values and fix any `defaultValue` that names no option. Replace `Breadcrumb` hrefs such as `javascript:...` with real destinations; relative paths need a leading `/`. Tests that select a radio option by its old id (`<group id>-<value>`) should use the label or role instead. Code that relied on `Select` or `RadioGroup` ignoring `form` now submits with the named form. Remove `headingLevel` and `titleStyle` from any `Section` without a title. Catch the `RangeError` from `show`, or fix the duration. A JSON consumer that read the `passwordDescription` default from the schema should read `passwordMinLength` instead.

### Patch Changes

- 0779959: Tighten SignupForm validation and document every field. The email is now trimmed before validation, so a stray leading or trailing space no longer fails with "Enter a valid email address", and the submitted email is trimmed. `signInHref` now accepts `/`, and rejects `https://` with no host, whitespace and `/\host`. Appearance is unchanged.

  Migration: no action is needed for typical use. Callers that pass `signInHref` values such as `https://` or paths containing spaces will now fail validation and should use a complete address or encode the spaces. Code that relied on an untrimmed submitted email should trim or normalize on its own.

## 0.7.0

### Minor Changes

- Support star favorites in Toggle with stable accessible names and keyboard/state/theme coverage. Remove color transitions from Button, SearchField, TextField, Select, Tabs and Toggle so theme changes retain contrast. Support React and React DOM ^19.0.0, verified with the Excalidraw app's React 19.0.0 and matching types in the packed consumer.

  Add an icon-only DropdownMenu trigger, a focus-preserving pending Toggle state, controlled SearchField clearing, and destructive Button/Dialog confirmation. Existing defaults remain unchanged. Toast outcomes use existing variants; action/Undo support remains deferred.

  Migration: new props are opt-in. Set DropdownMenu trigger="icon" with a contextual label; own Toggle pending and saved state in the app; provide SearchField onClear with controlled value/onChange; choose Dialog confirmVariant="destructive" for irreversible actions and provide a surviving returnFocusRef when deletion removes the trigger.

## 0.6.0

### Minor Changes

- efd54ec: Add explicit Markdown input/output to RichTextComposer with `format="markdown"`, string value/defaultValue and string onValueChange callbacks. JSON remains the default and existing JSON consumers require no migration. Both formats use the same visual formatting toolbar, selection, Clear/Undo, form reset and editor history. The ref adds getMarkdown(); getDocument() remains JSON in both modes. Hidden form values use the selected format.

  Markdown supports the existing toolbar subset: headings 1–3, bold, italic, lists, hard breaks and safe links. Unsupported syntax is rejected, and serialization normalizes whitespace and delimiter choices. This does not preserve raw Markdown source byte for byte or add image/code/table support. The Markdown parser is pinned to the existing Tiptap editor version.

## 0.5.0

### Minor Changes

- 8448c8b: Add a decorative Badge `indicator` (`dot` or `sync`; the sync icon animates only when motion is allowed) and a React-only Alert `action` slot for one Button or link, rendered below the text.
- 8448c8b: Add Card headingless mode and Section `titleStyle`. Card `title` is now optional in its schema: provide exactly one of `title` or `label` (an accessible name, with no description); existing cards with a title are unchanged, but generated JSON Schemas no longer list `title` as required. Section `titleStyle` is `default` or `label`; `label` uses a new registered typography slot (`section.label-*`), so consumers with their own token files must add it from `tokens/components/section.json`.
- 8448c8b: Add Composer, a multiline panel wrapping the catalog input group with an internal labeled header and React-only headerActions, toolbar, secondaryActions and actions slots. It shares Textarea typography, grows from rows to maxRows, distinguishes submission feedback from validation, and supports optional Clear with persistent Undo.

  Existing value/onChange usage remains supported. Controlled Clear/Undo requires onValueChange for string updates; onChange continues to report native input events only. Read-only hides mutation slots; busy locks editing while leaving host-owned loading actions visible. No image-upload lifecycle is included.

  Add RichTextComposer as a separate entry sharing Composer’s panel. It accepts allowlisted structured JSON and supports bold, italic, lists, link editing, keyboard toolbar navigation and editor history. Plain-text Composer retains its string API and does not import the editor engine. Images remain outside this release scope. Heading levels 1–3 use a split toolbar button: toggle the selected level on/off or choose Paragraph or a heading level from its dropdown. Structured documents preserve heading levels.

  Fix secondary Button contrast inside tinted panels by using solid dark background and hover roles instead of stacking catalog opacity fills.

  Expose the supported ghost Button variant for low-prominence utility actions, and use it for Composer and RichTextComposer Clear/Undo.

  Use the existing container surface roles for both Composer panels instead of a border-derived translucent input fill, reducing dark-mode prominence.

  Soften the shared border token and its input/sidebar-border aliases across all components, including TextField and both Composers. Composer uses one opaque outline color on every edge. Focus and validation tokens are unchanged. The fallback chart-4 color inherits border. Custom themes can retain their existing border values; the default theme updates light, dark and emphasis outline colors.

- 8448c8b: Add Item and ItemGroup for repeated list rows: title, supporting line, status text and a trailing actions slot, with plain and outlined variants. Title, description and status are registered typography slots (`item.title-*`, `item.description-*`, `item.status-*`); consumers with their own token files must add them from `tokens/components/item.json`.
- 8448c8b: Add `labelVisibility` (`visible` or `hidden`) to TextField, Textarea, Select, Combobox and SearchField. A hidden label stays the accessible name and is only removed from view. Hidden combined with `required` is rejected for fields that have `required`. Use it only when visible context already names the field.
- 8448c8b: Add composed Tabs pieces (`TabsRoot`, `TabsList`, `TabsPanel`) so a tab list can sit in a page header while panels render elsewhere in the same root, and a `size` option (`default` or `sm`) that tightens horizontal padding. Existing `Tabs` is unchanged. Add the `arrow-up-right` action icon.

## 0.4.0

### Minor Changes

- Make Toast runtime validation opt-in through a separate validator entry. Ship Tailwind source and component dependency source manifests for app-sized CSS. Emit local font files separately from CSS and use the source workflow in the React starter.
- Make Page header actions wrap according to available space by default, independent of description length. Add inline and stacked action layouts and guidance for choosing icon-only versus text actions. Migration: existing Page headers now use content-driven wrapping instead of forced mobile stacking; set actionsLayout="inline" for compact actions or "stacked" for a dedicated action row at every width.

### Patch Changes

- optimizations

## 0.3.1

### Patch Changes

- fixes

## 0.3.0

### Minor Changes

- Optimized library for composable use

### Patch Changes

- Preserve ES module boundaries so unused components can be removed from consumer bundles. Add typed component and block subpath imports while retaining root imports.
- Separate authoritative rendering defaults and helpers from schema construction so ordinary components do not load Zod. Preserve schema exports, inferred types and runtime validation in ButtonGroup, Toast and SignupForm.

## 0.2.0

### Minor Changes

- Export all 33 completed Prism components and both supported blocks, with React types, portable guidance, schemas and matching consumer discovery.

### Patch Changes

- exporting all components

## 0.1.6

### Patch Changes

- Fixed tab text length behavior. Truncates no longer break lines.

## 0.1.5

### Patch Changes

- Ship release-matched agent discovery, generated consumer rules, audit policy/template, a portable page skill and an executable composition recipe. Add prism-setup to connect existing project instructions and a project skill without replacing user rules or validation. Include experience/platform/viewport selection guidance and validate packaged links, release identity and setup across consumer updates.

## 0.1.4

### Patch Changes

- Preserve the starter's Git ignore rules inside packed releases and restore them during bootstrap. Ignore local update locks/history while keeping vendored releases available to other checkouts.

## 0.1.3

### Patch Changes

- Ship a matching React/Vite starter and pinned toolchain inside the local release. Verify staged consumer updates and rollback, CSS module typing, and settled theme accessibility checks. Keep component implementations and token ownership unchanged.

## 0.1.2

### Patch Changes

- Extend consumer checks for literal visual values, unknown semantic roles and explicit Prism styling overrides. Include release notes for staged consumer updates. Add an independent React/Vite starter and local update/rollback workflow.

## 0.1.1

### Patch Changes

- Add the portable prism-check command to reject direct shadcn dependencies, catalog imports, private Prism subpaths, and recognized local catalog copies in consumer source. The check reports source locations and fails on computed module loading it cannot inspect.
