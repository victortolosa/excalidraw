# Hero

## When to use

Introduce a page with one H1 and optional eyebrow, description and paired actions. Choose centered text, centered text above full-width media, or split text/media. Prism-authored custom block composed from supported Button and semantic structure.

Source story evidence (not installed): src/blocks/hero/hero.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Not a site header, full page, secondary section heading, carousel, video player or arbitrary styling surface. Page owns the main landmark. Keep navigation, proof rows and product behavior outside Hero.

## States

Static introduction. Caller owns pendingAction; matching action shows loading and prevents activation. Other callback actions are disabled during pending work. Navigation remains a native link. Missing onAction disables callback actions with no explanation, so JSON-only consumers should use link actions.

## Content

Required headingId identifies the H1. Ordered heading segments support semantic primary emphasis and a deliberate line break. Preserve readable wording across breaks. Segments join exactly as written, so include spaces between words; the first segment cannot use breakBefore. Eyebrow is a short line above the heading in small uppercase text, so keep it to a few words. Image alt is descriptive for informative images and empty for decorative images; intrinsic dimensions prevent layout movement. Never put essential text exclusively inside media.

## Composition

Use Page labelledBy matching headingId and the React header slot. Omit Page title/description/actions; exactly one H1 must name the main landmark. Centered excludes media, centered-media and split require it. Images and custom mediaContent are mutually exclusive; slot media requires a visible, accessible supported composition, and its label is a screen reader name that is not shown. Media fills its area: images scale to its width and narrow slot content sits at the start. Split stacks text first on mobile. Secondary action requires primary; callback IDs must be distinct. Action and link icons appear after the label. React onAction(id), pendingAction and mediaContent stay outside JSON.

Source story evidence (not installed): src/blocks/hero/hero.stories.tsx#PageIntegration. See packaged agent recipes for executable examples.

## Implementation origin

Custom block authored by Prism. No corresponding shadcn Hero was found in the official registry assessment. Uses shadcn-backed Button through the system API; native semantic HTML and token-based Tailwind layout provide structural scaffolding. Design rationale and scope are in docs/project/hero-block-plan.md. No vendor snapshot or third-party source is claimed.

## Catalog base

Supported Button supplies accessible callback action behavior and glyphs. Navigation uses native links with the same token-backed CTA treatment as Button: primary is filled, secondary outlined. The action slot determines prominence independently of whether it navigates or invokes a callback. Link actions support the shared decorative icon vocabulary. No catalog imports, application routing or product services.

## API

API schema: generated/schemas/hero.schema.json

Zod also rejects duplicate callback action IDs, breakBefore on the first heading segment, and adjacent heading segments that would join two words without a space, refinements not expressed by JSON Schema. The space check covers Latin, Cyrillic and Greek text and digits, so mid-word emphasis in those scripts is not supported. Callers validate serializable input with the contract; runtime TypeScript requires mediaContent for slot media. Browser review enforces single-H1 relationships.

## Tokens

Inherits regional scheme; foreground, muted-foreground, primary and ring roles. Semantic section/stack spacing and heading/body type ramp. No new token names or brand logic.

## Themes

Both modes and all configured schemes. Split switches to two columns at the shared medium breakpoint. Long content and actions wrap at 320px.

Source story evidence (not installed): src/blocks/hero/hero.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.
