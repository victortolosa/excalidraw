# SignupForm

## When to use

Use for account creation with name, email, password confirmation, Google signup and a supplied sign-in destination. Supported block composed from Card, TextField and Button.

Source story evidence (not installed): src/blocks/signup-form/signup-form.stories.tsx#Default. See packaged agent recipes for executable examples.

## When not to use

Not for sign-in, workspace setup, consent, subscription selection or authentication infrastructure. Caller owns verification, server validation, password policy and provider integration.

## States

Idle, invalid, submitting, failure/retry and caller result feedback. Both actions are mutually exclusive while pending. First invalid input receives focus. Errors stay associated with inputs; results use a live status and failures an alert. Values remain after failure. Passwords clear after any resolved action, including one whose message reports a problem, so resolve only when the action worked.

A callback that resolves with `{ ok: false, message }` reports a failure it understands, such as "That email is already registered." The message shows as an alert, the values stay, and the passwords are not cleared. A rejected callback shows the generic `submitFailure` or `providerFailure` text and discards the error, so unexpected errors do not reach the reader. The Google button ignores the typed fields and runs without validation.

Source story evidence (not installed): src/blocks/signup-form/signup-form.stories.tsx#Invalid. See packaged agent recipes for executable examples.

Source story evidence (not installed): src/blocks/signup-form/signup-form.stories.tsx#Recovery. See packaged agent recipes for executable examples.

## Content

Labels and hints are serializable. The validation errors, the status line above the fields and the submitting and failure messages are fields too (`nameError`, `emailError`, `passwordError`, `confirmationError`, `mismatchError`, `invalidMessage`, `submittingMessage`, `providerPendingMessage`, `submitFailure`, `providerFailure`), each with an English default. `passwordMinLength` (default 8) sets the minimum and, unless `passwordDescription` is supplied, the hint. A custom `passwordDescription` is only text, so keep it true. The minimum and matching confirmation preserve the source block's requirement, not a universal password policy. Full name must be nonblank. Email is trimmed, then must satisfy the shared credential schema. The submitted email is trimmed but not lowercased. Local fixture callbacks explicitly announce that they do not create accounts. No credentials are stored, logged or serialized in fixtures.

## Composition

Use inside a bounded parent. Block owns transient field state and validation. Required React callbacks: `onSubmit({ name, email, password })` and `onGoogleSignup()` (the button text is `providerLabel`, so it can name another provider if the callback starts one), both return `Promise<{ message: string; ok?: true } | { message: string; ok: false }>`. Rejection produces a recoverable generic failure; resolution displays caller feedback without inferring authenticated success, and `ok: false` shows the message as a failure. `headingLevel` ("2", "3" or "4") sets the title's level. Confirmation stays local. No arbitrary styles, slots or inherited Card props. Never nest inside a form.

Source story evidence (not installed): src/blocks/signup-form/signup-form.stories.tsx#PageExample. See packaged agent recipes for executable examples.

## Implementation origin

Adapted from shadcn signup-01, radix-nova. Immutable retrieved snapshot and attribution are in `vendor/shadcn/blocks/signup-01/`; `blocks.lock.json` pins bytes and actual imports, including upstream's undeclared Field dependency. No upstream application source is imported.

## Catalog base

System Card, TextField and Button exclusively. Removed the product-specific email privacy promise and replaced the placeholder sign-in link with a required destination. Next.js routing is excluded. The page example uses Page and Section and adds a visible H1 for Prism's landmark contract.

## API

API schema: generated/schemas/signup-form.schema.json

## Tokens

Inherits component tokens and containing semantic scheme. Local layout uses stack/tight spacing; local status/navigation use foreground, muted-foreground, destructive and ring roles.

## Themes

Supports both modes and all configured regional schemes.

Source story evidence (not installed): src/blocks/signup-form/signup-form.stories.tsx#SchemeMatrix. See packaged agent recipes for executable examples.
