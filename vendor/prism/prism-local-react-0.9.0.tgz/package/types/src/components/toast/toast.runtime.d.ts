export declare const toastDefaults: {
    readonly variant: "default";
    readonly duration: 6000;
};
export declare const toastDurationRange: {
    readonly min: 5000;
    readonly max: 30000;
};
