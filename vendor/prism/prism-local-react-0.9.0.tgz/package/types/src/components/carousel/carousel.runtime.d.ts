export declare const carouselDefaults: {
    readonly previousLabel: "Previous slide";
    readonly nextLabel: "Next slide";
    readonly positionLabel: "Slide {current} of {total}";
    readonly slideLabel: "{current} of {total}: {label}";
};
