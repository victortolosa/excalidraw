export { carouselDefaults } from './carousel.runtime.ts';
import { z } from 'zod';
export declare const carouselItemSchema: z.ZodObject<{
    id: z.ZodString;
    label: z.ZodString;
}, z.core.$strict>;
export declare const carouselSchema: z.ZodObject<{
    label: z.ZodString;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
    }, z.core.$strict>>;
    previousLabel: z.ZodDefault<z.ZodString>;
    nextLabel: z.ZodDefault<z.ZodString>;
    positionLabel: z.ZodDefault<z.ZodString>;
    slideLabel: z.ZodDefault<z.ZodString>;
}, z.core.$strict>;
export type CarouselInput = z.input<typeof carouselSchema>;
export declare const carouselJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    label: z.ZodString;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        label: z.ZodString;
    }, z.core.$strict>>;
    previousLabel: z.ZodDefault<z.ZodString>;
    nextLabel: z.ZodDefault<z.ZodString>;
    positionLabel: z.ZodDefault<z.ZodString>;
    slideLabel: z.ZodDefault<z.ZodString>;
}, z.core.$strict>>;
