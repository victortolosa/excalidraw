/** Fills {name} placeholders in a content string. Unknown placeholders are left as written. */
export declare const fillTemplate: (template: string, values: Record<string, string | number>) => string;
