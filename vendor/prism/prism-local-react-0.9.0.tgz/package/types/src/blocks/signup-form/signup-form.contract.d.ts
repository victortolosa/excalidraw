export { signupFormDefaults, signupPasswordHint } from './signup-form.runtime.ts';
import { z } from 'zod';
export declare const signupFormSchema: z.ZodObject<{
    title: z.ZodDefault<z.ZodString>;
    description: z.ZodDefault<z.ZodString>;
    nameLabel: z.ZodDefault<z.ZodString>;
    emailLabel: z.ZodDefault<z.ZodString>;
    emailDescription: z.ZodDefault<z.ZodString>;
    passwordLabel: z.ZodDefault<z.ZodString>;
    passwordDescription: z.ZodOptional<z.ZodString>;
    confirmationLabel: z.ZodDefault<z.ZodString>;
    confirmationDescription: z.ZodDefault<z.ZodString>;
    submitLabel: z.ZodDefault<z.ZodString>;
    providerLabel: z.ZodDefault<z.ZodString>;
    signInPrompt: z.ZodDefault<z.ZodString>;
    signInLabel: z.ZodDefault<z.ZodString>;
    headingLevel: z.ZodDefault<z.ZodEnum<{
        2: "2";
        3: "3";
        4: "4";
    }>>;
    passwordMinLength: z.ZodDefault<z.ZodNumber>;
    nameError: z.ZodDefault<z.ZodString>;
    emailError: z.ZodDefault<z.ZodString>;
    passwordError: z.ZodDefault<z.ZodString>;
    confirmationError: z.ZodDefault<z.ZodString>;
    mismatchError: z.ZodDefault<z.ZodString>;
    invalidMessage: z.ZodDefault<z.ZodString>;
    submittingMessage: z.ZodDefault<z.ZodString>;
    providerPendingMessage: z.ZodDefault<z.ZodString>;
    submitFailure: z.ZodDefault<z.ZodString>;
    providerFailure: z.ZodDefault<z.ZodString>;
    signInHref: z.ZodString;
}, z.core.$strict>;
export type SignupFormInput = z.input<typeof signupFormSchema>;
export declare const signupFormJsonSchema: () => z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
    title: z.ZodDefault<z.ZodString>;
    description: z.ZodDefault<z.ZodString>;
    nameLabel: z.ZodDefault<z.ZodString>;
    emailLabel: z.ZodDefault<z.ZodString>;
    emailDescription: z.ZodDefault<z.ZodString>;
    passwordLabel: z.ZodDefault<z.ZodString>;
    passwordDescription: z.ZodOptional<z.ZodString>;
    confirmationLabel: z.ZodDefault<z.ZodString>;
    confirmationDescription: z.ZodDefault<z.ZodString>;
    submitLabel: z.ZodDefault<z.ZodString>;
    providerLabel: z.ZodDefault<z.ZodString>;
    signInPrompt: z.ZodDefault<z.ZodString>;
    signInLabel: z.ZodDefault<z.ZodString>;
    headingLevel: z.ZodDefault<z.ZodEnum<{
        2: "2";
        3: "3";
        4: "4";
    }>>;
    passwordMinLength: z.ZodDefault<z.ZodNumber>;
    nameError: z.ZodDefault<z.ZodString>;
    emailError: z.ZodDefault<z.ZodString>;
    passwordError: z.ZodDefault<z.ZodString>;
    confirmationError: z.ZodDefault<z.ZodString>;
    mismatchError: z.ZodDefault<z.ZodString>;
    invalidMessage: z.ZodDefault<z.ZodString>;
    submittingMessage: z.ZodDefault<z.ZodString>;
    providerPendingMessage: z.ZodDefault<z.ZodString>;
    submitFailure: z.ZodDefault<z.ZodString>;
    providerFailure: z.ZodDefault<z.ZodString>;
    signInHref: z.ZodString;
}, z.core.$strict>>;
type CredentialCopy = Record<'nameError' | 'emailError' | 'passwordError' | 'confirmationError' | 'mismatchError', string> & {
    passwordMinLength: number;
};
/** The rules the form enforces, with its error text. Pass the content copy to localize or reword. */
export declare const createSignupCredentialsSchema: (copy?: CredentialCopy) => z.ZodObject<{
    name: z.ZodString;
    email: z.ZodPipe<z.ZodString, z.ZodEmail>;
    password: z.ZodString;
    confirmation: z.ZodString;
}, z.core.$strict>;
export declare const signupCredentialsSchema: z.ZodObject<{
    name: z.ZodString;
    email: z.ZodPipe<z.ZodString, z.ZodEmail>;
    password: z.ZodString;
    confirmation: z.ZodString;
}, z.core.$strict>;
export type SignupValues = z.input<typeof signupCredentialsSchema>;
export type SignupSubmission = Omit<SignupValues, 'confirmation'>;
/** What a callback resolves to. Resolve with ok: false to report a failure the caller understands, such as "Email already registered". */
export type SignupResult = {
    message: string;
    ok?: true;
} | {
    message: string;
    ok: false;
};
