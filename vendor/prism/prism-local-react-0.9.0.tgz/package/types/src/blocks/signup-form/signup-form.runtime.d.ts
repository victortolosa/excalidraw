export declare const signupFormDefaults: {
    readonly title: "Create an account";
    readonly description: "Enter your information below to create your account";
    readonly headingLevel: "2";
    readonly passwordMinLength: 8;
    readonly nameLabel: "Full Name";
    readonly emailLabel: "Email";
    readonly emailDescription: "We'll use this to contact you.";
    readonly passwordLabel: "Password";
    readonly confirmationLabel: "Confirm Password";
    readonly confirmationDescription: "Please confirm your password.";
    readonly submitLabel: "Create Account";
    readonly providerLabel: "Sign up with Google";
    readonly signInPrompt: "Already have an account?";
    readonly signInLabel: "Sign in";
    readonly nameError: "Enter your full name.";
    readonly emailError: "Enter a valid email address.";
    readonly passwordError: "Use at least {min} characters.";
    readonly confirmationError: "Confirm your password.";
    readonly mismatchError: "Passwords must match.";
    readonly invalidMessage: "Check the highlighted fields.";
    readonly submittingMessage: "Submitting your information…";
    readonly providerPendingMessage: "Starting Google signup…";
    readonly submitFailure: "Account creation failed. Your values are still here. Please try again.";
    readonly providerFailure: "Google signup could not start. Please try again.";
};
/** The hint under the password field when the caller supplies none, so it always names the enforced minimum. */
export declare const signupPasswordHint: (minLength: number) => string;
