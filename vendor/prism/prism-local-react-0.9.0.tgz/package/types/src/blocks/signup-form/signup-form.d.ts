import { type SignupFormInput, type SignupSubmission, type SignupResult } from './signup-form.contract';
export type SignupFormProps = SignupFormInput & {
    onSubmit: (values: SignupSubmission) => Promise<SignupResult>;
    onGoogleSignup: () => Promise<SignupResult>;
};
export declare function SignupForm({ onSubmit, onGoogleSignup, signInHref, ...content }: SignupFormProps): import("react").JSX.Element;
