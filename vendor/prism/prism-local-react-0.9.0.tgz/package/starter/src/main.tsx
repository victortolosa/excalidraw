import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './styles.css'
import { Page, Section } from '@prism-local/react'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Page title="Your app" description="Prism is installed. Replace this page with your first screen.">
      <Section title="Next steps">
        <p>Build screens in src/screens and import supported components from @prism-local/react.</p>
      </Section>
    </Page>
  </StrictMode>,
)
