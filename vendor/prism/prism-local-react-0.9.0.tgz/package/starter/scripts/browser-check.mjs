import assert from 'node:assert/strict'
import { readFileSync, mkdirSync } from 'node:fs'
import { createServer } from 'vite'
import { chromium } from 'playwright'
const server = await createServer({ server: { host: '127.0.0.1', port: 0 } })
let browser
try {
  await server.listen(); browser = await chromium.launch({ headless: true })
  const page = await browser.newPage({ viewport: { width: 320, height: 900 } })
  const errors = []; page.on('pageerror', error => errors.push(error.message))
  page.setDefaultTimeout(10000)
  await page.goto(server.resolvedUrls.local[0])
  await page.getByRole('heading', { level: 1 }).waitFor()
  const themes = JSON.parse(readFileSync('node_modules/@prism-local/react/context/resolved-themes.json','utf8'))
  const axe = readFileSync('node_modules/axe-core/axe.min.js','utf8')
  // The matrix uses the installed release vocabulary, not an independently maintained list.
  for (const context of themes.themes) {
    const {mode,surface:scheme} = context
    const key = `${mode}/${scheme}`
    await page.evaluate(({mode,scheme})=>{document.documentElement.dataset.mode=mode;document.documentElement.dataset.scheme=scheme}, {mode,scheme})
    await page.waitForFunction(() => document.getAnimations().every(animation => animation.playState !== 'running'))
    await page.addScriptTag({content:axe})
    const violations = await page.evaluate(async()=> (await window.axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21a','wcag21aa']}})).violations)
    assert.deepEqual(violations.map(v=>v.id), [], key)
    assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth <= innerWidth), true, key)
  }
  const config = JSON.parse(readFileSync('node_modules/@prism-local/react/types/tokens/themes.json','utf8'))
  for (const density of config.densities) {
    await page.evaluate(value => {document.documentElement.dataset.density = value}, density)
    assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth <= innerWidth), true, density)
  }
  await page.emulateMedia({reducedMotion:'reduce'})
  assert.equal(await page.evaluate(()=>matchMedia('(prefers-reduced-motion: reduce)').matches), true)
  const evidence = process.env.PRISM_EVIDENCE_DIR
  if (evidence) mkdirSync(evidence,{recursive:true})
  for (const width of [320,768,1280]) {
    await page.setViewportSize({width,height:900})
    assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth <= innerWidth), true, `viewport ${width}`)
    if (evidence && width !== 768) await page.screenshot({path:`${evidence}/starter-${width}.png`,fullPage:true})
  }
  await page.setViewportSize({width:1280,height:900})
  assert.equal(await page.getByRole('main').count(),1)
  assert.equal(await page.getByRole('heading',{level:1}).count(),1)
  assert.deepEqual(errors, [])
  console.log('Starter page rendering and theme accessibility checks passed.')
} finally { await browser?.close(); await server.close() }
