// src/blocks/signup-form/signup-form.runtime.ts
var e = {
	title: "Create an account",
	description: "Enter your information below to create your account",
	headingLevel: "2",
	passwordMinLength: 8,
	nameLabel: "Full Name",
	emailLabel: "Email",
	emailDescription: "We'll use this to contact you.",
	passwordLabel: "Password",
	confirmationLabel: "Confirm Password",
	confirmationDescription: "Please confirm your password.",
	submitLabel: "Create Account",
	providerLabel: "Sign up with Google",
	signInPrompt: "Already have an account?",
	signInLabel: "Sign in",
	nameError: "Enter your full name.",
	emailError: "Enter a valid email address.",
	passwordError: "Use at least {min} characters.",
	confirmationError: "Confirm your password.",
	mismatchError: "Passwords must match.",
	invalidMessage: "Check the highlighted fields.",
	submittingMessage: "Submitting your information…",
	providerPendingMessage: "Starting Google signup…",
	submitFailure: "Account creation failed. Your values are still here. Please try again.",
	providerFailure: "Google signup could not start. Please try again."
}, t = (e) => `Must be at least ${e} characters long.`;
export { e as signupFormDefaults, t as signupPasswordHint };
