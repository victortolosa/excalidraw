import { Card as e } from "../../components/card/card.js";
import { TextField as t } from "../../components/text-field/text-field.js";
import { Button as n } from "../../components/button/button.js";
import { signupFormDefaults as r, signupPasswordHint as i } from "./signup-form.runtime.js";
import { createSignupCredentialsSchema as a } from "./signup-form.contract.js";
import { useRef as o, useState as s } from "react";
import { jsx as c, jsxs as l } from "react/jsx-runtime";
// src/blocks/signup-form/signup-form.tsx
var u = [
	"name",
	"email",
	"password",
	"confirmation"
];
function d({ onSubmit: d, onGoogleSignup: f, signInHref: p, ...m }) {
	let h = {
		...r,
		...m
	}, [g, _] = s({
		name: "",
		email: "",
		password: "",
		confirmation: ""
	}), [v, y] = s({}), [b, x] = s(null), [S, C] = s(""), [w, T] = s(""), E = o(!1), D = {
		name: o(null),
		email: o(null),
		password: o(null),
		confirmation: o(null)
	};
	function O(e, t) {
		_((n) => ({
			...n,
			[e]: t
		})), y((t) => ({
			...t,
			[e]: void 0
		})), C(""), T("");
	}
	async function k(e, t) {
		if (!E.current) {
			E.current = !0, x(e), T(""), C(e === "submit" ? h.submittingMessage : h.providerPendingMessage);
			try {
				let e = await t();
				if (e.ok === !1) {
					C(""), T(e.message);
					return;
				}
				C(e.message), _((e) => ({
					...e,
					password: "",
					confirmation: ""
				}));
			} catch {
				C(""), T(e === "submit" ? h.submitFailure : h.providerFailure);
			} finally {
				E.current = !1, x(null);
			}
		}
	}
	return /* @__PURE__ */ c("div", {
		"data-block": "signup-form",
		className: "min-w-0",
		children: /* @__PURE__ */ c(e, {
			title: h.title,
			description: h.description,
			headingLevel: h.headingLevel,
			children: /* @__PURE__ */ l("form", {
				noValidate: !0,
				"aria-busy": !!b,
				className: "grid min-w-0 gap-stack",
				onSubmit: (e) => {
					if (e.preventDefault(), E.current) return;
					let t = a(h).safeParse(g);
					if (!t.success) {
						let e = {};
						for (let n of t.error.issues) {
							let t = n.path[0];
							e[t] || (e[t] = n.message);
						}
						y(e), C(h.invalidMessage), T("");
						let n = u.find((t) => e[t]);
						n && D[n].current?.focus();
						return;
					}
					y({});
					let { confirmation: n, ...r } = t.data;
					k("submit", () => d(r));
				},
				children: [
					/* @__PURE__ */ c(t, {
						label: h.nameLabel,
						name: "name",
						autoComplete: "name",
						required: !0,
						ref: D.name,
						value: g.name,
						onChange: (e) => O("name", e.target.value),
						error: v.name,
						readOnly: !!b
					}),
					/* @__PURE__ */ c(t, {
						label: h.emailLabel,
						description: h.emailDescription,
						name: "email",
						type: "email",
						autoComplete: "email",
						required: !0,
						ref: D.email,
						value: g.email,
						onChange: (e) => O("email", e.target.value),
						error: v.email,
						readOnly: !!b
					}),
					/* @__PURE__ */ c(t, {
						label: h.passwordLabel,
						description: m.passwordDescription ?? i(h.passwordMinLength),
						name: "password",
						type: "password",
						autoComplete: "new-password",
						required: !0,
						ref: D.password,
						value: g.password,
						onChange: (e) => O("password", e.target.value),
						error: v.password,
						readOnly: !!b
					}),
					/* @__PURE__ */ c(t, {
						label: h.confirmationLabel,
						description: h.confirmationDescription,
						name: "confirmation",
						type: "password",
						autoComplete: "new-password",
						required: !0,
						ref: D.confirmation,
						value: g.confirmation,
						onChange: (e) => O("confirmation", e.target.value),
						error: v.confirmation,
						readOnly: !!b
					}),
					/* @__PURE__ */ l("div", {
						className: "flex min-w-0 flex-col items-stretch gap-tight",
						children: [/* @__PURE__ */ c(n, {
							type: "submit",
							...b === "google" ? { disabled: !0 } : { loading: b === "submit" },
							children: h.submitLabel
						}), /* @__PURE__ */ c(n, {
							variant: "secondary",
							...b === "submit" ? { disabled: !0 } : { loading: b === "google" },
							onClick: () => {
								k("google", f);
							},
							children: h.providerLabel
						})]
					}),
					/* @__PURE__ */ l("p", {
						className: "text-center text-sm text-muted-foreground wrap-anywhere",
						children: [
							h.signInPrompt,
							" ",
							/* @__PURE__ */ c("a", {
								href: p,
								className: "underline underline-offset-4 focus-visible:outline-2 focus-visible:outline-ring",
								children: h.signInLabel
							})
						]
					}),
					/* @__PURE__ */ c("p", {
						role: "status",
						className: "text-sm wrap-anywhere",
						children: S
					}),
					w && /* @__PURE__ */ c("p", {
						role: "alert",
						className: "text-sm text-destructive wrap-anywhere",
						children: w
					})
				]
			})
		})
	});
}
export { d as SignupForm };
