import { signupFormDefaults as e } from "./signup-form.runtime.js";
import { fillTemplate as t } from "../../lib/template.js";
import { z as n } from "zod";
// src/blocks/signup-form/signup-form.contract.ts
var r = n.string().regex(/\S/);
n.strictObject({
	title: r.default(e.title).describe("Heading of the form, which also names its region for screen readers."),
	description: r.default(e.description).describe("One line under the heading explaining what the form does."),
	nameLabel: r.default(e.nameLabel).describe("Label for the full name field. The error text is set separately by nameError."),
	emailLabel: r.default(e.emailLabel).describe("Label for the email field."),
	emailDescription: r.default(e.emailDescription).describe("Hint under the email field, such as why the address is needed."),
	passwordLabel: r.default(e.passwordLabel).describe("Label for the password field."),
	passwordDescription: r.optional().describe("Hint under the password field. Defaults to naming passwordMinLength. It is text only, so keep it true if you change it."),
	confirmationLabel: r.default(e.confirmationLabel).describe("Label for the repeat-password field."),
	confirmationDescription: r.default(e.confirmationDescription).describe("Hint under the repeat-password field."),
	submitLabel: r.default(e.submitLabel).describe("Text of the main button that creates the account. Describe the result."),
	providerLabel: r.default(e.providerLabel).describe("Text of the second button, which runs onGoogleSignup. Name the provider that callback actually starts."),
	signInPrompt: r.default(e.signInPrompt).describe("Text before the sign-in link, such as \"Already have an account?\"."),
	signInLabel: r.default(e.signInLabel).describe("Text of the sign-in link."),
	headingLevel: n.enum([
		"2",
		"3",
		"4"
	]).default(e.headingLevel).describe("Heading level of the title, given as text: \"2\", \"3\" or \"4\". Match the surrounding outline."),
	passwordMinLength: n.number().int().min(1).max(128).default(e.passwordMinLength).describe("Fewest characters the password may have. Enforced by the form and named in the default hint."),
	nameError: r.default(e.nameError).describe("Error when the name is blank."),
	emailError: r.default(e.emailError).describe("Error when the email is not valid."),
	passwordError: r.default(e.passwordError).describe("Error when the password is too short. {min} becomes passwordMinLength."),
	confirmationError: r.default(e.confirmationError).describe("Error when the repeat-password field is empty."),
	mismatchError: r.default(e.mismatchError).describe("Error when the two passwords differ."),
	invalidMessage: r.default(e.invalidMessage).describe("Status line shown above the fields when the form cannot be submitted."),
	submittingMessage: r.default(e.submittingMessage).describe("Status line while the account is being created."),
	providerPendingMessage: r.default(e.providerPendingMessage).describe("Status line while the provider button is working."),
	submitFailure: r.default(e.submitFailure).describe("Alert when creating the account fails without a message from the caller."),
	providerFailure: r.default(e.providerFailure).describe("Alert when the provider button fails without a message from the caller."),
	signInHref: n.string().regex(/^(\/(?![/\\])|https?:\/\/[^\s/]|#[A-Za-z])\S*$/).describe("Where the sign-in link goes: a site path such as /sign-in, a #section or a full web address. Required; there is no default.")
}).meta({
	title: "SignupForm",
	description: "A signup form with name, email, password confirmation, Google signup and sign-in navigation. Caller owns authentication."
});
var i = (r = e) => n.strictObject({
	name: n.string().trim().min(1, r.nameError),
	email: n.string().trim().pipe(n.email(r.emailError)),
	password: n.string().min(r.passwordMinLength, t(r.passwordError, { min: r.passwordMinLength })),
	confirmation: n.string().min(1, r.confirmationError)
}).refine((e) => e.password === e.confirmation, {
	path: ["confirmation"],
	message: r.mismatchError
});
i();
export { i as createSignupCredentialsSchema };
