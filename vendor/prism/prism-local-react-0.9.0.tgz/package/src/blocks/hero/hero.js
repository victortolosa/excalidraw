import { NavigationCta as e } from "../../components/button/navigation-cta.js";
import { Button as t } from "../../components/button/button.js";
import { heroDefaults as n } from "./hero.runtime.js";
import { Fragment as r } from "react";
import { Fragment as i, jsx as a, jsxs as o } from "react/jsx-runtime";
// src/blocks/hero/hero.tsx
function s({ headingId: s, heading: c, eyebrow: l, description: u, composition: d = n.composition, primaryAction: f, secondaryAction: p, media: m, mediaContent: h, onAction: g, pendingAction: _ }) {
	let v = d !== "split", y = (n, r = !1) => n.kind === "link" ? /* @__PURE__ */ a(e, {
		label: n.label,
		href: n.href,
		icon: n.icon,
		variant: r ? "secondary" : "primary"
	}) : /* @__PURE__ */ a(t, {
		variant: r ? "secondary" : "primary",
		icon: n.icon,
		iconPosition: n.icon ? "end" : void 0,
		..._ === n.id ? { loading: !0 } : { disabled: !!_ || !g },
		onClick: () => g?.(n.id),
		children: n.label
	});
	return /* @__PURE__ */ o("section", {
		"data-block": "hero",
		"aria-labelledby": s,
		className: `grid min-w-0 gap-section py-section ${d === "split" ? "md:grid-cols-2 md:items-center" : ""}`,
		children: [/* @__PURE__ */ o("div", {
			className: `flex min-w-0 flex-col gap-stack ${v ? "items-center text-center mx-auto max-w-3xl" : ""}`,
			children: [
				l && /* @__PURE__ */ a("p", {
					className: "font-mono text-xs uppercase tracking-wider text-muted-foreground",
					children: l
				}),
				/* @__PURE__ */ a("h1", {
					id: s,
					className: "font-heading text-3xl sm:text-4xl font-semibold leading-tight wrap-anywhere",
					children: c.map((e, t) => /* @__PURE__ */ o(r, { children: [e.breakBefore && /* @__PURE__ */ o(i, { children: [" ", /* @__PURE__ */ a("br", {})] }), e.emphasis ? /* @__PURE__ */ a("em", {
						className: "text-primary italic font-normal",
						children: e.text
					}) : e.text] }, t))
				}),
				u && /* @__PURE__ */ a("p", {
					className: "max-w-prose text-muted-foreground wrap-anywhere",
					children: u
				}),
				(f || p) && /* @__PURE__ */ o("div", {
					className: `flex min-w-0 flex-wrap items-center gap-stack ${v ? "justify-center" : ""}`,
					children: [f && y(f), p && y(p, !0)]
				})
			]
		}), m && /* @__PURE__ */ a("div", {
			className: "min-w-0",
			children: m.kind === "image" ? /* @__PURE__ */ a("img", {
				src: m.src,
				alt: m.alt,
				width: m.width,
				height: m.height,
				className: "h-auto w-full rounded-panel object-contain"
			}) : /* @__PURE__ */ a("div", {
				role: "group",
				"aria-label": m.label,
				children: h
			})
		})]
	});
}
export { s as Hero };
