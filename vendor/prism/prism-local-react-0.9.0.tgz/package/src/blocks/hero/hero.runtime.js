// src/blocks/hero/hero.runtime.ts
var e = { composition: "centered" };
export { e as heroDefaults };
