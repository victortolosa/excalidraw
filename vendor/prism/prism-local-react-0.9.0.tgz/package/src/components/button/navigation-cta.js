import { typographyProps as e } from "../../lib/typography.js";
import { buttonVariants as t } from "../ui/button.js";
import { cn as n } from "../../lib/utils.js";
import { actionIcons as r } from "../../lib/action-icons.js";
import { catalogVariants as i, systemClasses as a } from "./button-styles.js";
import { jsx as o, jsxs as s } from "react/jsx-runtime";
// src/components/button/navigation-cta.tsx
function c({ label: c, href: l, icon: u, variant: d = "primary" }) {
	let f = u ? r[u] : void 0;
	return /* @__PURE__ */ s("a", {
		...e("button", "label"),
		href: l,
		"data-navigation-cta": d,
		className: n(t({
			variant: i[d],
			size: "lg"
		}), a),
		children: [/* @__PURE__ */ o("span", {
			className: "min-w-0 break-words",
			children: c
		}), f && /* @__PURE__ */ o(f, {
			"aria-hidden": "true",
			className: "size-4 shrink-0"
		})]
	});
}
export { c as NavigationCta };
