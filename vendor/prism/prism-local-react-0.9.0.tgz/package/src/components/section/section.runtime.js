// src/components/section/section.runtime.ts
var e = {
	headingLevel: "2",
	titleStyle: "default"
};
export { e as sectionDefaults };
