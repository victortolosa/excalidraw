import { toastDefaults as e, toastDurationRange as t } from "./toast.runtime.js";
import { z as n } from "zod";
// src/components/toast/toast.contract.ts
var r = [
	"default",
	"success",
	"info",
	"warning",
	"destructive"
], i = n.strictObject({
	title: n.string().regex(/\S/).describe("Brief, explicit outcome; meaning must not depend on the icon."),
	description: n.string().regex(/\S/).optional().describe("Optional supporting information. Essential instructions also belong inline."),
	variant: n.enum(r).default(e.variant).describe("The kind of outcome: default, success, info, warning or destructive. It changes the icon and not the wording, so the title must carry the meaning."),
	duration: n.number().int().min(t.min).max(t.max).default(e.duration).describe("Time on screen in milliseconds, from 5000 to 30000. The pause during interaction comes from Sonner. show throws a RangeError outside the range. Other input is checked only when ToastProvider receives validateInput.")
}).meta({
	title: "Toast",
	description: "Brief non-blocking outcome feedback via ToastProvider and useToast. Use inline Alert for persistent errors or required action."
});
export { i as toastSchema, r as toastVariants };
