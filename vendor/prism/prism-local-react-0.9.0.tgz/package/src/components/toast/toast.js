import { typographyProps as e } from "../../lib/typography.js";
import { Toaster as t } from "../ui/sonner.js";
import { toastDefaults as n, toastDurationRange as r } from "./toast.runtime.js";
import { createContext as i, useContext as a, useEffect as o, useId as s, useMemo as c, useRef as l, useState as u } from "react";
import { jsx as d, jsxs as f } from "react/jsx-runtime";
import { createPortal as p } from "react-dom";
import { toast as m } from "sonner";
// src/components/toast/toast.tsx
var h = i(null), g = {
	default: m,
	success: m.success,
	info: m.info,
	warning: m.warning,
	destructive: m.error
};
function _({ children: i, validateInput: a }) {
	let _ = s(), v = l(/* @__PURE__ */ new Set()), [y, b] = u(null), [x, S] = u("light");
	o(() => {
		b(document.body);
		let e = document.documentElement, t = () => S(e.dataset.mode === "dark" ? "dark" : "light");
		t();
		let n = new MutationObserver(t);
		n.observe(e, {
			attributes: !0,
			attributeFilter: ["data-mode"]
		});
		let r = v.current;
		return () => {
			n.disconnect();
			for (let e of r) m.dismiss(e);
			r.clear();
		};
	}, []);
	let C = c(() => ({
		show(t) {
			let { title: i, description: o, variant: s = n.variant, duration: c = n.duration } = a ? a(t) : t;
			if (!Number.isInteger(c) || c < r.min || c > r.max) throw RangeError(`Toast duration must be a whole number of milliseconds from ${r.min} to ${r.max}.`);
			let l = (e) => {
				v.current.delete(e.id);
			}, u = g[s](/* @__PURE__ */ d("span", {
				...e("toast", "title"),
				children: i
			}), {
				description: o ? /* @__PURE__ */ d("span", {
					...e("toast", "description"),
					children: o
				}) : void 0,
				duration: c,
				toasterId: _,
				onDismiss: l,
				onAutoClose: l
			});
			return v.current.add(u), u;
		},
		dismiss(e) {
			v.current.delete(e) && m.dismiss(e);
		}
	}), [_, a]);
	return /* @__PURE__ */ f(h.Provider, {
		value: C,
		children: [i, y && p(/* @__PURE__ */ d("div", {
			"data-component": "toast",
			"data-scheme": "default",
			children: /* @__PURE__ */ d(t, {
				id: _,
				theme: x,
				position: "bottom-right",
				closeButton: !0,
				richColors: !1,
				toastOptions: { classNames: {
					toast: "font-sans",
					title: "wrap-anywhere",
					description: "!text-muted-foreground wrap-anywhere",
					closeButton: "!bg-popover !text-popover-foreground !border-border focus-visible:!outline-ring"
				} }
			})
		}), y)]
	});
}
function v() {
	let e = a(h);
	if (!e) throw Error("useToast requires ToastProvider");
	return e;
}
export { _ as ToastProvider, v as useToast };
