// src/components/toast/toast.runtime.ts
var e = {
	variant: "default",
	duration: 6e3
}, t = {
	min: 5e3,
	max: 3e4
};
export { e as toastDefaults, t as toastDurationRange };
