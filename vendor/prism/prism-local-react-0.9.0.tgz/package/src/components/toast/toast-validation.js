import { toastSchema as e } from "./toast.contract.js";
// src/components/toast/toast-validation.ts
function t(t) {
	return e.parse(t);
}
export { t as validateToast };
