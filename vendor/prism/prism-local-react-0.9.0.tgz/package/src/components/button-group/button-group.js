import { ButtonGroup as e } from "../ui/button-group.js";
import { buttonSchema as t } from "../button/button.contract.js";
import { Button as n } from "../button/button.js";
import { buttonGroupDefaults as r } from "./button-group.runtime.js";
import { jsx as i } from "react/jsx-runtime";
// src/components/button-group/button-group.tsx
function a({ label: a, items: o, orientation: s = r.orientation, onAction: c }) {
	return /* @__PURE__ */ i(e, {
		"data-component": "button-group",
		"aria-label": a,
		orientation: s,
		className: "max-w-full min-w-0 [&>button]:min-w-0 [&>button]:flex-1 [&>button]:wrap-anywhere",
		children: o.map((e) => {
			let r = t.parse(e.button), a = r.loading ? {
				loading: !0,
				disabled: !1
			} : {
				loading: !1,
				disabled: r.disabled
			};
			return /* @__PURE__ */ i(n, {
				...r,
				...a,
				onClick: () => c(e.id)
			}, e.id);
		})
	});
}
export { a as ButtonGroup };
