// src/components/button-group/button-group.runtime.ts
var e = { orientation: "horizontal" };
export { e as buttonGroupDefaults };
