// src/components/switch/switch.runtime.ts
var e = {
	required: !1,
	disabled: !1,
	defaultChecked: !1
};
export { e as switchDefaults };
