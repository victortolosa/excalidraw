// src/components/item/item.runtime.ts
var e = { variant: "plain" };
export { e as itemDefaults };
