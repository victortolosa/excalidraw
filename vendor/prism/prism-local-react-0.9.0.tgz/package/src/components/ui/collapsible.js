"use client";
import { Collapsible as e } from "radix-ui";
import { jsx as t } from "react/jsx-runtime";
// src/components/ui/collapsible.tsx
function n({ ...n }) {
	return /* @__PURE__ */ t(e.Root, {
		"data-slot": "collapsible",
		...n
	});
}
function r({ ...n }) {
	return /* @__PURE__ */ t(e.CollapsibleTrigger, {
		"data-slot": "collapsible-trigger",
		...n
	});
}
function i({ ...n }) {
	return /* @__PURE__ */ t(e.CollapsibleContent, {
		"data-slot": "collapsible-content",
		...n
	});
}
export { n as Collapsible, i as CollapsibleContent, r as CollapsibleTrigger };
