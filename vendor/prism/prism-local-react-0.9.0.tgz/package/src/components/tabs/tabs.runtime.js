// src/components/tabs/tabs.runtime.ts
var e = { size: "default" }, t = (e) => e.find((e) => !e.disabled)?.value;
export { t as firstEnabledTab, e as tabsDefaults };
