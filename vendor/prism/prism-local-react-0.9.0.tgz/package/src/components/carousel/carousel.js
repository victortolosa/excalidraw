import { typographyProps as e } from "../../lib/typography.js";
import { Carousel as t, CarouselContent as n, CarouselItem as r } from "../ui/carousel.js";
import { Button as i } from "../button/button.js";
import { fillTemplate as a } from "../../lib/template.js";
import { carouselDefaults as o } from "./carousel.runtime.js";
import { useEffect as s, useRef as c, useState as l } from "react";
import { jsx as u, jsxs as d } from "react/jsx-runtime";
// src/components/carousel/carousel.tsx
function f({ label: f, items: p, renderSlide: m, previousLabel: h = o.previousLabel, nextLabel: g = o.nextLabel, positionLabel: _ = o.positionLabel, slideLabel: v = o.slideLabel }) {
	let [y, b] = l(), [x, S] = l(0), [C, w] = l(!0), T = c(null), E = c(null), D = c(null);
	return s(() => {
		let e = D.current === "next" && x === p.length - 1, t = D.current === "previous" && x === 0;
		e && T.current?.focus(), t && E.current?.focus();
	}, [x, p.length]), s(() => {
		let e = window.matchMedia("(prefers-reduced-motion: reduce)"), t = () => w(e.matches);
		return t(), e.addEventListener("change", t), () => e.removeEventListener("change", t);
	}, []), s(() => {
		if (!y) return;
		let e = () => S(y.selectedScrollSnap());
		return e(), y.on("select", e).on("reInit", e), () => {
			y.off("select", e).off("reInit", e);
		};
	}, [y]), /* @__PURE__ */ d(t, {
		"data-component": "carousel",
		"aria-label": f,
		tabIndex: 0,
		setApi: b,
		opts: {
			loop: !1,
			duration: C ? 0 : 25
		},
		className: "min-w-0 max-w-full rounded-panel focus-visible:outline-2 focus-visible:outline-ring",
		onKeyDownCapture: (e) => {
			e.target === e.currentTarget && (e.key === "ArrowLeft" && (e.preventDefault(), y?.scrollPrev()), e.key === "ArrowRight" && (e.preventDefault(), y?.scrollNext()));
		},
		children: [/* @__PURE__ */ u(n, { children: p.map((e, t) => /* @__PURE__ */ u(r, {
			"aria-label": a(v, {
				current: t + 1,
				total: p.length,
				label: e.label
			}),
			"aria-hidden": t !== x,
			inert: t !== x,
			children: /* @__PURE__ */ u("div", {
				className: "min-w-0 p-1 wrap-anywhere",
				children: m(e.id)
			})
		}, e.id)) }), /* @__PURE__ */ d("div", {
			className: "mt-3 flex flex-wrap items-center gap-2",
			children: [
				/* @__PURE__ */ u(i, {
					ref: T,
					variant: "secondary",
					disabled: !y || x === 0,
					onClick: () => {
						D.current = "previous", y?.scrollPrev();
					},
					children: h
				}),
				/* @__PURE__ */ u(i, {
					ref: E,
					variant: "secondary",
					disabled: !y || x === p.length - 1,
					onClick: () => {
						D.current = "next", y?.scrollNext();
					},
					children: g
				}),
				/* @__PURE__ */ u("p", {
					...e("carousel", "status"),
					role: "status",
					"aria-atomic": "true",
					className: "text-sm text-muted-foreground",
					children: a(_, {
						current: x + 1,
						total: p.length
					})
				})
			]
		})]
	});
}
export { f as Carousel };
