// src/components/carousel/carousel.runtime.ts
var e = {
	previousLabel: "Previous slide",
	nextLabel: "Next slide",
	positionLabel: "Slide {current} of {total}",
	slideLabel: "{current} of {total}: {label}"
};
export { e as carouselDefaults };
