// src/components/badge/badge.runtime.ts
var e = { variant: "neutral" };
export { e as badgeDefaults };
