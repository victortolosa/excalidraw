// src/components/separator/separator.runtime.ts
var e = {
	orientation: "horizontal",
	decorative: !0
};
export { e as separatorDefaults };
