// src/components/breadcrumb/breadcrumb.runtime.ts
var e = { label: "Breadcrumb" };
export { e as breadcrumbDefaults };
