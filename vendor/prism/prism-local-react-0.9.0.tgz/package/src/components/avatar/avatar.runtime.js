// src/components/avatar/avatar.runtime.ts
var e = {
	size: "default",
	decorative: !1
};
function t(e) {
	let t = e.replace(/\([^)]*\)|\[[^\]]*\]/g, " ").split(/\s+/).map((e) => e.replace(/^[^\p{L}\p{N}]+/u, "")).filter(Boolean);
	if (t.length === 0) return Array.from(e.trim())[0]?.toLocaleUpperCase() ?? "";
	let n = (e) => Array.from(e)[0] ?? "";
	return (n(t[0]) + (t.length > 1 ? n(t[t.length - 1]) : "")).toLocaleUpperCase();
}
export { e as avatarDefaults, t as avatarInitials };
