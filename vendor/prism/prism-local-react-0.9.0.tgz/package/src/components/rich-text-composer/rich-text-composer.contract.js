import { composerConstraints as e, composerFieldsSchema as t } from "../composer/composer.contract.js";
import { isSafeRichTextLink as n } from "./rich-text-composer.runtime.js";
import { validateRichTextMarkdown as r } from "./rich-text-composer.markdown.js";
import { z as i } from "zod";
// src/components/rich-text-composer/rich-text-composer.contract.ts
var a = i.union([
	i.strictObject({ type: i.literal("bold").describe("Bold text.") }),
	i.strictObject({ type: i.literal("italic").describe("Italic text.") }),
	i.strictObject({
		type: i.literal("link").describe("A link."),
		attrs: i.strictObject({ href: i.string().refine(n, "Use an absolute http, https or mailto URL.").describe("Where the link goes: an absolute http, https or mailto address. Relative paths are rejected.") }).describe("Link settings.")
	})
]), o = i.union([i.strictObject({
	type: i.literal("text").describe("A run of text."),
	text: i.string().min(1).describe("The words. Cannot be empty."),
	marks: i.array(a).optional().describe("Formatting applied to this run: bold, italic or a link.")
}), i.strictObject({ type: i.literal("hardBreak").describe("A line break inside a paragraph.") })]), s = i.strictObject({
	type: i.literal("paragraph").describe("A paragraph."),
	content: i.array(o).optional().describe("Text and line breaks. Omit for an empty paragraph.")
}), c = i.strictObject({
	type: i.literal("heading").describe("A heading."),
	attrs: i.strictObject({ level: i.union([
		i.literal(1),
		i.literal(2),
		i.literal(3)
	]).describe("Heading level, 1 to 3.") }).describe("Heading settings."),
	content: i.array(o).optional().describe("Text and line breaks.")
}), l = i.lazy(() => i.union([i.strictObject({
	type: i.literal("bulletList").describe("A bulleted list."),
	content: i.array(u).min(1).describe("List items, at least one.")
}), i.strictObject({
	type: i.literal("orderedList").describe("A numbered list."),
	attrs: i.strictObject({ start: i.number().int().positive().describe("Number of the first item.") }).optional().describe("Numbering settings. Omit to start at 1."),
	content: i.array(u).min(1).describe("List items, at least one.")
})])), u = i.lazy(() => i.strictObject({
	type: i.literal("listItem").describe("One item in a list."),
	content: i.tuple([s]).rest(i.union([s, l])).describe("A paragraph first, then any more paragraphs or nested lists.")
})), d = i.strictObject({
	type: i.literal("doc").describe("The whole document."),
	content: i.array(i.union([
		s,
		c,
		l
	])).min(1).describe("Paragraphs, headings and lists, at least one block.")
}), f = t.omit({
	maxLength: !0,
	required: !0
}), p = i.string().superRefine((e, t) => {
	try {
		r(e);
	} catch (e) {
		t.addIssue({
			code: "custom",
			message: e instanceof Error ? e.message : "Invalid Markdown."
		});
	}
});
f.extend({
	format: i.enum(["json", "markdown"]).optional().describe("Input/output format. Defaults to json; markdown uses strings with the same visual toolbar."),
	defaultValue: i.union([d, p]).optional().describe("Initial document for json, or supported Markdown string for markdown.")
}).superRefine((t, n) => {
	e(t, n), t.defaultValue !== void 0 && typeof t.defaultValue == "string" != (t.format === "markdown") && n.addIssue({
		code: "custom",
		path: ["defaultValue"],
		message: "defaultValue must match the selected format."
	});
}).meta({
	title: "RichTextComposer",
	description: "Text editing with JSON or Markdown input/output, headings, bold, italic, lists and links in the shared Composer panel. Use Composer for plain text; images are not supported."
});
export { d as richTextDocumentSchema };
