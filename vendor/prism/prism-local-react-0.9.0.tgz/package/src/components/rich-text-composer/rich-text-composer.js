import { DropdownMenu as e, DropdownMenuContent as t, DropdownMenuRadioGroup as n, DropdownMenuRadioItem as r, DropdownMenuTrigger as i } from "../ui/dropdown-menu.js";
import { typographyProps as a } from "../../lib/typography.js";
import { ComposerPanel as ee } from "../composer/composer-panel.js";
import { Button as o } from "../button/button.js";
import { Dialog as te } from "../dialog/dialog.js";
import { TextField as s } from "../text-field/text-field.js";
import { composerDefaults as c } from "../composer/composer.runtime.js";
import "./rich-text-composer.contract.js";
import { isSafeRichTextLink as ne, richTextContentText as re } from "./rich-text-composer.runtime.js";
import { parseRichTextValue as l, portable as u, richTextExtensions as ie, serializeRichTextMarkdown as d } from "./rich-text-composer.document.js";
import { useEffect as f, useId as ae, useImperativeHandle as oe, useRef as p, useState as m } from "react";
import { Toolbar as h } from "radix-ui";
import { Bold as se, ChevronDown as ce, Italic as le, Link as ue, List as de, ListOrdered as fe, Redo2 as pe, Undo2 as me } from "lucide-react";
import { Fragment as he, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { EditorContent as ge, useEditor as _e, useEditorState as ve } from "@tiptap/react";
import "@tiptap/core";
import { EditorState as v } from "@tiptap/pm/state";
import { closeHistory as y } from "@tiptap/pm/history";
// src/components/rich-text-composer/rich-text-composer.tsx
function b(e, t) {
	e.view.updateState(v.create({
		schema: e.schema,
		doc: e.schema.nodeFromJSON(t),
		plugins: e.state.plugins
	})), e.commands.setTextSelection(1);
}
function ye(e, t, n) {
	let r = getComputedStyle(e), i = parseFloat(r.lineHeight), a = parseFloat(r.paddingTop) + parseFloat(r.paddingBottom);
	e.style.minHeight = `${t * i + a}px`, e.style.maxHeight = `${n * i + a}px`, e.style.overflowY = "auto";
}
var x = "shrink-0 rounded-(--button-radius) border border-border bg-secondary text-secondary-foreground hover:bg-accent hover:text-accent-foreground focus-visible:outline-2 focus-visible:outline-ring disabled:opacity-50 data-[state=on]:bg-accent data-[state=on]:text-accent-foreground", S = `size-(--icon-button-size) ${x}`;
function C(v) {
	let { label: C, labelVisibility: be = c.labelVisibility, description: w, error: T, submissionError: E, status: xe, id: Se, rows: D = c.rows, maxRows: O, disabled: k = !1, readOnly: A = !1, busy: j = !1, clearable: M = !1, clearLabel: Ce = c.clearLabel, undoLabel: we = c.undoLabel, format: N = "json", value: P, defaultValue: F, ref: Te, name: I, form: Ee, headerActions: De, secondaryActions: Oe, actions: ke } = v, Ae = ae(), L = Se ?? Ae, R = k || A || j, je = p(null), z = p(null), Me = p(null), [B] = m(() => l(P ?? F, N)), V = p(null), H = p(() => {});
	f(() => {
		H.current = (e) => {
			if (v.format === "markdown") {
				let t = d(e);
				V.current = {
					format: "markdown",
					value: t,
					document: JSON.stringify(e)
				}, v.onValueChange?.(t);
			} else V.current = {
				format: "json",
				value: e,
				document: JSON.stringify(e)
			}, v.onValueChange?.(e);
		};
	}, [v.format, v.onValueChange]);
	let [Ne, U] = m(""), [Pe, Fe] = m(1), Ie = p({
		from: 1,
		to: 1
	}), W = p(!1), [Le, G] = m(!1), [K, Re] = m(""), [q, ze] = m(""), [Be, J] = m(), Y = p({
		from: 1,
		to: 1
	}), X = _e({
		extensions: ie,
		content: B,
		immediatelyRender: !1,
		editable: !R,
		onUpdate: ({ editor: e }) => {
			H.current?.(u(e.getJSON())), U("");
		},
		editorProps: { attributes: {
			role: "textbox",
			"aria-multiline": "true",
			id: L,
			"aria-labelledby": `${L}-label`,
			"data-typography": "textarea.control",
			"aria-readonly": String(A || j),
			"aria-disabled": String(k),
			tabindex: k ? "-1" : "0",
			"aria-invalid": T ? "true" : "false",
			"aria-describedby": [
				w && `${L}-description`,
				T && `${L}-error`,
				E && `${L}-submission-error`
			].filter(Boolean).join(" "),
			"data-slot": "input-group-control",
			class: "w-full min-w-0 break-words py-2 text-foreground outline-none [&_p]:m-0 [&_h1]:m-0 [&_h1]:font-heading [&_h1]:text-3xl [&_h1]:font-semibold [&_h2]:m-0 [&_h2]:font-heading [&_h2]:text-2xl [&_h2]:font-semibold [&_h3]:m-0 [&_h3]:font-heading [&_h3]:text-xl [&_h3]:font-semibold [&_ul]:list-disc [&_ul]:pl-6 [&_ol]:list-decimal [&_ol]:pl-6 [&_a]:text-primary [&_a]:underline"
		} }
	}), Z = ve({
		editor: X,
		selector: ({ editor: e }) => e ? {
			heading: [
				1,
				2,
				3
			].find((t) => e.isActive("heading", { level: t })),
			bold: e.isActive("bold"),
			italic: e.isActive("italic"),
			bulletList: e.isActive("bulletList"),
			orderedList: e.isActive("orderedList"),
			link: e.isActive("link"),
			undo: e.can().undo(),
			redo: e.can().redo(),
			empty: e.isEmpty,
			document: u(e.getJSON())
		} : null
	});
	oe(Te, () => ({
		focus: () => X?.commands.focus(),
		getDocument: () => X ? u(X.getJSON()) : B,
		getText: () => re(X ? u(X.getJSON()) : B),
		getMarkdown: () => d(X ? u(X.getJSON()) : B)
	}), [X, B]), f(() => {
		X && (X.setEditable(!R, !1), Me.current = X.view.dom);
	}, [
		X,
		R,
		k,
		A,
		j,
		L,
		w,
		T,
		E
	]), f(() => {
		if (!X || P === void 0) return;
		let e = JSON.stringify(u(X.getJSON())), t = V.current;
		if (t?.format === N && t.value === P && t.document === e) return;
		let n = u(X.schema.nodeFromJSON(l(P, N)).toJSON());
		JSON.stringify(n) !== e && b(X, n);
	}, [
		X,
		P,
		N
	]), f(() => {
		if (!X || !z.current) return;
		let e = X.view.dom;
		function t() {
			ye(e, D, O ?? Math.max(D, c.maxRows));
		}
		t();
		let n = new MutationObserver(t);
		for (let e = z.current; e; e = e.parentElement) n.observe(e, {
			attributes: !0,
			attributeFilter: [
				"data-density",
				"data-mode",
				"class",
				"style"
			]
		});
		return window.addEventListener("resize", t), () => {
			n.disconnect(), window.removeEventListener("resize", t);
		};
	}, [
		X,
		D,
		O
	]), f(() => {
		if (!X) return;
		let e = je.current?.form ?? z.current?.closest("form");
		if (!e) return;
		let t = (e) => queueMicrotask(() => {
			if (e.defaultPrevented || X.isDestroyed) return;
			let t = l(P ?? F, N);
			b(X, t), P === void 0 && H.current?.(u(X.getJSON())), U(""), G(!1);
		});
		return e.addEventListener("reset", t), () => e.removeEventListener("reset", t);
	}, [
		X,
		P,
		F,
		Ee,
		N
	]);
	let Ve = (e) => {
		if (!X || R) return;
		X.view.dispatch(y(X.state.tr));
		let t = X.chain().focus();
		e === "bold" && t.toggleBold().run(), e === "italic" && t.toggleItalic().run(), e === "bulletList" && t.toggleBulletList().run(), e === "orderedList" && t.toggleOrderedList().run();
	};
	function He() {
		X && !R && (X.isActive("link") && X.commands.extendMarkRange("link"), Y.current = {
			from: X.state.selection.from,
			to: X.state.selection.to
		}, Re(X.state.doc.textBetween(Y.current.from, Y.current.to, " ")), ze(X.getAttributes("link").href ?? ""), J(void 0), G(!0));
	}
	function Ue() {
		G(!1), X && !X.isDestroyed && X.chain().focus().setTextSelection(Y.current).run();
	}
	function We() {
		if (!X || R) return Promise.reject(/* @__PURE__ */ Error("Editor unavailable"));
		if (!K.trim() || !ne(q)) return J(K.trim() ? "Use an absolute http, https or mailto URL." : "Enter link text."), Promise.reject(/* @__PURE__ */ Error("Invalid link"));
		J(void 0), X.view.dispatch(y(X.state.tr)), X.chain().focus().insertContentAt(Y.current, {
			type: "text",
			text: K,
			marks: [{
				type: "link",
				attrs: { href: q }
			}]
		}).setTextSelection(Y.current.from + K.length).command(({ tr: e }) => (e.setStoredMarks([]), !0)).run(), Y.current = {
			from: X.state.selection.from,
			to: X.state.selection.to
		};
	}
	let Q = Z?.heading ?? Pe, $ = Z?.empty ?? X?.isEmpty ?? !0, Ge = X && /* @__PURE__ */ _(h.Root, {
		"aria-label": "Text formatting",
		className: "flex w-full gap-1 overflow-x-auto py-1",
		loop: !0,
		onFocusCapture: (e) => e.target.scrollIntoView({
			block: "nearest",
			inline: "nearest"
		}),
		children: [
			/* @__PURE__ */ _("div", {
				className: "flex shrink-0",
				role: "group",
				"aria-label": "Heading style",
				children: [/* @__PURE__ */ _(h.Button, {
					"aria-label": `Toggle heading ${Q}`,
					"aria-pressed": !!Z?.heading,
					disabled: R || !X.can().toggleHeading({ level: Q }),
					className: `${S} rounded-r-none data-[active=true]:bg-accent data-[active=true]:text-accent-foreground`,
					"data-active": !!Z?.heading,
					onClick: () => {
						X.view.dispatch(y(X.state.tr)), X.chain().focus().toggleHeading({ level: Q }).run(), Fe(Q);
					},
					children: ["H", Q]
				}), /* @__PURE__ */ _(e, {
					modal: !1,
					onOpenChange: (e) => {
						e && (Ie.current = {
							from: X.state.selection.from,
							to: X.state.selection.to
						}, W.current = !1);
					},
					children: [/* @__PURE__ */ g(i, {
						asChild: !0,
						children: /* @__PURE__ */ g(h.Button, {
							"aria-label": "Choose heading level",
							disabled: R,
							className: `h-(--icon-button-size) w-6 min-w-[1.5rem] ${x} rounded-l-none border-l-0`,
							children: /* @__PURE__ */ g(ce, {
								"aria-hidden": "true",
								className: "mx-auto size-4"
							})
						})
					}), /* @__PURE__ */ g(t, {
						"aria-label": "Heading level",
						className: "max-w-[calc(100vw-2rem)]",
						onCloseAutoFocus: (e) => {
							W.current &&= (e.preventDefault(), X.commands.focus(), !1);
						},
						children: /* @__PURE__ */ _(n, {
							value: Z?.heading ? String(Z.heading) : "paragraph",
							onValueChange: (e) => {
								if (R) return;
								X.view.dispatch(y(X.state.tr));
								let t = X.chain().setTextSelection(Ie.current);
								if (e === "paragraph") t.setParagraph().run();
								else {
									let n = Number(e);
									t.setHeading({ level: n }).run(), Fe(n);
								}
								W.current = !0;
							},
							children: [/* @__PURE__ */ g(r, {
								value: "paragraph",
								disabled: R || !X.can().setParagraph(),
								...a("dropdown-menu", "option"),
								children: "Paragraph"
							}), [
								1,
								2,
								3
							].map((e) => /* @__PURE__ */ _(r, {
								value: String(e),
								disabled: R || !X.can().setHeading({ level: e }),
								...a("dropdown-menu", "option"),
								children: ["Heading ", e]
							}, e))]
						})
					})]
				})]
			}),
			/* @__PURE__ */ g(h.ToggleGroup, {
				type: "multiple",
				value: [
					"bold",
					"italic",
					"bulletList",
					"orderedList"
				].filter((e) => Z?.[e]),
				onValueChange: () => {},
				className: "flex gap-1",
				children: [
					{
						key: "bold",
						label: "Bold",
						Icon: se
					},
					{
						key: "italic",
						label: "Italic",
						Icon: le
					},
					{
						key: "bulletList",
						label: "Bulleted list",
						Icon: de
					},
					{
						key: "orderedList",
						label: "Numbered list",
						Icon: fe
					}
				].map(({ key: e, label: t, Icon: n }) => /* @__PURE__ */ g(h.ToggleItem, {
					value: e,
					"aria-label": t,
					disabled: R,
					className: S,
					onClick: () => Ve(e),
					onFocus: (e) => e.currentTarget.scrollIntoView({
						block: "nearest",
						inline: "nearest"
					}),
					children: /* @__PURE__ */ g(n, {
						"aria-hidden": "true",
						className: "mx-auto size-4"
					})
				}, e))
			}),
			/* @__PURE__ */ g(h.Button, {
				"aria-label": "Edit link",
				"aria-haspopup": "dialog",
				"aria-expanded": Le,
				disabled: R,
				className: S,
				onClick: He,
				children: /* @__PURE__ */ g(ue, {
					"aria-hidden": "true",
					className: "mx-auto size-4"
				})
			}),
			/* @__PURE__ */ g(h.Button, {
				"aria-label": "Undo edit",
				disabled: R || !Z?.undo,
				className: S,
				onClick: () => X.chain().focus().undo().run(),
				children: /* @__PURE__ */ g(me, {
					"aria-hidden": "true",
					className: "mx-auto size-4"
				})
			}),
			/* @__PURE__ */ g(h.Button, {
				"aria-label": "Redo edit",
				disabled: R || !Z?.redo,
				className: S,
				onClick: () => X.chain().focus().redo().run(),
				children: /* @__PURE__ */ g(pe, {
					"aria-hidden": "true",
					className: "mx-auto size-4"
				})
			})
		]
	});
	return /* @__PURE__ */ _(he, { children: [/* @__PURE__ */ _(ee, {
		component: "rich-text-composer",
		label: C,
		labelVisibility: be,
		description: w,
		error: T,
		submissionError: E,
		status: xe,
		inputId: L,
		disabled: k,
		readOnly: A,
		busy: j,
		announcement: Ne,
		onLabelClick: () => X?.commands.focus(),
		toolbar: Ge,
		secondaryActions: Oe,
		actions: ke,
		headerActions: De || M && X && (!$ || Z?.undo) ? /* @__PURE__ */ _(he, { children: [De, M && X && ($ ? Z?.undo && /* @__PURE__ */ g(o, {
			variant: "ghost",
			disabled: R,
			onClick: () => {
				X.chain().focus().undo().run(), U("Draft restored.");
			},
			children: we
		}) : /* @__PURE__ */ g(o, {
			variant: "ghost",
			disabled: R,
			onClick: () => {
				X.view.dispatch(y(X.state.tr)), X.chain().focus().clearContent().run(), U("Draft cleared. Undo is available.");
			},
			children: Ce
		}))] }) : void 0,
		children: [/* @__PURE__ */ g("div", {
			ref: z,
			className: "w-full min-w-0",
			children: /* @__PURE__ */ g(ge, { editor: X })
		}), I && /* @__PURE__ */ g("input", {
			ref: je,
			type: "hidden",
			name: I,
			form: Ee,
			disabled: k,
			value: N === "markdown" ? d(Z?.document ?? B) : JSON.stringify(Z?.document ?? B)
		})]
	}), /* @__PURE__ */ g(te, {
		title: "Edit link",
		description: "Set the text and destination for this link.",
		open: Le,
		onOpenChange: (e) => {
			e || Ue();
		},
		confirmLabel: "Save link",
		cancelLabel: "Cancel",
		error: Be,
		onConfirm: We,
		returnFocusRef: Me,
		children: /* @__PURE__ */ _("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ g(s, {
					label: "Link text",
					value: K,
					onChange: (e) => Re(e.target.value)
				}),
				/* @__PURE__ */ g(s, {
					label: "Destination",
					value: q,
					onChange: (e) => ze(e.target.value)
				}),
				Z?.link && /* @__PURE__ */ g(o, {
					variant: "secondary",
					onClick: () => {
						X?.chain().focus().setTextSelection(Y.current).unsetLink().run(), Ue();
					},
					children: "Remove link"
				})
			]
		})
	})] });
}
export { C as RichTextComposer };
