import { richTextDocumentSchema as e } from "./rich-text-composer.contract.js";
import { emptyRichTextDocument as t, isSafeRichTextLink as n } from "./rich-text-composer.runtime.js";
import { validateRichTextMarkdown as r } from "./rich-text-composer.markdown.js";
import "@tiptap/core";
import i from "@tiptap/starter-kit";
import { MarkdownManager as a } from "@tiptap/markdown";
// src/components/rich-text-composer/rich-text-composer.document.ts
var o = [i.configure({
	heading: { levels: [
		1,
		2,
		3
	] },
	blockquote: !1,
	code: !1,
	codeBlock: !1,
	horizontalRule: !1,
	strike: !1,
	underline: !1,
	trailingNode: !1,
	link: {
		openOnClick: !1,
		autolink: !1,
		linkOnPaste: !1,
		isAllowedUri: n,
		HTMLAttributes: {
			target: null,
			rel: "noopener noreferrer"
		}
	}
})];
function s(t) {
	let n = (e) => ({
		type: e.type,
		...e.text === void 0 ? {} : { text: e.text },
		...e.type === "heading" ? { attrs: { level: e.attrs?.level } } : {},
		...e.type === "orderedList" ? { attrs: { start: e.attrs?.start ?? 1 } } : {},
		...e.marks ? { marks: e.marks.map((e) => e.type === "link" ? {
			type: "link",
			attrs: { href: e.attrs?.href }
		} : { type: e.type }) } : {},
		...e.content ? { content: e.content.map(n) } : {}
	});
	return e.parse(n(t));
}
var c;
function l() {
	return c ??= new a({ extensions: o });
}
function u(n, i) {
	if (i === "json") return e.parse(n ?? t);
	if (n !== void 0 && typeof n != "string") throw Error("Markdown format requires a string value.");
	let a = n ?? "";
	r(a);
	let o = l().parse(a);
	return s(o.content?.length ? o : t);
}
function d(t) {
	return l().serialize(e.parse(t));
}
export { u as parseRichTextValue, s as portable, o as richTextExtensions, d as serializeRichTextMarkdown };
