import { typographyProps as e } from "../../lib/typography.js";
import { Dialog as t, DialogClose as n, DialogContent as r, DialogDescription as i, DialogFooter as a, DialogHeader as o, DialogTitle as s, DialogTrigger as c } from "../ui/dialog.js";
import { Alert as l } from "../alert/alert.js";
import { Button as u } from "../button/button.js";
import { dialogDefaults as d } from "./dialog.runtime.js";
import { dialogMeta as f } from "./dialog.meta.js";
import { useRef as p, useState as m } from "react";
import { jsx as h, jsxs as g } from "react/jsx-runtime";
// src/components/dialog/dialog.tsx
var _ = "max-h-[calc(100dvh-2rem)] overflow-y-auto", v = "leading-snug wrap-anywhere";
function y({ title: y, description: b, confirmLabel: x, confirmVariant: S = d.confirmVariant, cancelLabel: C = d.cancelLabel, error: w, open: T, defaultOpen: E = d.defaultOpen, onOpenChange: D, trigger: O, onConfirm: k, children: A, returnFocusRef: j }) {
	let [M, N] = m(E), P = p(null), [F, I] = m(!1), L = p(!1), R = T ?? M, z = (e) => {
		(e || !L.current) && (T === void 0 && N(e), D?.(e));
	}, B = async () => {
		if (F) return;
		let e = k?.();
		if (!(e instanceof Promise)) return z(!1);
		L.current = !0, I(!0);
		try {
			await e, L.current = !1, z(!1);
		} catch {} finally {
			L.current = !1, I(!1);
		}
	};
	return /* @__PURE__ */ g(t, {
		open: R,
		onOpenChange: z,
		children: [O && /* @__PURE__ */ h(c, {
			asChild: !0,
			children: O
		}), /* @__PURE__ */ g(r, {
			"data-component": f.id,
			className: _,
			onOpenAutoFocus: (e) => {
				S === "destructive" && (e.preventDefault(), P.current?.focus());
			},
			onCloseAutoFocus: (e) => {
				j?.current && (e.preventDefault(), j.current.focus());
			},
			...b ? {} : { "aria-describedby": void 0 },
			children: [
				/* @__PURE__ */ g(o, {
					className: "min-w-0 pr-8",
					children: [/* @__PURE__ */ h(s, {
						...e("dialog", "title"),
						className: v,
						children: y
					}), b && /* @__PURE__ */ h(i, {
						...e("dialog", "description"),
						className: "wrap-anywhere",
						children: b
					})]
				}),
				A && /* @__PURE__ */ h("div", {
					...e("dialog", "body"),
					className: "min-w-0",
					children: A
				}),
				w && /* @__PURE__ */ h(l, {
					title: w,
					variant: "destructive",
					live: "assertive"
				}),
				/* @__PURE__ */ g(a, { children: [/* @__PURE__ */ h(n, {
					asChild: !0,
					children: /* @__PURE__ */ h(u, {
						ref: P,
						variant: "secondary",
						disabled: F,
						children: C
					})
				}), x && /* @__PURE__ */ h(u, {
					variant: S,
					loading: F,
					onClick: B,
					children: x
				})] })
			]
		})]
	});
}
export { y as Dialog };
