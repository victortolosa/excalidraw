// src/components/dialog/dialog.runtime.ts
var e = {
	confirmVariant: "primary",
	cancelLabel: "Cancel",
	defaultOpen: !1
};
export { e as dialogDefaults };
