// src/components/popover/popover.runtime.ts
var e = {
	defaultOpen: !1,
	side: "bottom",
	align: "center"
};
export { e as popoverDefaults };
