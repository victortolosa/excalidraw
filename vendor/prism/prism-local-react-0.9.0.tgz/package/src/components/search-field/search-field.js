import { typographyProps as e } from "../../lib/typography.js";
import { IconButton as t } from "../icon-button/icon-button.js";
import { Field as n, FieldDescription as r, FieldError as i, FieldLabel as a } from "../ui/field.js";
import { InputGroup as o, InputGroupAddon as s, InputGroupInput as c } from "../ui/input-group.js";
import { searchFieldDefaults as l } from "./search-field.runtime.js";
import { useId as u, useImperativeHandle as d, useRef as f } from "react";
import { Search as p } from "lucide-react";
import { jsx as m, jsxs as h } from "react/jsx-runtime";
// src/components/search-field/search-field.tsx
function g({ label: g, labelVisibility: _ = l.labelVisibility, placeholder: v, description: y, error: b, id: x, disabled: S = l.disabled, readOnly: C = l.readOnly, onClear: w, ref: T, ...E }) {
	let D = f(null);
	d(T, () => D.current, []);
	let O = u(), k = x ?? O, A = [y && `${k}-description`, b && `${k}-error`].filter(Boolean).join(" ") || void 0;
	return /* @__PURE__ */ h(n, {
		"data-component": "search-field",
		"data-invalid": !!b,
		"data-disabled": S,
		className: "min-w-0",
		children: [
			/* @__PURE__ */ m(a, {
				...e("search-field", "label"),
				htmlFor: k,
				className: _ === "hidden" ? "sr-only" : "break-words",
				children: g
			}),
			/* @__PURE__ */ h(o, {
				className: "transition-none has-[[data-slot=input-group-control]:focus-visible]:ring-ring has-[[data-slot=input-group-control]:focus-visible]:border-ring",
				children: [
					/* @__PURE__ */ m(c, {
						ref: D,
						...e("search-field", "control"),
						...E,
						id: k,
						type: "search",
						placeholder: v,
						disabled: S,
						readOnly: C,
						"aria-invalid": b ? !0 : void 0,
						"aria-describedby": A,
						className: "text-foreground transition-none [&::-webkit-search-cancel-button]:appearance-none"
					}),
					/* @__PURE__ */ m(s, {
						align: "inline-start",
						"aria-hidden": "true",
						children: /* @__PURE__ */ m(p, { "aria-hidden": "true" })
					}),
					w && !!E.value && !S && !C && /* @__PURE__ */ m(s, {
						align: "inline-end",
						children: /* @__PURE__ */ m(t, {
							icon: "close",
							label: `Clear ${g}`,
							variant: "secondary",
							onClick: () => {
								w(), D.current?.focus();
							}
						})
					})
				]
			}),
			y && /* @__PURE__ */ m(r, {
				...e("search-field", "description"),
				id: `${k}-description`,
				className: "break-words",
				children: y
			}),
			b && /* @__PURE__ */ m(i, {
				...e("search-field", "error"),
				id: `${k}-error`,
				className: "break-words",
				children: b
			})
		]
	});
}
export { g as SearchField };
