import { typographyProps as e } from "../../lib/typography.js";
import { Field as t, FieldDescription as n, FieldError as r, FieldLabel as i } from "../ui/field.js";
import { Select as a, SelectContent as o, SelectItem as s, SelectTrigger as c, SelectValue as l } from "../ui/select.js";
import { selectDefaults as u } from "./select.runtime.js";
import { createElement as d, useId as f } from "react";
import { jsx as p, jsxs as m } from "react/jsx-runtime";
// src/components/select/select.tsx
function h({ label: h, labelVisibility: g = u.labelVisibility, options: _, placeholder: v, description: y, error: b, id: x, name: S, form: C, required: w = u.required, disabled: T = u.disabled, value: E, defaultValue: D, onValueChange: O, open: k, onOpenChange: A }) {
	let j = f(), M = x ?? j, N = `${M}-trigger`, P = [y && `${M}-description`, b && `${M}-error`].filter(Boolean).join(" ") || void 0;
	return /* @__PURE__ */ m(t, {
		"data-component": "select",
		"data-invalid": !!b,
		"data-disabled": T,
		className: "min-w-0",
		children: [
			/* @__PURE__ */ m(i, {
				...e("select", "label"),
				htmlFor: N,
				className: g === "hidden" ? "sr-only" : "break-words",
				children: [h, w && /* @__PURE__ */ p("span", {
					"aria-hidden": "true",
					children: " (required)"
				})]
			}),
			/* @__PURE__ */ m(a, {
				name: S,
				form: C,
				disabled: T,
				required: w,
				value: E,
				defaultValue: D,
				onValueChange: O,
				open: k,
				onOpenChange: A,
				children: [/* @__PURE__ */ p(c, {
					...e("select", "control"),
					id: N,
					"aria-invalid": b ? !0 : void 0,
					"aria-describedby": P,
					className: "transition-none w-full text-foreground focus-visible:ring-ring aria-invalid:focus-visible:ring-ring",
					children: /* @__PURE__ */ p(l, { placeholder: v })
				}), /* @__PURE__ */ p(o, { children: _.map((t) => /* @__PURE__ */ d(s, {
					...e("select", "option"),
					key: t.value,
					value: t.value,
					disabled: t.disabled
				}, t.label)) })]
			}),
			y && /* @__PURE__ */ p(n, {
				...e("select", "description"),
				id: `${M}-description`,
				className: "break-words",
				children: y
			}),
			b && /* @__PURE__ */ p(r, {
				...e("select", "error"),
				id: `${M}-error`,
				className: "break-words",
				children: b
			})
		]
	});
}
export { h as Select };
