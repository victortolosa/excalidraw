// src/components/select/select.runtime.ts
var e = {
	labelVisibility: "visible",
	required: !1,
	disabled: !1
};
export { e as selectDefaults };
