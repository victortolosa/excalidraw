import { typographyProps as e } from "../../lib/typography.js";
import { IconButton as t } from "../icon-button/icon-button.js";
import { Button as n } from "../button/button.js";
import { DropdownMenu as r, DropdownMenuContent as i, DropdownMenuItem as a, DropdownMenuTrigger as o } from "../ui/dropdown-menu.js";
import { dropdownMenuDefaults as s, dropdownMenuItemDefaults as c } from "./dropdown-menu.runtime.js";
import { createElement as l, useRef as u } from "react";
import { jsx as d, jsxs as f } from "react/jsx-runtime";
// src/components/dropdown-menu/dropdown-menu.tsx
var p = "max-w-[calc(100vw-2rem)]", m = "whitespace-normal wrap-anywhere";
function h({ label: h, items: g, trigger: _ = s.trigger, disabled: v = s.disabled, align: y = s.align, onAction: b }) {
	let x = u(null);
	return /* @__PURE__ */ f(r, {
		modal: !1,
		children: [/* @__PURE__ */ d(o, {
			asChild: !0,
			children: _ === "icon" ? /* @__PURE__ */ d(t, {
				ref: x,
				icon: "more",
				label: h,
				variant: "secondary",
				disabled: v
			}) : /* @__PURE__ */ d(n, {
				ref: x,
				variant: "secondary",
				disabled: v,
				children: h
			})
		}), /* @__PURE__ */ d(i, {
			"data-component": "dropdown-menu",
			align: y,
			className: p,
			children: g.map((t) => /* @__PURE__ */ l(a, {
				...e("dropdown-menu", "option"),
				key: t.id,
				disabled: t.disabled ?? c.disabled,
				variant: t.variant ?? c.variant,
				className: m,
				onSelect: () => b(t.id, x.current)
			}, t.label))
		})]
	});
}
export { h as DropdownMenu };
