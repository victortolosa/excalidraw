// src/components/dropdown-menu/dropdown-menu.runtime.ts
var e = {
	disabled: !1,
	align: "end",
	trigger: "text"
}, t = {
	disabled: !1,
	variant: "default"
};
export { e as dropdownMenuDefaults, t as dropdownMenuItemDefaults };
