// src/components/combobox/combobox.runtime.ts
var e = {
	labelVisibility: "visible",
	required: !1,
	disabled: !1,
	openOnInputClick: !1
};
export { e as comboboxDefaults };
