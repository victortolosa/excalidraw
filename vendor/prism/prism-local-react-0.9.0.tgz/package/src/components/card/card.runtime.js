// src/components/card/card.runtime.ts
var e = { headingLevel: "2" };
export { e as cardDefaults };
