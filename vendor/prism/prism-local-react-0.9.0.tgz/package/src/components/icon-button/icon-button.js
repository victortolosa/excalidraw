import { actionIcons as e } from "../../lib/action-icons.js";
import { Button as t } from "../ui/button.js";
import { iconButtonDefaults as n } from "./icon-button.runtime.js";
import { iconButtonMeta as r } from "./icon-button.meta.js";
import { jsx as i } from "react/jsx-runtime";
// src/components/icon-button/icon-button.tsx
var a = {
	primary: "default",
	secondary: "outline"
}, o = "transition-none size-(--icon-button-size) p-0 rounded-(--button-radius) focus-visible:ring-ring";
function s({ icon: s, label: c, variant: l = n.variant, type: u = n.type, disabled: d = n.disabled, ...f }) {
	let p = e[s];
	return /* @__PURE__ */ i(t, {
		...f,
		variant: a[l],
		size: "icon-lg",
		type: u,
		disabled: d,
		"aria-label": c,
		"data-component": r.id,
		className: o,
		children: /* @__PURE__ */ i(p, {
			"aria-hidden": "true",
			className: "size-4"
		})
	});
}
export { s as IconButton };
