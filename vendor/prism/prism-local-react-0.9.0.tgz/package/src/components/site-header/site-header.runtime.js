import { pageDefaults as e } from "../page/page.runtime.js";
// src/components/site-header/site-header.runtime.ts
var t = {
	layout: "compact",
	navigationPlacement: "separate",
	mainId: e.id,
	menuLabel: "Menu",
	skipLabel: "Skip to content"
};
export { t as siteHeaderDefaults };
