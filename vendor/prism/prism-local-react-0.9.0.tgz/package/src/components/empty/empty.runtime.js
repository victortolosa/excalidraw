// src/components/empty/empty.runtime.ts
var e = { headingLevel: "3" };
export { e as emptyDefaults };
