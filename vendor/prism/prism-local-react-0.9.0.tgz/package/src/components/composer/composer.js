import { typographyProps as e } from "../../lib/typography.js";
import { InputGroupTextarea as t } from "../ui/input-group.js";
import { Button as n } from "../button/button.js";
import { ComposerPanel as r } from "./composer-panel.js";
import { composerDefaults as i } from "./composer.runtime.js";
import { useEffect as a, useId as o, useImperativeHandle as s, useLayoutEffect as c, useRef as l, useState as u } from "react";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
// src/components/composer/composer.tsx
function m({ label: m, labelVisibility: h = i.labelVisibility, description: g, error: _, submissionError: v, status: y, id: b, rows: x = i.rows, maxRows: S, maxLength: C, required: w = i.required, disabled: T = i.disabled, readOnly: E = i.readOnly, busy: D = i.busy, clearable: O = i.clearable, clearLabel: ee = i.clearLabel, undoLabel: k = i.undoLabel, headerActions: A, toolbar: j, secondaryActions: M, actions: N, value: P, defaultValue: F = "", onValueChange: I, onChange: te, ref: ne, ...L }) {
	let R = o(), z = b ?? R, B = l(null), [V, H] = u(F), [U, W] = u(), [G, K] = u(""), q = P ?? V, J = T || E || D, Y = [
		g && `${z}-description`,
		_ && `${z}-error`,
		v && `${z}-submission-error`
	].filter(Boolean).join(" ") || void 0;
	s(ne, () => B.current, []);
	let [X, re] = u({
		text: q,
		locked: J,
		clearable: O
	});
	(q !== X.text || J !== X.locked || O !== X.clearable) && (re({
		text: q,
		locked: J,
		clearable: O
	}), (q !== "" || J || !O) && (W(void 0), K("")));
	function Z(e) {
		P === void 0 && H(e), I?.(e);
	}
	a(() => {
		let e = B.current?.form;
		if (!e) return;
		let t = (e) => {
			queueMicrotask(() => {
				e.defaultPrevented || (W(void 0), K(""), P === void 0 && (H(F), I?.(F)));
			});
		};
		return e.addEventListener("reset", t), () => e.removeEventListener("reset", t);
	}, [
		P,
		F,
		I,
		L.form
	]), c(() => {
		let e = B.current;
		if (!e) return;
		function t() {
			let t = e, n = getComputedStyle(t), r = parseFloat(n.lineHeight), a = parseFloat(n.paddingTop) + parseFloat(n.paddingBottom), o = parseFloat(n.borderTopWidth) + parseFloat(n.borderBottomWidth), s = x * r + a + o, c = (S ?? Math.max(x, i.maxRows)) * r + a + o;
			t.style.height = "auto", t.style.height = `${Math.min(c, Math.max(s, t.scrollHeight + o))}px`, t.style.overflowY = t.scrollHeight + o > c ? "auto" : "hidden";
		}
		t();
		let n = e.clientWidth, r = new ResizeObserver(() => {
			e.clientWidth !== n && (n = e.clientWidth, t());
		});
		r.observe(e);
		let a = new MutationObserver(t);
		for (let t = e.parentElement; t; t = t.parentElement) a.observe(t, {
			attributes: !0,
			attributeFilter: [
				"data-density",
				"data-mode",
				"class",
				"style"
			]
		});
		return window.addEventListener("resize", t), document.fonts?.addEventListener("loadingdone", t), () => {
			r.disconnect(), a.disconnect(), window.removeEventListener("resize", t), document.fonts?.removeEventListener("loadingdone", t);
		};
	}, [
		q,
		x,
		S
	]);
	function ie() {
		!J && q && (W(q), Z(""), K("Draft cleared. Undo is available until the next edit."), B.current?.focus());
	}
	function ae() {
		J || U === void 0 || q !== "" || (Z(U), W(void 0), K("Draft restored."), B.current?.focus());
	}
	let Q = U !== void 0 && q === "", $ = !E && O && (q !== "" || Q);
	return /* @__PURE__ */ f(r, {
		label: m,
		labelVisibility: h,
		required: w,
		disabled: T,
		readOnly: E,
		busy: D,
		description: g,
		error: _,
		submissionError: v,
		status: y,
		inputId: z,
		announcement: G,
		toolbar: j,
		secondaryActions: M,
		actions: N,
		headerActions: A || $ ? /* @__PURE__ */ p(d, { children: [A, $ && (Q ? /* @__PURE__ */ f(n, {
			variant: "ghost",
			disabled: J,
			onClick: ae,
			children: k
		}) : /* @__PURE__ */ f(n, {
			variant: "ghost",
			disabled: J,
			onClick: ie,
			children: ee
		}))] }) : void 0,
		children: /* @__PURE__ */ f(t, {
			...e("textarea", "control"),
			...L,
			ref: B,
			id: z,
			rows: x,
			value: q,
			maxLength: C,
			required: w,
			disabled: T,
			readOnly: E || D,
			"aria-invalid": _ ? !0 : void 0,
			"aria-describedby": Y,
			className: "min-h-0 flex-none field-sizing-fixed px-0 text-foreground",
			onChange: (e) => {
				W(void 0), K(""), Z(e.target.value), te?.(e);
			}
		})
	});
}
export { m as Composer };
