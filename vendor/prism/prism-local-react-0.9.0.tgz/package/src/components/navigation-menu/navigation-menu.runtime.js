// src/components/navigation-menu/navigation-menu.runtime.ts
var e = { orientation: "horizontal" };
export { e as navigationMenuDefaults };
