// src/components/table/table.runtime.ts
var e = {
	hideCaption: !1,
	emptyMessage: "No items to show."
}, t = { align: "start" };
export { t as tableColumnDefaults, e as tableDefaults };
