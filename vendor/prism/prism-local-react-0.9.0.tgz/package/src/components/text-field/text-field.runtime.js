// src/components/text-field/text-field.runtime.ts
var e = {
	labelVisibility: "visible",
	type: "text",
	required: !1,
	disabled: !1,
	readOnly: !1
};
export { e as textFieldDefaults };
