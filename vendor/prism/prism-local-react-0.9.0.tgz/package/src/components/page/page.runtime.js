// src/components/page/page.runtime.ts
var e = {
	id: "main-content",
	width: "standard",
	layout: "contained",
	actionsLayout: "auto"
};
export { e as pageDefaults };
