// src/components/site-footer/site-footer.runtime.ts
var e = {
	navigationLabel: "Footer",
	legalLabel: "Legal",
	groups: [],
	legalLinks: []
};
export { e as siteFooterDefaults };
