// src/components/checkbox/checkbox.runtime.ts
var e = {
	required: !1,
	disabled: !1,
	defaultChecked: !1
};
export { e as checkboxDefaults };
