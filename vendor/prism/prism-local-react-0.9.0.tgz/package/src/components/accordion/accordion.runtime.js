// src/components/accordion/accordion.runtime.ts
var e = {
	type: "single",
	defaultValue: "",
	disabled: !1
};
export { e as accordionDefaults };
