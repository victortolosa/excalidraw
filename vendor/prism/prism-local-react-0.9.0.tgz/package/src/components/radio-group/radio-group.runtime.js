// src/components/radio-group/radio-group.runtime.ts
var e = {
	required: !1,
	disabled: !1,
	orientation: "vertical"
};
export { e as radioGroupDefaults };
