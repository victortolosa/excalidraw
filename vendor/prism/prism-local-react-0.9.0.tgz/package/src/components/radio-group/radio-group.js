import { typographyProps as e } from "../../lib/typography.js";
import { Field as t, FieldContent as n, FieldDescription as r, FieldError as i, FieldLabel as a, FieldLegend as o, FieldSet as s } from "../ui/field.js";
import { RadioGroup as c, RadioGroupItem as l } from "../ui/radio-group.js";
import { radioGroupDefaults as u } from "./radio-group.runtime.js";
import { useId as d } from "react";
import { jsx as f, jsxs as p } from "react/jsx-runtime";
// src/components/radio-group/radio-group.tsx
function m({ label: m, options: h, description: g, error: _, id: v, name: y, form: b, required: x = u.required, disabled: S = u.disabled, orientation: C = u.orientation, value: w, defaultValue: T, onValueChange: E }) {
	let D = d(), O = v ?? D, k = [g && `${O}-description`, _ && `${O}-error`].filter(Boolean).join(" ") || void 0;
	return /* @__PURE__ */ p(s, {
		"data-component": "radio-group",
		"data-invalid": !!_,
		"data-disabled": S,
		className: "min-w-0",
		children: [
			/* @__PURE__ */ p(o, {
				...e("radio-group", "legend"),
				className: "break-words",
				children: [m, x && /* @__PURE__ */ f("span", {
					"aria-hidden": "true",
					children: " (required)"
				})]
			}),
			/* @__PURE__ */ f(c, {
				id: O,
				name: y,
				form: b,
				value: w,
				defaultValue: T,
				onValueChange: E,
				disabled: S,
				required: x,
				"aria-invalid": _ ? !0 : void 0,
				"aria-describedby": k,
				className: C === "horizontal" ? "flex flex-wrap gap-4" : "grid gap-2",
				children: h.map((i, o) => {
					let s = `${O}-option-${o}`, c = i.description ? `${s}-description` : void 0, u = S || i.disabled;
					return /* @__PURE__ */ p(t, {
						orientation: "horizontal",
						"data-disabled": u,
						className: "min-w-0",
						children: [/* @__PURE__ */ f(l, {
							id: s,
							value: i.value,
							disabled: u,
							"aria-describedby": c,
							className: "focus-visible:ring-ring aria-invalid:focus-visible:ring-ring"
						}), /* @__PURE__ */ p(n, { children: [/* @__PURE__ */ f(a, {
							...e("radio-group", "label"),
							htmlFor: s,
							className: "break-words",
							children: i.label
						}), i.description && /* @__PURE__ */ f(r, {
							...e("radio-group", "option-description"),
							id: c,
							className: "break-words",
							children: i.description
						})] })]
					}, i.value);
				})
			}),
			g && /* @__PURE__ */ f(r, {
				...e("radio-group", "description"),
				id: `${O}-description`,
				className: "break-words",
				children: g
			}),
			_ && /* @__PURE__ */ f(i, {
				...e("radio-group", "error"),
				id: `${O}-error`,
				className: "break-words",
				children: _
			})
		]
	});
}
export { m as RadioGroup };
