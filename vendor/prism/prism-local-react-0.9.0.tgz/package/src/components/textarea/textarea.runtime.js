// src/components/textarea/textarea.runtime.ts
var e = {
	labelVisibility: "visible",
	required: !1,
	disabled: !1,
	readOnly: !1
};
export { e as textareaDefaults };
