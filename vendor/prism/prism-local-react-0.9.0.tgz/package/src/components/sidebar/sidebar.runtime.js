// src/components/sidebar/sidebar.runtime.ts
var e = { collapsed: !1 };
export { e as sidebarDefaults };
