import { typographyProps as e } from "../../lib/typography.js";
import { Sidebar as t, SidebarContent as n, SidebarGroup as r, SidebarGroupContent as i, SidebarGroupLabel as a, SidebarMenu as o, SidebarMenuButton as s, SidebarMenuItem as c, SidebarProvider as l, SidebarTrigger as u } from "../ui/sidebar.js";
import { TooltipProvider as d } from "../ui/tooltip.js";
import { sidebarDefaults as f } from "./sidebar.runtime.js";
import { ChartNoAxesColumn as p, Folder as m, House as h, Layers3 as g, Settings as _, Users as v } from "lucide-react";
import { jsx as y, jsxs as b } from "react/jsx-runtime";
// src/components/sidebar/sidebar.tsx
var x = {
	home: h,
	layers: g,
	folder: m,
	settings: _,
	users: v,
	chart: p
};
function S({ label: p, items: m, currentId: h, collapsed: g = f.collapsed }) {
	return /* @__PURE__ */ y(d, { children: /* @__PURE__ */ b(l, {
		defaultOpen: !g,
		"data-component": "sidebar",
		children: [/* @__PURE__ */ y(t, {
			collapsible: "icon",
			children: /* @__PURE__ */ y(n, { children: /* @__PURE__ */ y("nav", {
				"aria-label": p,
				children: /* @__PURE__ */ b(r, { children: [/* @__PURE__ */ y(a, {
					...e("sidebar", "group"),
					children: p
				}), /* @__PURE__ */ y(i, { children: /* @__PURE__ */ y(o, { children: m.map((t) => {
					let n = x[t.icon], r = t.id === h;
					return /* @__PURE__ */ y(c, { children: /* @__PURE__ */ y(s, {
						asChild: !0,
						isActive: r,
						tooltip: { children: /* @__PURE__ */ y("span", {
							...e("sidebar", "tooltip"),
							children: t.label
						}) },
						children: /* @__PURE__ */ b("a", {
							...e("sidebar", r ? "active-link" : "link"),
							href: t.href,
							"aria-current": r ? "page" : void 0,
							children: [/* @__PURE__ */ y(n, { "aria-hidden": "true" }), /* @__PURE__ */ y("span", { children: t.label })]
						})
					}) }, t.id);
				}) }) })] })
			}) })
		}), /* @__PURE__ */ y(u, { "aria-label": `Toggle ${p}` })]
	}) });
}
export { S as Sidebar };
