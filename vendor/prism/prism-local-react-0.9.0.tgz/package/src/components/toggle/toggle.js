import { typographyProps as e } from "../../lib/typography.js";
import { Toggle as t } from "../ui/toggle.js";
import { actionIcons as n } from "../../lib/action-icons.js";
import { toggleDefaults as r } from "./toggle.runtime.js";
import { StarIcon as i } from "lucide-react";
import { jsx as a } from "react/jsx-runtime";
// src/components/toggle/toggle.tsx
function o({ label: o, icon: s, variant: c = r.variant, disabled: l = r.disabled, pending: u = r.pending, defaultPressed: d = r.defaultPressed, onPressedChange: f, ...p }) {
	let m = s === "star" ? i : s ? n[s] : void 0;
	return /* @__PURE__ */ a(t, {
		...p,
		defaultPressed: d,
		disabled: l,
		"aria-disabled": u || void 0,
		"aria-busy": u || void 0,
		onClick: (e) => {
			u && e.preventDefault();
		},
		onPressedChange: (e) => {
			u || f?.(e);
		},
		variant: c === "outline" ? "outline" : "default",
		size: "lg",
		"aria-label": m ? o : void 0,
		"data-component": "toggle",
		...e("toggle", "label"),
		className: "transition-none h-auto min-h-9 min-w-9 max-w-full whitespace-normal wrap-anywhere focus-visible:ring-ring data-[state=on]:bg-accent data-[state=on]:text-accent-foreground hover:bg-accent hover:text-accent-foreground",
		children: m ? /* @__PURE__ */ a(m, {
			"aria-hidden": "true",
			className: "size-4"
		}) : o
	});
}
export { o as Toggle };
