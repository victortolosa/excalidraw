// src/components/alert/alert.runtime.ts
var e = {
	variant: "neutral",
	live: "off"
};
export { e as alertDefaults };
