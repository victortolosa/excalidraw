#!/usr/bin/env node
import { readFileSync, writeFileSync, existsSync, mkdirSync, lstatSync, realpathSync, readdirSync, rmSync } from 'node:fs'
import { dirname, resolve, relative } from 'node:path'
import { fileURLToPath } from 'node:url'

const start = '<!-- prism:instructions:start -->', end = '<!-- prism:instructions:end -->'
export function setupPrism(root, packageDirectory) {
  root = realpathSync(root)
  packageDirectory = realpathSync(packageDirectory)
  const release = JSON.parse(readFileSync(resolve(packageDirectory,'release.json'),'utf8'))
  const manifest = JSON.parse(readFileSync(resolve(packageDirectory,'agent/manifest.json'),'utf8'))
  if (release.version !== manifest.releaseIdentity.version || release.sourceDigest !== manifest.releaseIdentity.sourceDigest) throw new Error('Prism implementation/instruction identity mismatch')
  const packagePath = resolve(root,'package.json')
  const pkg = JSON.parse(readFileSync(packagePath,'utf8'))
  if (![pkg.dependencies, pkg.devDependencies].some(deps => deps?.[release.packageName ?? '@prism-local/react'])) throw new Error('Install Prism as a project dependency before setup')
  const entry = relative(root,resolve(packageDirectory,'AGENTS.md')).replaceAll('\\','/')
  if (entry.startsWith('../')) throw new Error('Prism must be installed inside this project; workspace-hoisted installations require setup at the owning workspace root')
  const updates = []
  const managed = (file, content) => {
    const path=resolve(root,file)
    if (existsSync(path) && lstatSync(path).isSymbolicLink()) throw new Error(`Refusing to change symlinked instruction file: ${file}`)
    const old=existsSync(path) ? readFileSync(path,'utf8') : ''
    const a=old.indexOf(start), b=old.indexOf(end)
    if ((a<0)!==(b<0) || (a>=0 && (b<a || old.indexOf(start,a+start.length)>=0 || old.indexOf(end,b+end.length)>=0))) throw new Error(`Invalid Prism instruction markers: ${file}`)
    const block=`${start}\n${content}\n${end}`
    const next=a>=0 ? old.slice(0,a)+block+old.slice(b+end.length) : `${old}${old && !old.endsWith('\n') ? '\n' : ''}${old ? '\n' : ''}${block}\n`
    if(next!==old) updates.push([path,next])
  }
  managed('AGENTS.md', `## Prism design system\n\nFor Prism design and React web implementation, read [the installed release instructions](${entry}) first. Use the \`prism-explore\` skill when the design is unsettled and \`prism-build\` for approved designs and production work. Follow its discovery, rules, audit and validation workflow; retrieve only selected APIs. Project instructions remain in force. Read the installed release again after dependency updates.`)
  managed('CLAUDE.md', `For Prism design and React web implementation, read [the installed release instructions](${entry}) and the project AGENTS.md. Preserve project rules and use release-matched guidance.`)
  const skills = {
    'prism-build': ['Use when implementing an approved design, or when explicitly asked to build a production React web page or screen with the installed Prism release. Not for trying out unsettled directions; use prism-explore for those.', 'Prism build', 'build', 'before implementing. Use the installed supported inventory and portable audit workflow. Native mobile implementations are outside this release.'],
    'prism-explore': ['Use when asked to explore, wireframe, mock up, or try directions for an interface whose design is not settled yet. Not for approved designs or production builds; use prism-build for those.', 'Prism explore', 'explore', 'before exploring. Exploration output is disposable and stays out of shipped code.'],
  }
  // .agents is the shared location; Claude Code only discovers skills under .claude.
  for (const directory of ['.agents','.claude']) for (const [name,[description,title,label,guidance]] of Object.entries(skills)) {
    const skillPath=resolve(root,directory,'skills',name,'SKILL.md')
    if (existsSync(skillPath) && !readFileSync(skillPath,'utf8').includes('<!-- prism:skill -->')) continue
    if (existsSync(skillPath) && lstatSync(skillPath).isSymbolicLink()) throw new Error('Refusing to change symlinked Prism skill')
    const target=relative(dirname(skillPath),resolve(packageDirectory,'agent/skills',name,'SKILL.md')).replaceAll('\\','/')
    const text=`---\nname: ${name}\ndescription: ${description}\n---\n\n<!-- prism:skill -->\n# ${title}\n\nRead [the installed ${label} skill](${target}) and its release entry point ${guidance}\n`
    if(!existsSync(skillPath) || readFileSync(skillPath,'utf8')!==text) updates.push([skillPath,text])
  }
  // prism-build was named prism-page in earlier releases; remove only adapters setup generated, never custom skills.
  const retired=[]
  for (const directory of ['.agents','.claude']) {
    const oldPath=resolve(root,directory,'skills/prism-page/SKILL.md')
    if (!existsSync(oldPath)) continue
    if (lstatSync(oldPath).isSymbolicLink()) throw new Error('Refusing to change symlinked Prism skill')
    if (readFileSync(oldPath,'utf8').includes('<!-- prism:skill -->')) retired.push(oldPath)
  }
  pkg.scripts ??= {}
  const scriptConflict=pkg.scripts['prism:check'] && pkg.scripts['prism:check']!=='prism-check'
  if(!pkg.scripts['prism:check']) {pkg.scripts['prism:check']='prism-check'; updates.push([packagePath,JSON.stringify(pkg,null,2)+'\n'])}
  for (const [path,text] of updates) {mkdirSync(dirname(path),{recursive:true}); writeFileSync(path,text)}
  for (const path of retired) {rmSync(path); if(!readdirSync(dirname(path)).length) rmSync(dirname(path),{recursive:true})}
  return {version:release.version,changed:[...updates.map(([path])=>path),...retired].map(path=>relative(root,path)),scriptConflict:Boolean(scriptConflict)}
}
if (process.argv[1] && fileURLToPath(import.meta.url) === realpathSync(resolve(process.argv[1]))) {
  try {
    const args=process.argv.slice(2)
    if(args.length && (args.length!==2 || args[0]!=='--root')) throw new Error('Usage: prism-setup [--root <project>]')
    const result=setupPrism(resolve(args[1] ?? process.cwd()),dirname(fileURLToPath(import.meta.url)))
    console.log(`Connected Prism ${result.version}: ${result.changed.length ? result.changed.join(', ') : 'already configured'}.`)
    console.log(result.scriptConflict ? 'Existing prism:check script preserved; integrate the installed prism-check command manually.' : 'Run npm run prism:check and add it to existing project validation/CI.')
    console.log('Import Prism styles once and use supported React/toolchain versions; setup preserves existing validation and app configuration.')
  } catch(error) {console.error(`Prism setup failed: ${error.message}`);process.exitCode=1}
}
