# Component index

One line per installed component and block. Pick from this list, then read only the linked guidance for the parts you use, and read it before calling something a gap. Open the full [discovery manifest](manifest.json) only when this index is not enough.

## Components

- [accordion](../context/accordion.md): A stack of h3 disclosures under an h2.
- [alert](../context/alert.md): A message about the page or a task, with an optional explanation.
- [avatar](../context/avatar.md): A person's or entity's image, falling back to initials.
- [badge](../context/badge.md): A short, non-interactive label for a status, role, or category.
- [breadcrumb](../context/breadcrumb.md): An ordered navigation path to the current page.
- [button](../context/button.md): Triggers an action or submits a form.
- [button-group](../context/button-group.md): A named group of related system Buttons.
- [card](../context/card.md): A non-interactive content group with a heading that inherits regional context by default.
- [carousel](../context/carousel.md): A manually advanced horizontal set of slides with visible controls and position feedback.
- [checkbox](../context/checkbox.md): A labeled two-state control for selecting independent options or confirming choices.
- [combobox](../context/combobox.md): A labeled searchable single-choice field for selecting one option from a list; use Select for a non-searchable list.
- [composer](../context/composer.md): A multiline text entry panel for composing one item, with optional toolbar above and actions below the text.
- [rich-text-composer](../context/rich-text-composer.md): Text editing with JSON or Markdown input/output, headings, bold, italic, lists and links in the shared Composer panel.
- [dialog](../context/dialog.md): A modal window for a focused task or decision that blocks the page until it is closed.
- [dropdown-menu](../context/dropdown-menu.md): A button-triggered list of row or object actions.
- [empty](../context/empty.md): A consistent message for an empty list or result set, with an optional description and action slot.
- [icon-button](../context/icon-button.md): Triggers a familiar compact action with a Lucide icon and an explicit accessible name.
- [item](../context/item.md): The list that contains Items.
- [navigation-menu](../context/navigation-menu.md): A named set of page links with current-page indication.
- [page](../context/page.md): The main landmark, default or custom page heading, and bounded content.
- [popover](../context/popover.md): Non-modal rich content adjacent to a button trigger, such as annotation details.
- [radio-group](../context/radio-group.md): A labeled group of mutually exclusive options where only one can be selected.
- [search-field](../context/search-field.md): A labeled native search input with a decorative search icon and persistent guidance.
- [section](../context/section.md): Unboxed content grouping with optional heading, description, and actions.
- [select](../context/select.md): A labeled single-select dropdown with options, persistent guidance, and errors.
- [separator](../context/separator.md): A non-interactive divider between content groups.
- [sidebar](../context/sidebar.md): A responsive named set of top-level page links.
- [site-footer](../context/site-footer.md): Site-wide grouped links, optional identity text, and legal information in a contentinfo landmark.
- [site-header](../context/site-header.md): Site identity, page skip link, and responsive navigation in a banner.
- [switch](../context/switch.md): A labeled toggle control for switching settings immediately on or off.
- [table](../context/table.md): A captioned data table of rows and columns.
- [tabs](../context/tabs.md): Switches between related panels of content in one place.
- [text-field](../context/text-field.md): A labeled single-line text, email or password input with persistent guidance and errors.
- [textarea](../context/textarea.md): A labeled multiline text input with persistent guidance and errors.
- [toast](../context/toast.md): Brief non-blocking outcome feedback via ToastProvider and useToast.
- [toggle](../context/toggle.md): A pressed/unpressed toolbar button for a mode or favorite state.

## Blocks

- [hero](../context/blocks/hero.md): Prism-authored page introduction with one H1, optional paired actions and bounded centered/split compositions.
- [signup-form](../context/blocks/signup-form.md): A signup form with name, email, password confirmation, Google signup and sign-in navigation.
