# Exploration design guidance

This file guides visual exploration, not production component APIs. The task brief and user-provided brand direction take precedence. Atlas and Editorial are test brands, not a mandatory visual identity.

## Product intent

Start from the primary user task, audience, content, and constraints in the brief. Make the main action and information hierarchy clear. Use realistic content and data; identify assumptions instead of disguising missing requirements with decorative filler.

## Fidelity

Exploration is for flexibility; build is for consistency, shared components and tokens. Nothing in exploration is required to match the system. Explorations are wireframes by default. Settle structure before style: layout, hierarchy, content, and flow. Default to neutral styling (the template's neutral token roles are a convenient starting point, not a rule), one type scale, plain boxes for imagery and media (labeled, not decorative), and no brand color, illustration, or motion beyond what explains an interaction. Real copy and realistic data still apply; wireframe means unstyled, not placeholder text. Show emphasis through size, weight, spacing, and position, not color.

Keep the wireframe to the bare minimum that answers the brief. Add extra screens, states, responsive variants, or detail only when the user expresses them.

Move to high fidelity only when the user asks for it or approves the wireframe direction. High fidelity is stricter than the wireframe: it is built from the installed system components, styles and theme, each part is checked against component guidance, and a part with no component stops for a decision (build it into the system, use a labeled temporary placeholder, or change the design) instead of being mocked silently. The visual direction below applies only to what the system's theme does not already decide.

## Visual direction (high fidelity only)

Choose a coherent direction appropriate to the product. Define typography, color relationships, density, shape, imagery, and motion for the specific exploration. Avoid prescribing the same aesthetic for every task. Use a restrained hierarchy and deliberate spacing; preserve room for expressive choices when they help the experience.

## References

Research current comparable products and primary design references. Link the sources and explain which useful decisions inform the exploration. Use references for hierarchy, navigation, content, and interaction patterns rather than reproducing a competitor's screen.

## Interaction and accessibility

Show the primary journey only. Add loading, empty, error, success, and disabled states when the user asks or the screen's design depends on them; otherwise mention a state the design relies on in a short note. Preserve readable contrast, visible focus, labels, native semantics, keyboard access, and reduced-motion preferences. Communicate responsive intent from narrow screens to desktop. A static mockup must disclose interactions it cannot verify.

## Exploration freedom

Know the system, but never be blocked by it. Before designing, skim `agent/manifest.json` so the exploration reuses existing components by name and purpose where they fit. Exact Prism tokens and component APIs are optional; match them loosely and do not stop to verify contracts.

When the design needs something the system lacks, build it as a local mockup part and keep going. Do not pause to ask, search for matches, or propose system changes mid-exploration. Add a one-line note per missing part (what it is, nearest existing component) to the exploration's gap list. Keep these parts inside the exploration workspace and do not silently modify Prism. Gaps are resolved later, at production mapping.

## Review

Present a reviewable direction with the key screens and interactions, sources, assumptions, and limitations. Freeze the reference only after the user approves it. The chosen exploration supplies design intent for branded prototyping, not an exact visual specification. Routine brand/component adaptations proceed automatically under the production assessment gate. Consequential changes to content, hierarchy or interaction intent return for review; the branded prototype requires its own design review.
