---
name: prism-explore
description: Use when asked to explore, wireframe, mock up, or try directions for an interface whose design is not settled yet, and when asked to take such a wireframe to hi-fi, high fidelity, or a prototype. Wireframes are disposable and flexible; hi-fi builds with Prism components and checks gaps. Not for approved designs or explicit production builds; use prism-build for those.
---

# Explore an interface

Use this skill when the design is still open. If the user clearly asks for production implementation, or the design is already approved, use `prism-build` instead. Resolve routine creative choices yourself; ask only for missing constraints that materially affect the task.

## Set up

Read the installed `agent/design.md` and the compact index `agent/components.md` (open `agent/manifest.json` only if the index is not enough), then work in `exploration/<task>/` in this project, or in the requested canvas tool. Prism's exploration scaffold and wireframe kit are not installed, so use the project's existing runtime and write plain labeled boxes for media. Keep the workspace out of shipped code and do not edit the installed package.

## Process

1. **Frame:** State the primary user task, audience, content, and constraints from the brief. Identify assumptions rather than hiding them.
2. **Research:** Look at current comparable interfaces using primary sources. Link them and note the decisions they inform.
3. **Wireframe:** Default to wireframe fidelity as the design guidance describes: neutral styling (grayscale; show status and emphasis with text, shape, weight and position, not color), labeled boxes for media, real copy, no brand styling. Raise fidelity only when asked ("hi-fi", "high fidelity", "prototype") or after the wireframe is approved; see Hi-fi below.
4. **Stay flexible:** Exploration is for flexibility; consistency, shared components and tokens are the build phase's job. Existing components, APIs and token values are information, not constraints. Name a matching system component where one fits, but never bend the design to fit the system.
5. **Wireframes mock gaps and keep going:** At wireframe fidelity, when something is missing, mock it locally, add one line to the task's `GAPS.md`, and continue. Never stop or ask because a component does not exist. Hi-fi is different; see Hi-fi.
6. **Keep it minimal:** Show the primary journey only. Add other states, screens, or responsive variants when the user asks or the design depends on them. Follow the design guidance on accessibility.
7. **Check:** Run the mockup in its own runtime and report unsupported interactions. Do not run or report the project's production validation as verification of the mockup.
8. **Present:** Give the direction, references, assumptions, and limitations for review. Iterate within the same workspace.

## Hi-fi

Wireframes mock gaps and keep going. Hi-fi does not: it is built from the system and checks before it builds. Do not write a standalone page with its own colors, icons and CSS, and do not treat the wireframe as the starting file to restyle.

1. **Start from the wireframe, in a separate folder.** Read the wireframe and its `GAPS.md` in `exploration/<task>/`. Keep its layout, hierarchy, copy and data as they are, reusing the same content and fixtures; the user has already seen them and hi-fi is not a redesign. Do not copy its markup or CSS: the wireframe is loose, and hi-fi replaces its local parts with components. Do not add hi-fi files to `exploration/<task>/`: that folder holds the disposable wireframe only. Build the hi-fi as real app code in `src/screens/<task>/` (alongside the project's other screens) and mount it so it can be viewed in the running app, noting the entry-point change you made.
2. **Build with the system.** Use the installed components, blocks, styles and theme. The theme decides color, type, shape and icons: do not choose a palette, typeface pairing or icon set, write hex colors, inline SVG icons or your own button, chip or card CSS, and take spacing from `Page` and `Section` rhythm presets, not hand-set pixel values. A platform the library does not target, such as an iOS screen, is still built from components as a web approximation at the requested viewport. Say so once; it is not a reason to skip components.
3. **Check every part before building.** Map each part of the screen to a component and read that component's guidance before deciding it is missing. Do not log a gap from memory or from the component's name. Try a composition of smaller supported parts before declaring a gap. Pick from the compact component index (`agent/components.md` in a consumer project, `generated/context/system-components.md` in the Prism repository) and read only the guidance for the components you use; do not read the whole manifest.
4. **Prompt on a real gap.** When a part has no component and no supported composition, stop before building that part and ask the user, with the gap written in the consumer rules' Gap format (Gap, component or token, discovery, used instead, proposed extension). Offer: build it into the system (hand off the gap as a brief for Prism; inside the Prism repository, start the promotion process), use a visibly labeled temporary placeholder for now (explicit FPO authorization), or change the design to use what exists. Build the parts that are not blocked while waiting. Never silently mock a missing part at this fidelity.
5. **Verify cheaply.** Run the project's `prism-check` and build. Check layout, such as what sits above the fold, by measuring element positions in the browser, not by repeated screenshots; take one screenshot at the end. Do not publish the result to an external service unless asked.
6. **Write `NOTES.md` beside the screen** (`src/screens/<task>/NOTES.md`), as you work, a line or two per entry, not a report at the end. Seed it from the wireframe's `GAPS.md`, giving each carried-over item a status: now covered by a component, still a gap, or FPO. Leave the wireframe's `GAPS.md` unchanged. Use three short sections:
   - **Mapping:** screen part → component, with fit `good` or `compromised`.
   - **Gaps:** a part with no component, in the consumer rules' Gap format (Gap, component or token, discovery, used instead, proposed extension), plus the user's decision (build into the system, FPO, or change the design) and one line on what the design actually needed, such as the data shape or behavior.
   - **Poor fits:** a component used despite a mismatch, with what does not fit, the workaround, and the change that would fix it.

   Mark every temporary placeholder in code with a comment `FPO(<name>)` and list it under Gaps, so all of them can be found and removed before the screen ships. If a placeholder needs a native control, add `prism-allow native-control: FPO(<name>)` on or above that line so `prism-check` reports it without failing.
7. **Report.** List each part with the component it uses, each prompted gap and the user's decision, and what was not checked.

## Handoff

Once the user approves, preserve the source and visual reference with the relevant states, responsive intent, and an approval record. Never label a direction, wireframe or hi-fi approved unless the user said so; do not describe something as "approved" in your own notes or in the next step's brief without that record.

The exploration is a design-intent reference, not an exact production visual specification. Stop at approval. Production starts separately through `prism-build`, under its audit, including optional explicitly authorized FPO prototypes. Do not introduce audit schemas or promote exploratory parts unless the task requires that work.

Read the [design guidance](../../design.md) and [discovery](../../manifest.json).
