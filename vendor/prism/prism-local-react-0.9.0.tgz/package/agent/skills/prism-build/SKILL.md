---
name: prism-build
description: Use when implementing an approved design, or when explicitly asked to build a production page or screen with Prism in React. Audits the design against supported components before writing screen code. Not for trying out unsettled directions; use prism-explore for those.
---

# Build a Prism page

Use this skill for a full page or screen built with Prism. Follow the user's requested surface and page requirements. Treat the page as a composition of supported components; do not turn local page structure into a new system API without evidence and a separate request.

## Use the installed release

If this project consumes a Prism package, follow these steps in order. If the user wants to try directions rather than build, use `prism-explore` instead.

1. **Orient:** Read [the installed entry point](../../../AGENTS.md) and [discovery](../../manifest.json). Match release identity; do not rebuild context or read a separate Prism checkout.
2. **Classify:** Read [consumer rules](../../rules.md) through the release's generated portable adapter. Identify experience, platform, viewport and input needs independently.
3. **Select:** Pick components from the compact index `agent/components.md`, then retrieve only the selected guidance, schemas and React declarations from the installed inventory. Do not read the whole manifest.
4. **Audit:** Record the audit from the packaged audit policy/template before writing screen code, and report its readiness. Keep unsupported needs as gaps. Read each candidate component's guidance before deciding a need is a gap. When a need has no component and no supported composition, stop before building that part and ask the user to choose: build it into the system (hand off the gap as a brief for Prism), use a visibly labeled temporary placeholder under the audit policy's FPO exception, or revise the design. Build the unblocked parts meanwhile.
5. **Build:** Compose supported imports, native layout and local compositions. Use packaged recipes as examples, not shared APIs. Put the screen in `src/screens/<task>/`, never in `exploration/`, which holds disposable wireframes only; keep the audit and gap decisions beside it. If a hi-fi `NOTES.md` already sits there, carry its mapping, gaps, poor fits and `FPO(...)` markers into the audit instead of rediscovering them.
6. **Verify:** Use the project's validation commands, review the running consumer app, and append actual results and remaining gaps to the audit.




Read the [audit policy](../../audit.md), [template](../../audit-template.md), [recipes](../../recipes.md) and [validation](../../validation.md) as needed.
